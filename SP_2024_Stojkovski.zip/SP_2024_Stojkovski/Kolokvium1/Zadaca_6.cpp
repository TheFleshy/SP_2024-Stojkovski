#include <iostream>
using namespace std;
int main (){

    int z;
    cin>>z;  // unasame prvicno eden broj so ke provereme posle dali zbiro na parovite e ednakov so nego

    int a, b;
    int zbir ;
    int brojac = 0;             //site ovia sa prvicno na 0
    int zbirNaZ = 0;

    while (cin>>a && cin>>b){               // se dodeka se unasat parovi
        if (a == 0 && b == 0)break;         // ako se unesat 0 0 , prekinuva
        zbir = a+b;                     //sobirame sekogas parovite
        brojac ++;          // brojaco se zgolemuva sekogas koga uneseme nov par, posle ni treba za da podeleme od koku parovi sme unesele, kolku parovi sa imali zbir na z

        if (z == zbir){     // ako zbiro e ednakov na z
            zbirNaZ ++;     // zgolemuva brojkata na par so zbiro mu e Z
        }
    }
    float procent;          // za procento mora so float oti u test slucai ima so decimalni
    if (zbirNaZ == 0){      // uslov ako nema ni eden par so mu e zbiro = z , procento da bide 0
        procent = 0;
    }
    else {
        procent = 100.0 / ((float) brojac/zbirNaZ);  // procento e 100/(kokuparovi sa uneseni do 0 0 / kolku parovi zbiro im e z)
    }
    cout<<"Vnesovte "<<zbirNaZ<<" parovi od broevi chij zbir e "<<z<<endl;
    cout<<"Procentot na parovi so zbir "<<z<<" e "<<procent<<"%";

    return 0;
}
