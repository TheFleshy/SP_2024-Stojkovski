#include <iostream>
using namespace std;
int main() {
    int a, b;
    cin >> a >> b;
    int najmalPalindrom = b + 1, najgolemPalindrom = a - 1;
    for (int i = a; i <= b; i++) {
        int broj = i, palindrom = 0;
        while (broj > 0) {
            int cifra = broj % 10;
            palindrom = palindrom * 10 + cifra; // vrte go brojo pr ako e 12345 - 54321 dodeka ne dojde do 0 t.s dodeka ne se trgnat site cifri
            broj /= 10;
        }
        if (i == palindrom) {
            if (i < najmalPalindrom)najmalPalindrom = i;
            if (i > najgolemPalindrom)najgolemPalindrom = i;
        }
    }
    cout<<"Smallest Palindromic Number: "<<najmalPalindrom<<endl;
    cout<<"Largest Palindromic Number: "<<najgolemPalindrom;
    return 0;
}



//#include <iostream>
//
//using namespace std;
//
//int main()
//{
//    int n,m;
//    cin>>n>>m;
//    int smallest=m , largest=0;
//    for(int i=n;i<=m;i++)
//    {
//        int k=i,zbir=0;
//        while(k>0)
//        {
//            zbir*=10;
//            zbir+=k%10;
//            k/=10;
//        }
//        if(zbir==i)
//        {
//            if(zbir<smallest)
//            {
//                smallest=zbir;
//            }
//            if(zbir>largest)
//            {
//                largest=zbir;
//            }
//        }
//    }
//    cout<<"Smallest Palindromic Number: "<<smallest<<endl;
//    cout<<"Largest Palindromic Number: "<<largest<<endl;
//    return 0;
//}