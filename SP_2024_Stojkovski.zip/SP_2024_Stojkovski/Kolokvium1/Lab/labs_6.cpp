// elementi na parnite pozicii da se mnozat so 2, na neparni da se soberat so 2
#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;    // so ova opredeluvame kolku elementi ke vneseme vo nizata
    int clenovi [100]; // kreirame niza od 100 elementi sto ne mora da se iskoristat
    for (int i = 0; i<n; i++)  cin>>clenovi[i];           // so eden ciklus od 0 do n , se ispisuvaat site clenovi

    for (int i = 0; i<n; i++){                      // vo ciklus gi sporeduvame site vneseni cifri
        if (i%2==0) clenovi[i] = clenovi[i]*2;   // ako cifrata e na parno mesto da se pomnozi so 2
        else clenovi[i] = clenovi[i]+2;  // ako e pak na neparno da se sobere so 2
    }

    for (int i = 0; i<n; i++)         // ciklus kade gi ispsivuame novite promeneti cifri, odeleni so prazno mesto
        cout<<clenovi[i]<<" ";

    return 0;
}


// ************************************************************//



// Zadaca - Ogledalni broevi
#include <iostream>
using namespace std;
int main (){

    int N;
    cin>>N;
    for (int i = 0; i<N; i++){
        int niza[100];
        int brojNaClenovi, ogledalniBroevi = 0;
        cin>>brojNaClenovi; //dolz
        for (int j = 0; j<brojNaClenovi; j++)  cin>>niza[j]; // elm na niz0
        for (int k = 0; k<brojNaClenovi/2; k++)
        {
            if (niza[k] == niza[brojNaClenovi-k-1])
                ogledalniBroevi += 2;
        }
        if (brojNaClenovi %2 != 0)  ogledalniBroevi++;

        double procent = (double)ogledalniBroevi/brojNaClenovi * 100;  // potrebno e na dve decimlai

        cout.precision(2);
        cout<<fixed<<procent<<"%"<<endl;
    }

    return 0;
}


// ************************************************************//

//Dali parot na broevi eden do eden e prost ili ne
#include <iostream>
using namespace std;

bool daliEProst (int brojj){
    for (int i = 2; i<=brojj/2; i++)
    {
        if (brojj % i == 0) return false;
    }
    return true;
}

int main (){
    int N;
    cin>>N;
    int niza [100];
    for (int i = 0; i<N; i++)  cin>>niza[i];

    for (int i = 0 ; i < N; i+=2)
    {
        int edenPar = niza[i] * 10 + niza[i+1];
        if (i == N-1)  edenPar = niza[i];

        if (daliEProst(edenPar))
            cout<<"brojot "<<edenPar<<" e prost";
        else
            cout<<"brojot "<<edenPar<<" NE e prost";
        cout<<endl;
    }

    return 0;
}

