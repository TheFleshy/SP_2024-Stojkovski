#include <iostream>
using namespace std;

int main(){
    int M, N;

    cin>>M;
    int a[100];
    for(int i=0;i<M;i++) cin>>a[i];

    cin>>N;
    int b[100];
    for(int i=0; i<N; i++) cin>>b[i];

    int s[200];

    int i=0, j=0, k=0; // i za prva, j za vtora, k za treta
    while(i<M && j<N){  //spojuva gi element od dvete nizi
        if(a[i]<b[j]){  // elem od prva pomal od vtora, stava elem od prva
            s[k]=a[i];
            k++;
            i++;
        }
        else{  // elem od vtora obratno
            s[k]=b[j];
            k++;j++;
        }
    }
    while(i<M){     //site od prvata , pogolemi od vtorata gi stava u s
        s[k]=a[i];
        i++;k++;
    }
    while(j<N){    // tuka obratno od vtora pogolemi prva stava u s
        s[k]=b[j];
        j++;
    }

    for(int x=0; x<k; x++) cout<<s[x]<<" ";
    return 0;

}
/* 4
1 3 5 7
4
2 4 6 8*/