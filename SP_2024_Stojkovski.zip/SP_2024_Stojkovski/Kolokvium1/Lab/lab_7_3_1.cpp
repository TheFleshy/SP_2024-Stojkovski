#include <iostream>
using namespace std;
int main (){

    int n,m;
    cin>>n>>m;

    int mat[n][m];

    int i,j;

    for (i=0; i<n; i++){
        for (j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    cout<<mat[0][0]<<endl;
    for (j=1; j<m; j++){
        int k=j;
        i = 0;
        while (i<n && k<m){
            cout<<mat[i][k]<<" ";
            i++; k++;
        }
        cout<<endl;
    }


    /*
     2 5
     1 2 3 4 5
     6 7 8 9 10          // ke gi pecate 1, 2so8, 3so9, 4so10, 5 ... tuka ne gi koriste site elem na 1 red
     */


    return 0;
}