// Се внесуваат два телефонски броја и времетраење на разговорот во минути.
// Да се пресмета цената на повикот доколку знаеме дека првите 30 минути чинат 3 ден/мин, а после
// тие 30 мин цената на 1 мин е 2 ден.
// Дополонително ако двата броја се ист оператор да се пресмета 30% попуст.
// оператор 1 - 071, 072, 073
// оператор 2 - 074, 075, 076

#include <iostream>

using namespace std;

int main() {
    float broj1, broj2, vreme, cena;
    int op1, op2;
    cin >> broj1 >> broj2 >> vreme;
    if (vreme <= 30)
        cena = vreme * 3;
    else
        cena = 90 + (2 * (vreme - 30));
    op1 = broj1 / 1000000;
    op2 = broj2 / 1000000;
    float popust = cena * 0.3;
    if ((op1 == 71 || op1 == 72 || op1 == 73) && (op2 == 71 || op2 == 72 || op2 == 73))
        cena = cena - popust;

    else if ((op1 == 74 || op1 == 75 || op1 == 76) && (op2 == 74 || op2 == 75 || op2 == 76))
        cena = cena - popust;
    cout << cena;

    return 0;
}


