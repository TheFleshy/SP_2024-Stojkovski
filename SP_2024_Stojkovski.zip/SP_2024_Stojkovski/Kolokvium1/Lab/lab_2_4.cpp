// Освоени поени од 5 активности за еден предмет
//Услов да биде положен е да имаат над 50 освоени поени.
// Ако има од 0-50 не го положил
// Ако има 51-60 го положил со 6 // Ако има 61-70 го положил со 7 // Ако има 71-80 го положил со 8
// Ако има 81-90 го положил со 9  // Ако има 91-100 го положил со 10
//Да се испечати оцена, поени, услов за повисока, спротивно нема, тоа само ако му треба 1 поен.

#include <iostream>
using namespace std;
int main (){
    int p1, p2,p3,p4,p5;
    cin>>p1>>p2>>p3>>p4>>p5;
    int poeni;
    poeni = p1+p2+p3+p4+p5;
    int ocena;
    if (poeni <= 50){
        ocena=5;
        cout<<"Predmetot ne e polozen"<<endl;
    }
    if (poeni >= 51 && poeni <= 60){
        ocena=6;
    }else if (poeni >= 61 && poeni <= 70){
        ocena=7;
    }else if (poeni >= 71 && poeni <= 80){
        ocena=8;
    }else if (poeni >=81 && poeni <= 90){
        ocena=9;
    }else if (poeni >= 91){
        ocena=10;
    }
    if (ocena != 5){
    cout<<"Ocenka: "<<ocena<<","<<" "<<"poeni: "<<poeni<<endl;
    }
    if (ocena != 5 && ocena != 10){
        if (poeni>=50 && poeni % 10 ==0){
            cout<<"Ima uslov za povisoka ocena";
        }else {
            cout<<"Nema uslov za povisoka ocena";
        }
    }
    return 0;
}