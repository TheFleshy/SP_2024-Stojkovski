// Со кино:
// билет - 200 ден + (комедија=20 ден, акција=40 ден, романса=30 ден)
// Мени:
// Пијалоци: Вода - 80 ден, Фанта/Кока/Спрајт - 100 ден, Чај - 120 ден.
// Пуканки: S - 100 ден, M - 150 ден, L - 200 ден
// Да се пресмета вкупната цена што треба да се плати
// Дополнително ако одат во Среда и платат со VISA, за 2 билети ќе добијат 4 (50% попуст на билтетите)

#include <iostream>
#include <string>

using namespace std;

int main() {

    string film, pijalok, den;
    char goleminaP;
    int bPakuvanjeP, brojP, karta = 200, pukanki, cenaP = 100;
    bool visa;
    cin >> film >> goleminaP >> bPakuvanjeP >> pijalok >> brojP >> den >> visa;

    if (film == "action")karta = 240;
    else if (film == "comedy")karta = 220;
    else if (film == "romance")karta = 230;

    if (goleminaP == 'S')pukanki = 100;
    else if (goleminaP == 'M')pukanki = 150;
    else if (goleminaP == 'L')pukanki = 200;

    if (pijalok == "Fanta" || pijalok == "CocaCola" || pijalok == "Srpite")cenaP = 100;
    else if (pijalok == "Water")cenaP = 80;
    else if (pijalok == "IceTea")cenaP = 120;

    if (den == "Wednesday" && visa == 1)karta=karta/2;

    int cena = 4*karta + bPakuvanjeP*pukanki + brojP*cenaP;
    cout<<cena;

    return 0;
}