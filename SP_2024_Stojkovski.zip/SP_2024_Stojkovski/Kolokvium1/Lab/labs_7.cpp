// zbir na site neparni broevi vo niza
#include <iostream>
using namespace std;

int sumaNeparni(int niza[], int n){
    if(n==0){
        if(niza[n]%2) return niza[n];
    }
    if(niza[n]%2) return niza[n]+ sumaNeparni(niza,n-1);
    else return sumaNeparni(niza,n-1);
}

int main(){
    int n;
    cin>>n;
    int niza[n];
    for(int i=0; i<n; i++) cin>>niza[i];
    cout<<"Zbirot na neparnite cifri e "<<sumaNeparni(niza,n-1);
}







//so interesna, pecate broevi od niza so sa takvi
#include <iostream>
using namespace std;

int isInteresting (int n){
    int cifra = n%10;
    while (n > 9){
        n/=10;
        int prethodnaCifra = n%10;
        if(cifra%2==0 && prethodnaCifra%2==0) return 0;
        else if(cifra%2!=0 && prethodnaCifra%2!=0) return 0;
        else {
            cifra = prethodnaCifra;
        }
    }
    return 1;
}

void printArray(int niza[], int n){
    if(n==0){
        int broj= isInteresting(niza[n]);
        if(broj==1) cout<<niza[n]<<" ";
        return;
    }
    int broj= isInteresting(niza[n]);
    if(broj==1) {
        printArray(niza,n-1);
        cout << niza[n] << " ";
    }else printArray(niza,n-1);

}

int main (){

    int n;
    cin>>n;

    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    printArray(niza,n-1);

    return 0;
}





//bez sort funkcija da spoe dve nizi u edna
#include <iostream>
using namespace std;

int main(){
    int M, N;

    cin>>M;
    int a[100];
    for(int i=0;i<M;i++) cin>>a[i];

    cin>>N;
    int b[100];
    for(int i=0; i<N; i++) cin>>b[i];

    int s[200];

    int i=0, j=0, k=0; // i za prva, j za vtora, k za treta
    while(i<M && j<N){  //spojuva gi element od dvete nizi
        if(a[i]<b[j]){  // elem od prva pomal od vtora, stava elem od prva
            s[k]=a[i];
            k++;
            i++;
        }
        else{  // elem od vtora obratno
            s[k]=b[j];
            k++;j++;
        }
    }
    while(i<M){     //site od prvata , pogolemi od vtorata gi stava u s
        s[k]=a[i];
        i++;k++;
    }
    while(j<N){    // tuka obratno od vtora pogolemi prva stava u s
        s[k]=b[j];
        j++;
    }

    for(int x=0; x<k; x++) cout<<s[x]<<" ";
    return 0;

}




