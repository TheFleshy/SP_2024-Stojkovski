// najgolem palindrom
#include <iostream>

using namespace std;

int reverse(int number) {       // go naogame obratniot broj
    int broj = 0;
    while (number > 0) {
        int cifra = number % 10;
        broj = broj * 10 + cifra;
        number /= 10;
    }
    return broj;
}

bool isPalindrom(int number) {  // koristime bool za da vrne samo dali e ili ne e palindrom
    int broj = reverse(number);   // reverse(number) go naoga obratniot broj
    if (broj == number) {   // dali brojot e ednakov so negoviot obraten
        return true;
    }
    else
        return false;
}

int findLargest(int q, int r) {     // funkcijata ke vraka int podatocen tip, a ke prima q i r sto se int
    int najgolem = 0;
    for (int i = q; i <= r; i++) {
        if (isPalindrom(i)) {
            if (i > najgolem)
                najgolem = i;
        }
    }
    return najgolem;            // ke vrne najgolemiot broj sto e palindrom
}

int main() {
    int z, t;   // za pocetok i kraj
    cin >> z >> t;
    int najgolem = findLargest(z, t);       // int zatoa so find largest vraka int
    cout << "Largest Palindromic Number: " << najgolem;
    return 0;
}


//*****************************************************//

//Funkcija so apsolutna vrednost

#include <iostream>
using namespace std;

int apsolutna(int broj){        // ja vraka absolutnata vrednost na brojot
    if(broj>=0)
        return broj;
    else
        return -broj;   // ako e brojot pozitiven da ostane pozitiven, ako e negativen da vrne pozitiven
}

int najmaloD(int N){
    int najmalo = 2000000000;      // ovde se vnesuva najgolemiot int za da moze da se sporeduva
    for(int i=0; i<N; i++){
        int a,b,c, d=0;
        cin>>a>>b>>c;
        int razlika1=a-b, razlika2=b-c;
        d= apsolutna(razlika1)+ apsolutna(razlika2);    // ovde se presmetuva d
        if(d<najmalo)   // ako d e pomal od najmal go menuvame najmal
            najmalo=d;
    }
    return najmalo;
}

int main() {
    int N;
    cin>>N;

    int najmal = najmaloD(N);
    cout<<najmal;

    return 0;
}

//***********************************************//

//