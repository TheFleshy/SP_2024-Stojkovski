// Прогресивен данок

#include <iostream>

using namespace std;
int main (){

    double procent0, prag1, procent1, prag2,procent2, primanja;
    cin>>procent0>>prag1>>procent1>>prag2>>procent2>>primanja;

    if (primanja <= prag1){
        double rez = primanja * 0.1;
        cout<<rez;
        return 0;
    }
    else if (primanja <= prag2){
        double rez = (prag1)*0.1+(primanja-prag1)*0.2;
        cout<<rez;
        return 0;
    }
    else {
        double rez = ((prag1)*0.1) + ((prag2-prag1)*0.2) + ((primanja-prag2)*0.3);
        cout<<rez;
        return 0;
    }

}