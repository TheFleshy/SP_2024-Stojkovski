//Од стандарден влез се вчитува даден број n, а потоа се вчитуваат n трицифрени броеви .
// Ваша задача е да го најдете најголемиот број чиј збир на неговите цифри треба да е парен.


//#include <iostream>
//using namespace std;
//int main (){
//    int n, zbir, max=0;
//    cin>>n;
//    for (int i=0; i<n; i++){
//        int br;
//        cin>>br;
//        int c1,c2,c3;
//        c1 = br/100;
//        c2 = br/10;
//        c3 = br;
//        zbir = c1+c2+c3;
//
//        if (zbir % 2 ==0 && br>max){
//            max = br;
//        }
//    }
//    cout<<max;
//    return 0;
//}

#include <iostream>
using namespace std;
int main() {
    int n, najgolem=0;
    cin>>n;
    for(int i=0; i<n; i++){
        int broj;
        cin>>broj;
        int startBroj = broj, zbirCifri = 0;
        while(broj>0){
            int cifra = broj%10;
            zbirCifri+=cifra;
            broj /= 10;
        }
        if(zbirCifri % 2 == 0 && startBroj > najgolem){
            najgolem = startBroj;
        }
    }
    cout<<najgolem;
    return 0;
}
