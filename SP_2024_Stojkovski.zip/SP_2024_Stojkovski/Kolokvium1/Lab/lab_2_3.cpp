// Да се напише програма во која се внесуваат три цели броја.
// Доколку внес броеви се во растечки редослед да се испечати 1, а во опаѓачки -1.
// Во спротивно 0

#include <iostream>
using namespace std;
int main (){
    int a,b,c;
    cin>>a>>b>>c;
    if (a<b && b<c){
        cout<<"1";
    }
    else if (a>b && b>c)
    {
        cout<<"-1";
    }
    else {
        cout<<"0";
    }
    return 0;
}