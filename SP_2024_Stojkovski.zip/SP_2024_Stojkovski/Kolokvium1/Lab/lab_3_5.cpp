// Освоени поени од 5 активности, за положен е над 50, од 0-50 не го положил
// 51-60 положил со 6, 61-70 со 7, 71-80 со 8, 81-90 со 9, над 90 со 10.
// да се испечате оценката, поените, 1 за услов, иначе 0

#include <iostream>
using namespace std;
int main (){

    float a,b,c,d,e, p;
    cin>>a>>b>>c>>d>>e;
    p = a+b+c+d+e;

    if (p <= 50){
        cout<<"Predmetot ne e polozen";
    }
    else if (p> 50 && p<=60 ){
        cout<<"Ocenka:6, poeni:"<<p<<endl;
        if (p==60){
            cout<<"Ima uslov za povisoka ocenka";
        }else {
            cout<<"Nema uslov za povisoka ocenka";
        }
    }
    else if (p> 60 && p<=70 ){
        cout<<"Ocenka:7, poeni:"<<p<<endl;
        if (p==70){
            cout<<"Ima uslov za povisoka ocenka";
        }else {
            cout<<"Nema uslov za povisoka ocenka";
        }
    }
    else if (p> 70 && p<=80 ){
        cout<<"Ocenka:8, poeni:"<<p<<endl;
        if (p==80){
            cout<<"Ima uslov za povisoka ocenka";
        }else {
            cout<<"Nema uslov za povisoka ocenka";
        }
    }
    else if (p> 80 && p<=90 ){
        cout<<"Ocenka:9, poeni:"<<p<<endl;
        if (p==90){
            cout<<"Ima uslov za povisoka ocenka";
        }else {
            cout<<"Nema uslov za povisoka ocenka";
        }
    }
    else if (p>90){
        cout<<"Ocenka:10, poeni:"<<p<<endl;
    }

    return 0;
}