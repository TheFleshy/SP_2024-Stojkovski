#include <iostream>
using namespace std;

int funkcija (int niza[], int n, int k){

    if (n == 0){
        if (niza[n] == k)
            return 1;
        else return 0;
    }
    if (niza[n] == k){
        return 1 + funkcija(niza, n-1, k);
    }else {
        return funkcija(niza, n-1, k);
    }

}


int main (){

    int n;
    cin>>n;
    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    int k;
    cin>>k;

    int postoiK = funkcija(niza, n, k);

    if (postoiK){
        cout<<postoiK;
    }
    else cout<<0;


    return 0;
}


#include <iostream>
using namespace std;

int cikcak (int n){
    if (n < 10){
        return 1;
    }
    if (n%10 > n/10%10){
        return cikcak(n/10);
    }
    else if (n%10 < n/10%10){
        return cikcak(n/10);
    }
    else return 0;
}


int main (){

    int n;

    cin>>n;

    cout<<cikcak(n);

    return 0;
}


#include <iostream>
using namespace std;

int isInteresting (int n){
    int cifra = n%10;
    while (n > 9){
        n/=10;
        int prethodnaCifra = n%10;
        if(cifra%2==0 && prethodnaCifra%2==0) return 0;
        else if(cifra%2!=0 && prethodnaCifra%2!=0) return 0;
        else {
            cifra = prethodnaCifra;
        }
    }
    return 1;
}

void printArray(int niza[], int n){
    if(n==0){
        int broj= isInteresting(niza[n]);
        if(broj==1) cout<<niza[n]<<" ";
        return;
    }
    int broj= isInteresting(niza[n]);
    if(broj==1) {
        printArray(niza,n-1);
        cout << niza[n] << " ";
    }else printArray(niza,n-1);

}

int main (){

    int n;
    cin>>n;

    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    printArray(niza,n-1);

    return 0;
}


#include <iostream>
using namespace std;

int sumaNeparni(int niza[], int n){
    if(n==0){
        if(niza[n]%2) return niza[n];
    }
    if(niza[n]%2) return niza[n]+ sumaNeparni(niza,n-1);
    else return sumaNeparni(niza,n-1);
}

int main(){
    int n;
    cin>>n;
    int niza[n];
    for(int i=0; i<n; i++) cin>>niza[i];
    cout<<"Zbirot na neparnite cifri e: "<<sumaNeparni(niza,n-1);
    return 0;
}