#include <iostream>
using namespace std;

int main() {
    int broj, brCifriBroj = 0;
    cin >> broj;
    while (broj > 0) {
        brCifriBroj++;              // одделувам ги цифрите и бројам колку цифри има еден број
        broj = broj / 10;
    }
    int a;
    while (cin >> a) {
        int brCifri = 0, a1 = a;    // праеме нов број а1 кој ќе го цепкаме за да најдеме број на цифри, и зиаме му ја вредноста на главнио број за да не го расипеме.
        while (a1 > 0) {
            brCifri++;          // одделуваме ги цифрите на новио броеме колку има цифри
            a1 = a1 / 10;
        }
        if (brCifriBroj == brCifri)cout << a << endl; // споредба на бројо на цифри у првио и вторио и печатеме го тестиранио број
    }
    return 0;
}
