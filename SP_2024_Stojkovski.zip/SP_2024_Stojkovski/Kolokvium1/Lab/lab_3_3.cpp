// Упслужување на студенти за упис на ФИНКИ

#include <iostream>
using namespace std;
int main (){

    int broj, rez;
    cin>>broj;
    if (broj < 24)
        rez = broj*5;
    else if (broj <= 36)
        rez = broj * 5 + 30;
    else if (broj <60 )
        rez = broj * 5 + 60;
    else {
        cout<<"Studentot ne e voopsto usluzen";
        return 0;
    }
    rez = rez - 5;
    cout<<"Hours: "<<rez/60<<", "<<"minutes: "<<rez%60;
    return 0;
}
