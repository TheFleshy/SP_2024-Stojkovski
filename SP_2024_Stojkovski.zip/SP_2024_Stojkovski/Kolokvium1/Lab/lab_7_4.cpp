//***  1va so menenje na elementi na najgolema kolona

#include <iostream>
using namespace std;

int main() {
    int n,m;
    cin>>n>>m;

    int mat[n][m];

    int i,j;

    for (i=0; i<n; i++){
        for (j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    int najgolemZbir = 0, index=0;

    for(i=0; i<n; i++){
        int segasenZbir=0;
        for(j=0; j<m; j++){
            segasenZbir += mat[j][i];
        }
        if(segasenZbir>najgolemZbir) {
            najgolemZbir = segasenZbir;
            index = i;
        }
    }


    for(i=0; i<n; i++){
        mat[i][index] = najgolemZbir;
    }


    for(i=0; i<n; i++) {
        for (j = 0; j < m; j++)
            cout << mat[i][j] << " ";
        cout<<endl;
    }

    return 0;
}
