// Лаб - За успех со кредити, година, просек ..

#include <iostream>
using namespace std;
int main (){
    int krediti, godina;
    double prosek;
    cin>>krediti>>godina>>prosek;
    if (krediti > 100 && prosek > 8.0){
        int predvidenikrediti = (2023 - godina)*60;
        double poeni = ((float)krediti/predvidenikrediti)*10+(prosek - 8.5)*6.5;
        if (krediti > 240){
            cout<<"Need to graduate! ";
        }
        if (prosek > 9.0 ){
            cout<<"Great student! ";
        }
        cout<<"Points: "<<poeni;
    }else {
        cout<<"Points: "<<0;
    }


    return 0;
}