// Сума на броеви деливи со 3, а не е деливо со 2 во интервал [А,B)

#include <iostream>
using namespace std;
int main (){
    int a,b, suma=0;
    cin>>a>>b;

    for (int i=a; i<b; i++){

        if (i % 3 == 0 && i % 2 != 0){
            suma = suma + i;

        }

    }
    cout<<suma;

    return 0;
}
