#include <iostream>
using namespace std;

int main() {
    int broj;

    while (cin >> broj) {
        if (broj < 10) {
            continue;               // Игнорирај броеви помали од 10
        }
        int temp = broj;
        int flag = 1;

        while (temp >= 10) {                    // Проверка за секој пар соседни цифри
            int poslednaCifra = temp % 10;
            temp /= 10;
            int predposlednaCifra = temp % 10;

            if (!((poslednaCifra < 5 && predposlednaCifra >= 5) || (poslednaCifra >= 5 && predposlednaCifra < 5))) {     // Правило за цик-цак
                flag = 0;
                break;
            }
        }

        if (flag) {
            cout << broj << endl;           // Печатење на цик-цак броевите
        }
    }

    return 0;
}
