// На кое место се појавува најголемата цифра и правење статистика коку пати на тоа место се е најдела

#include <iostream>
using namespace std;
int main (){
    int broj;
    int pozicija0 = 0;
    int pozicija1 = 0;
    int pozicija2 = 0;                  // prvicno za site pozicii e nula
    int pozicija3 = 0;
    int pozicija4 = 0;

    while (cin>>broj){                          // se dodeka se unasa broj, ako se unase drugo zavrsuva
        int maxCifri = 0;
        int pozicija = 0;
        int temp = broj;

        for (int i=0; i<5 && temp > 0; ++i){
            int cifra = temp % 10;
            if (cifra > maxCifri){              //Proveruva na koe mesto e najgolemata cifra
                maxCifri = cifra;
                pozicija = i;
            }
            temp/=10;
        }

        if (pozicija == 0) pozicija0++;
        else if (pozicija == 1) pozicija1++;
        else if (pozicija == 2) pozicija2++;        // Vo zavisnost na koe mesto e najgolemata cifra taa se zgolemuva
        else if (pozicija == 3) pozicija3++;        // za posle dole u statistikata da dojde plus
        else if (pozicija == 4) pozicija4++;
    }
    cout<<"0: "<<pozicija0<<endl;
    cout<<"1: "<<pozicija1<<endl;
    cout<<"2: "<<pozicija2<<endl;       // zapisuva na sekoja pozicija koku pati e bila najgolemata cifra
    cout<<"3: "<<pozicija3<<endl;
    cout<<"4: "<<pozicija4<<endl;

    return 0;
}