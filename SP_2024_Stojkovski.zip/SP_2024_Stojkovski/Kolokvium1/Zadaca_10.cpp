#include <iostream>
using namespace std;
int main (){

    int broj; // mora da se stave zatoa so na krajo ke se pecate
    while (cin >> broj) {  // ciklus dodeka se unasa broj

        if (broj < 10)continue;  // ako e pomal od 10 da go ignorira

        int temp = broj; // mora da se stave temp oti ke go cepkame brojo a na krajo mora da se ispecate normalen broj ne cepkan

        int znak = 1; // stava se znako da receme na 1 zatoa so , dole u if ako e 0 ke zavrse i ke provere nov if ako e dojdel do 0 dali da go pecate brojo ako ne e dojdel tugaj nema da go pecate


        while (temp >= 10){  // ciklus stavam >= 10 zatoa so proveruvame za broevi so sa pogolemi ili pomali od 10, gore stavihme tia so sa pomali da se ignorirat
            int Poslednacifra = temp % 10;  // naogame ja poslednata cifra
            temp = temp/10; // delemo go brojo
            int Predposledna = temp % 10; //naogame ja predposlednata cifra
            temp = temp/10;
            int PredPredposledna = temp %10;

            if (!((Poslednacifra < Predposledna && Predposledna > PredPredposledna ) || (Poslednacifra > Predposledna && Predposledna < PredPredposledna))){  // sporeduvame gi poslednata i predposlednata cifra ako go zadovoluvat uslovo ulavat u nego
                znak = 0;   // updateame go znako i izlavame od ifo
                break;
            }

        }
        if (znak){  // ako znako e dojdel do 0 ulavme u uslovo i pecateme go brojceto
            cout<<broj<<endl;  // pecateme go sekoj cikcak broj , re6i
        }

    }

    return 0;
}