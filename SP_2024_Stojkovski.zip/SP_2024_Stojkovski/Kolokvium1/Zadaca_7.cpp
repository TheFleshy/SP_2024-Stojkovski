    #include <iostream>
    using namespace std;
    int main (){

        int m;
        cin>>m; // unasa se m za da kaze koku na koku ke se prave semata
        for (int i=0; i<m; i++){        // najprvo ulava u for cikluso dodeka ne stane pomal od m
            for (int j=0; j<m; j++){   // odma ulava u j dodeka ne stane pomal od m               -- ovia raboti mora da gi prae zatoa so se rabote za sema na desno i nadole
                if (i==0 || i==m-1 ){   // ako i == 0 ili e pomal za edno od m ulava u uslovo ako ne ode u else , so ovoa ke gi najde za prvio i poslednio red
                    if (j == 0 || j==m-1){    // ako j == 0 ili e pomal za eden od 1 , pecate %
                        cout<<"%";
                    }
                    else {                  // ako ne e j == 0 ili pomal za edno od m pecate @
                        cout<<"@";
                    }
                }
                else {                      // ovaj else sluze da gi crta srednite redovi
                    if (j==0 || j==m-1){        //ulava u if ako j == 0 ili e pomal za 1 od m i crta %
                        cout<<"%";
                    }
                    else {              // ako ne e crta .
                        cout<<" ";
                    }
                }
            }
            cout<<endl;  // posle sekoj red nacrtan ode u nov red za da ne gi nacrta site u eden xd
        }
        return 0;
    }

