#include <iostream>
using namespace std;
int main (){

    int N, X;
    cin>>N>>X;      // Unasa gi N , X

    for (int i=N-1; i>0; i--){        // prae eden ciklus so pocnuva za eden pomal od N , dodeka e broj i go namaluva , za na kraj da go ispecate brojo so e totalno razlicen
        int broj=i, Tobreak = 0;  // kreirame eden broj so go zima od i za da mozeme da go cepkame, zimame ToBreak za da mi dava znaci dali e zadovoleno toa so mi treba
        while (broj > 0) {          // praeme eden while da go cepkame broj
            int cifra = broj % 10;
            broj /= 10;                 // deleme go na cifri brojceto

            int x = X;              // praeme eden nov x so isto zima sea vrednosti na X za da mozeme da go cepkame
            while (x > 0) {         // praeme isto while dodeka taj broj ne e pomal od 6 i go cepkame
                int cifraX = x % 10;
                x /= 10;                // kako i gore naogame cifrite na x

                if (cifraX == cifra){    // eden uslov dali cifrata od brojceto e ista so cifrata od x
                    Tobreak = 1;
                    break;                  // ako da stavame mu znak na ToBreak = 1 so mora da e razlicno od gore i izlava od cikluso za da moze da ode da traze drug broj
                }
            }
            if (Tobreak == 1){              // uslov ako znako e 1 i deka cifrite sa isti da izleze i od taj ciklus za da ode na drug broj
                break;
            }
        }
        if (Tobreak == 0){              // uslov pa ako e 0 , tugaj ne sa isti cifrite i ne izlava od cikluso tuku odma go pecate i , so veke se namaluva
            cout<<i;
            return 0;           // veke e najden najgolemio broj so e pomal od N a e razl od X i zavrsuva
        }
    }
    cout<<0;        // pecateme 0 ako uopste ne ni uleze u for cikluso so uste ne znam kako ke go odbegne ..
    return 0;
}