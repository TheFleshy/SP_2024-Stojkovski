// Да се напише програма која ќе прочита два природни броја.
// Програмата треба да провери дали цифрите на непарна позиција од првио број се на парна позиција во вторниот.
// Ако услов е исполнет , програмата печати DA, инаку NE

// Првата цифра се наоѓа на 0та позиција почнувајќи од лево.


#include <iostream>
using namespace std;

int main() {
    int broj1, broj2;
    cin >> broj1 >> broj2;

    int temp1 = broj1;
    int temp2 = broj2;
    bool isConditionMet = true;

    while (temp1 > 0 && temp2 > 0) {
        int cifra1 = temp1 % 10;
        int cifra2 = temp2 % 10;

        if (cifra1 % 2 != 0 && cifra2 % 2 == 0) {
            isConditionMet = false;
            break;
        }

        temp1 /= 10;
        temp2 /= 10;
    }

    if (isConditionMet) {
        cout << "DA" << endl;
    } else {
        cout << "NE" << endl;
    }

    return 0;
}