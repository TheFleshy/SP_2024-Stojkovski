#include <iostream>
using namespace std;

int main() {
    // Внеси ги координатите на точката A
    int pointA_x, pointA_y;
    cin >> pointA_x >> pointA_y;

    // Внеси ги координатите на точката B
    int pointB_x, pointB_y;
    cin >> pointB_x >> pointB_y;

    // Внеси ги координатите на долното лево и горното десно теме на правоаголникот
    int x1, y1, x2, y2;
    cin >> x1 >> y1 >> x2 >> y2;

    // Провери дали точкте A и Б лежат врз или во правоаголникот
    if ((pointA_x >= x1 && pointA_x <= x2 && pointA_y >= y1 && pointA_y <= y2) && (pointB_x >= x1 && pointB_x <= x2 && pointB_y >= y1 && pointB_y <= y2)) {
        cout << "DA" << endl;
    } else {
        cout << "NE" << endl;
    }

    return 0;
}
