#include <iostream>
using namespace std;

int main() {


    int n;
    cin >> n ;

    int zbir = 0;
    int max=0;
    int min = 0;
    float srednaVrednost;
    int brojac=0;

    for (int i; i<=n; i++){

        int broj;
        cin>>broj;
        if (broj > max){
            max = broj;
        }
        if (broj < max){
            min = broj;
        }

        brojac++;
        zbir = zbir + broj;
    }

    cout<<max<<endl;
    cout<<min<<endl;

    srednaVrednost = (float)zbir / brojac;

    cout<<srednaVrednost;

    return 0;
}
