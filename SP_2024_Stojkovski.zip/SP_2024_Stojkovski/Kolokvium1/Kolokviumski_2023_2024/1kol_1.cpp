#include <iostream>
using namespace std;

int main() {
    int n, m, sumpomal = 0, sumpogolem = 0;
    cin >> n >> m;

    if (n <= 0 || m <= 0) {
        cout << "Invalid input" << endl;
    } else {
        if (n > m) {
            while (n) {
                sumpogolem = sumpogolem + n % 10;
                n = n / 10;
            }
            while (m) {
                int cifra = n % 10;
                sumpomal = sumpomal + cifra;
                m = m / 10;
            }
            if (sumpomal == sumpogolem) {
                cout << "ista suma" << endl;
            } else {
                cout << "NE" << endl;
            }
        } else {
            while (m) {
                sumpogolem += m % 10;
                m /= 10;
            }
            while (n) {
                sumpomal += n % 10;
                n /= 10;
            }
            if (sumpomal == sumpogolem) {
                cout << "ista suma" << endl;
            } else {
                cout << "NE" << endl;
            }
        }
    }

    return 0;
}