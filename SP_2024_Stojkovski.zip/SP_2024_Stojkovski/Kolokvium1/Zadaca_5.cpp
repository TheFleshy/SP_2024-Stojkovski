#include <iostream>
using namespace std;
int main (){

    int a, b;
    cin>>a>>b;  // unasame 2 vrednosti
    if (a<=0 || b <= 0){  // uslov ako edna od nih e pomala ili ednakva n 0 odma da pecate invalid input
        cout<<"Invalid input";
        return 0; // isto i tuka som veke se ispecate nesto return 0, za da ne ode i na drugi raboti pa da pecate poveke raboticki
    }

    if (a<b){           //mora a sekogas da e pogolema od b, ako ne e mora da napraeme smena so temp.
        int temp=b;         // temp ja zima vrednosta od pogolemata
        b=a;            //pogolemata ja zima od pomalata
        a = temp;   //pomalata ja zima od temp , so u ovaj slucaj e pogolem
    }

    while (a>0){        //ciklus deka se cepka a
        a = a/10;               // odma a go deleme so 10 i ja trgame poslednata cifra, zatoa so za parnite cifri preku treba da pocne edna ponazad
        if (a % 10 != b% 10){     //uslov ako poslednata cifra od a posle od kako e trgnana poslednata ne e ednavka so poslednata cifra na b .. da pecate NE
            cout<<"NE";
            return 0;       // mora return 0 zatoa so veke brojo ne e paren ekvivalent t.s cifrite od b ne sa na parnite pozicii od a
        }
        else {                  // ako pa poslednata cifra od a posle od kako se trgne poslednata e ednakva so poslednata cifra na b
            a = a/10;               // poslednite cifri na a i b se kratat i se namaluva brojo
            b = b/10;
        }
    }              // cikluso vrte dodeka ne se namalat site cifri na a a so toa ke nema veke cifri so ke se sporeduvat so b
    cout<<"PAREN";   // nadvor od cikluso a>0 pecateme paren , obicno sekogas oti u takov slucaj ke pecate poveke pati dodeka se cepka nekoj broj
    return 0;
}