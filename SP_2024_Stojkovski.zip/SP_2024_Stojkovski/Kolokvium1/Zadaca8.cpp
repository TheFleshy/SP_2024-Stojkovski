#include <iostream>
using namespace std;
int main (){

    int N, X, toBreak ;
    cin>>N>>X;

    for (int i=N-1; i>0; i--){
        int broj=i;
        toBreak = 0;
        while (broj > 0){
            int cifra = broj % 10;
            broj /=10;

            int x = X;
            while (x > 0) {
                int cifraX = x % 10;
                x /= 10;
                if (cifra == cifraX) {
                    toBreak = 1;
                    break;
                }
            }
                if (toBreak == 1){
                    break;
                }
        }
            if (toBreak == 0){
                cout<<i;
                return 0;
            }
    }
    cout<<0;
    return 0;
}