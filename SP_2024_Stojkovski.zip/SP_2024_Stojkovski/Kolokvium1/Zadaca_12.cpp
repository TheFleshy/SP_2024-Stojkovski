#include <iostream>
using namespace std;
int main (){

    int broj;           // mora da se unese broj
    int pozcija0 = 0;   // pravat se 5 pozicii so na pocetoko ke bidat 0, za posle u statistikata da se pecatat
    int pozcija1 = 0;
    int pozcija2 = 0;
    int pozcija3 = 0;
    int pozcija4 = 0;

    while (cin>>broj){          // ciklus dodeka se unasat brojki
        int maxCifra = 0;       // mesto deka se cuva najgolemata cifra
        int pozcija = 0;        //mesto deka se cuva na koja pozicija u sekoj broj se naoga najgomeata cifra
        int temp = broj;        // brojo so se unasa mora da se cepka za da se vide na koja cifra ke bide najgolema

        for (int i=0; i<5 && temp > 0; ++i ){       // ciklus so i go zima kako poziciicka pocnuvajki od 0 do 5.. se godeka brojo so se cepka ne dojde do 0, odma se zgolemuva poziciickata
            int cifra = temp % 10;          // zima se poslednata cifra
            if (cifra > maxCifra){      // ako e pogolema od prvicno najgolemata cifra dodava se
                maxCifra = cifra;       // update se najgolemata cifra ako u ifo dojde do toa deka cepkanata cifra e pogolema od taa so e zacuvana
                pozcija = i;    // pozicija zima na koja poziiciicka (i) od 0 do 5 se e pojavila najgolemata cifra, za posle da ja dodava u glavnite pozicii
            }
            temp /= 10;  // normalno mora da se trgne posledna cifra za da ode na sledna
        }
        if (pozcija == 0)pozcija0++;  // ako najgolemata cifra se e pojavila na pozicija 0, glavnata pozicija0 se zgolemuva
        else if (pozcija == 1)pozcija1++; // ako e na pozicija t.s (i) == 1, zgolemuva se pozicija1
        else if (pozcija == 2)pozcija2++; // ako e na pozicija t.s (i) == 2, zgolemuva se pozicija2
        else if (pozcija == 3)pozcija3++; // ako e na pozicija t.s (i) == 3, zgolemuva se pozicija3
        else if (pozcija == 4)pozcija4++; // ako e na pozicija t.s (i) == 4, zgolemuva se pozicija4
    }

    cout<<"0: "<<pozcija0<<endl;
    cout<<"1: "<<pozcija1<<endl;
    cout<<"2: "<<pozcija2<<endl;        // tuka se pecatat na koja pozcija koku pati se e javila najgolemata cifra
    cout<<"3: "<<pozcija3<<endl;
    cout<<"4: "<<pozcija4<<endl;

    return 0;
}