#include <iostream>
using namespace std;

int main() {
    int m;
    cin>>m;

    for(int i=0; i<m; i++){         //ulava u cikluso dodeka i ne stane = ili pogolem od m
        for(int j=0; j<m; j++){     // ulava u cikluso dodeka j ne stane = ili pogolem od m
            if(i==0 || i==m-1){        //prave go cikluso prvo za j kuga ke izleze od celio taj mene vrednost na i
                if(j==0 || j==m-1){     // ifovite rabotat najprvo ako zadovoluva i , pa posle deka moze za j toa pisa
                    cout<<"%";
                }
                else{
                    cout<<"@";
                }
            }
            else{
                if(j==0 || j==m-1){   // tuka dovaga ako gore if za i ne e zadovolen..
                    cout<<"%";
                }
                else{
                    cout<<".";
                }
            }
        }                               // ako ni eden od ovia ne e zadovolen izlava od for za j, mene vrednost za i.
        cout<<endl;
    }
    return 0;
}
