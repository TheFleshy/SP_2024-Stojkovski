#include <iostream>
using namespace std;
int main (){

    char hex;
    int zbir = 0;

    while (cin>>hex && hex != '.'){

        if (hex >= '0' && hex <= '9'){
            int cifra = hex - '0';
            zbir = zbir + cifra;
        }
        else if (hex >= 'A' && hex <= 'F'){
            int cifra = hex - 'A'+ 10;
            zbir = zbir + cifra;
        }
        else if (hex >= 'a' && hex <= 'f'){
            int cifra = hex - 'a'+10;
            zbir = zbir + cifra;
        }

    }
    if (zbir % 16 == 0 && zbir % 100 == 16){
        cout<<"Poln pogodok";
    }
    else if (zbir % 16 == 0 ){
        cout<<"Pogodok";
    }
    else {
        cout<<zbir;
    }

    return 0;
}