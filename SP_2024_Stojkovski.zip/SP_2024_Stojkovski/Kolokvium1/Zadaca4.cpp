#include <iostream>
using namespace std;

int main() {
    char c;
    int rez=0, broj=0;
    while(cin>>noskipws>>c && c!='!'){
        if(c >= '0' && c <= '9'){
            int cifra = c - '0';
            if(broj == 0){
                broj = cifra;
            }
            else if(broj < 10){
                broj = broj * 10 + cifra;
                rez += broj;
                broj = 0;
            }
        }
        else{
            rez += broj;
            broj = 0;
        }
    }
    if(broj != 0){
        rez += broj;
    }
    cout<<rez;
    return 0;
}
