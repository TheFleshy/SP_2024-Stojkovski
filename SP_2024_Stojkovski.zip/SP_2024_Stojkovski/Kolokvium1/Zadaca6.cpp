#include <iostream>
using namespace std;
int main (){

    int z;
    cin>>z;
    int a,b, zbir, brojac=0, ednakvonaZ=0;
    while (cin>>a && cin>>b){
        if (a==0 && b==0)break;
        zbir = a+b;
        brojac++;
        if (zbir == z){
            ednakvonaZ++;
        }
    }
    float procent;
    if (ednakvonaZ == 0){
        procent = 0;
    }
    else {
        procent = 100/float ((float) brojac / ednakvonaZ);
    }
    cout<<"Vnesovte "<<ednakvonaZ<<" parovi od broevi chij zbir e "<<z<<endl;
    cout<<"Procentot na parovi so zbir "<<z<<" e "<<procent<<"%";
    return 0;
}