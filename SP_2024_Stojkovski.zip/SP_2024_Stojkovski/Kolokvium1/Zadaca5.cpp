#include <iostream>
using namespace std;
int main (){

    int a,b;
    cin>>a>>b;

    if (a<=0 || b<=0){
        cout<<"Invalid input";
    }
    if (a < b){
        int temp = b;
        b=a;
        a=temp;
    }
    while (a > 0){
        a = a/10;
        if (a%10 != b%10){
            cout<<"NE";
            return 0;
        }
        else {
            a = a/10;
            b = b/10;
        }
    }
    cout<<"PAREN";
    return 0;
}