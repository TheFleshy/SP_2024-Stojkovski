#include <iostream>
using namespace std;
int main (){

    int broj, najgolem=0; // deklarirame broj najgolem

    while (cin>>broj){   // dodeka unasame broj

        int Br=broj, zbir = 0;      // deklarirame zbir za brojo so go unesehme gore, Br=broj go koristam kako cuvanje na vrednost
        while (Br > 0){              // Ovaj while mi sluze za opredeluvanje na zbir na cifrite na brojo, dodeka iame vrednosti
            int cifra = Br % 10;        // najde se poslednata cifra od brojo,
            zbir = zbir + cifra;        // zbir na cifri na prv broj // dodavase se poslednata cifra u zbir
            Br /=10;        // poslednata cifra se trga i ispituva naredna cifra ako ima
        }

        zbir = zbir + najgolem;  // dodavame go najgolemio na zbiro osven za prvata oti e 0
        cout << broj<<": "<<zbir<<endl;     // pecate se vnesenio broj i negovio zbir, a zbiro e zbiro na cifrite + najgolemata cifra od prethodnio broj

        int br = broj;
        najgolem = 0;
        while (br > 0){         // u while se naogja najgolemata cifra na unesenio broj
            int cifra = br % 10;
            br = br/ 10;
            if (cifra > najgolem){          // ispituva dali poslednata cifra e pogolema od najgolemio, ako da update
                najgolem = cifra;
            }
        }
    }

    return 0;
}