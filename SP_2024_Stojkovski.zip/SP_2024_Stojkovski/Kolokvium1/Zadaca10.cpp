#include <iostream>
using  namespace  std;

int main() {
    int br, startBr;
    while (cin>>br) {
        startBr = br;
        if (br < 10) continue;
        int znak;

        if (br % 10 > br / 10 % 10) {
            znak = 1;
        } else if (br % 10 < br / 10 % 10) {
            znak = 0;
        } else
            continue;

        while (br > 0) {
            br /= 10;
            if (br < 10) {
                cout << startBr << endl;
                break;
            }
            if (znak) {
                if (br % 10 >= br / 10 % 10) break;
            } else {
                if (br % 10 <= br / 10 % 10) break;
            }
            znak = !znak;
        }
    }

    return 0;
}
