#include <iostream>
using namespace std;
int main (){

    int broj;

    while (cin>>broj && broj!=0){
        int najznacaenBroj=0;
        int najznacajnaCifra=0;
        for (int i=0; i<broj; i++){
            int poedinecniBroevi;
            cin>>poedinecniBroevi;

            int temp = poedinecniBroevi;
            while (temp > 9){
                temp/=10;
            }
            if (temp > najznacajnaCifra){
                najznacajnaCifra = temp;
                najznacaenBroj = poedinecniBroevi;
            }
        }
        cout<<najznacaenBroj<<endl;

    }

    return 0;
}