// Stefan Andonov - kolokviumski/ispitni zadaci

//////////// prva zadaca - unasa se dolzina na niza od prirodni broevi, a potoa i elementite na nizata
// programa koja ke ja preuredi nizata na toj nacin sto site parni broevi ke gi premesti na pocetokot na nizata
// i toa vo redosled na nivno pojavuvanje vo pojdovnata niza, a po niv ke bidat site neparni broevi vo obraten redosled
// na nivnoto pojavuvanje vo pojdovnata niza. Preureduvanjeto na nizata da se realizira so posebna funkcija. Nizata da se ispecati

#include <iostream>
using namespace std;
void transform(int niza[], int n) {
    int tmp[100];
    int j = 0;

    for (int i = 0; i < n; i++) {
        if (niza[i] % 2 == 0) {       // parni broevi
            tmp[j] = niza[i];
            ++j;
        }
    }
    for (int i = n - 1; i >= 0; i--) {
        if (niza[i] % 2 == 1) {    // neparni broevi
            tmp[j] = niza[i];
            ++j;
        }
    }

    for (int i = 0; i < n; i++) {
        niza[i] = tmp[i];
    }
}

int main() {

    int n;
    int niza[100];

    cin >> n;

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    transform(niza, n);

    for (int i = 0; i < n; i++) {
        cout << niza[i] << " ";
    }

    /*
     7
     5 2 7 12 3 5 10

     2 12 10 5 3 7 5
     */

    return 0;
}


/////////// 2ra zadaca - niza od znaci
//
////nizi od znaci sekoja zapisana vo poseben red. Nizite ne se podolgi od 80 znaci.
//// Napisete programa koja sto od tekstot ke gi isfrli site samoglaski(i golemi i mali) i vaka dobieniot tekst ke
//// go ispecati na ekran

#include <iostream>
#include <cstring>
using namespace std;
bool DaliESamoglaska(char bukva) {
    if (bukva == 'a' || bukva == 'A' || bukva == 'e' || bukva == 'E' || bukva == 'i' || bukva == 'I' || bukva == 'o' ||
        bukva == 'O' || bukva == 'u' || bukva == 'U') {
        return true;
    } else return false;

    /*    switch (tolower(bukva)) {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':                   // moze i vaka zatoa e komentirano da ne odat site 5 kako gore, skrateno demek
                return true;
            default:
                return false;
        }
      */
}

int main() {

    char line[81]; // 80 ama +1 za null terminator

    while (cin.getline(line, 81)) {

        for (int i = 0; i < strlen(line); i++) {
            if (!DaliESamoglaska(line[i])) {
                cout << line[i];
            }
        }
        cout << endl;   //getline ne gi prae i praznite redovi zatoa
    }

    // Denes e ubav den a nie polagame

    return 0;
}

////////////// 1 zadaca ispit juni Kolokviumski_2023_2024   - Rekurzija

//// dva broja velime deka se isti ako gi imaat istite cifri na soodvetnite pozicii.
//// Slicnost na broevi se definira kako brojot na isti cifri na soodvetnite pozicii(gledano oddesno-nalevo). Najslicen
//// broj na brojot x e brojot koj ima najmnogu isti cifri na ista pozicija so brojot x (gledano oddesno-nalevo)
//// od tast se vnesuva eden broj x a potoa i nepoznat broj na celi broevi(dodeka ne se vnese nesto sto ne e broj)
//// od vnesenite broevi, da se najde i ispecati brojot koj e najslicen so brojot x. Ako ima poveke broevi koi imaat ista najgolema slicnost, da se ispecate prvio
//// Dokolku broevite imaat razlicen broj na cifri, za visokot cifri od pogolemiot broj treba da se pretpostavi deka se razlicni

#include <iostream>
using namespace std;
int slicnost(int x, int y) {
    if (x == 0 || y == 0) {
        return 0;
    } else {
        if (x % 10 == y % 10) {
            return 1 + slicnost(x / 10, y / 10);
        } else {
            return slicnost(x / 10, y / 10);   // isto kako 0 + toa, za da produze oti ne sa isti
        }
    }
}

int main() {

    int x;
    cin >> x;

    int y;

    int maxSlicnost = 0;
    int maxBroj;

    while (cin >> y) {
        if (slicnost(x, y) >
            maxSlicnost) {  // ako staehme >= tugaj ako imase poveke so ist broj slicnost, da go pecatese posledno najdenio broj
            maxSlicnost = slicnost(x, y);
            maxBroj = y;
        }
    }

    cout << maxBroj;

    return 0;
}


////////// 2 zadaca ispit juni Kolokviumski_2023_2024   - niza od znaci

// Boris cuva telefonski imenik od prijatelite so koi najcesto kontakrial. Za sekoj prijatel, toj vo posebna linija zapisuval
// imeto i prezimeto, domasniot telefonski broj i brojot na mobilniot telefon razdeleni so 1 prazno mesto
// No, bidejki imenikot stanal dosta obemen, Boris imal problem koga sakal da go pronajde domasniot ili brojot na mobilniot telefon na nekoj prijatel
// Vasa zadaca e da help na boris, i da napravete programa koja za  vneseno ime i prezime ke go ispecati telefonskiot broj na prijatelot
// Porgramata treba da pobara od korisnikot da go vnese znakot d dokolku saka da ispecati domasen broj ili m za mobilen
// Dokolku se bara prijatel koj ne postoi da se ispecati "Nema takov zapis" , maks dolzina na niza 80 znaci

// znaci citame kontakti dodeka ne doeme do # , posle birame za koj kontakt i dali da pecate d ili m

#include <iostream>
#include <cstring>
using namespace std;
int main() {

    char kontakti[100][100];

    int golemina = 0;

    while (cin.getline(kontakti[golemina], 100)) {
        if (kontakti[golemina][0] == '#') {
            break;
        }
        cout << kontakti[golemina] << endl;
        ++golemina;
    }

    char kontakt[100];

    cin.getline(kontakt, 100);

    char ured;
    cin >> ured;

    for (int i = 0; i < golemina; i++) {
        if (strstr(kontakti[i], kontakt)) {
            //d - od vtor do tret space
            //m - od tret do kraj na niza
            if (ured == 'd') {
                bool flag = false;
                for (int j = 0; j < strlen(kontakti[i]); j++) {
                    if (isdigit(kontakti[i][j])) {
                        flag = true;
                    }
                    if (isspace(kontakti[i][j]) && flag) {
                        flag = false;
                        break;
                    }
                    if (flag) {
                        cout << kontakti[i][j];
                    }
                }
            } else {
                for (int j = strlen(kontakti[i]) - 1; j >= 0; j--) {
                    if (isspace(kontakti[i][j])) {
                        cout << kontakti[i] + j + 1;
                        break;
                    }
                }
            }
        }
    }
    // umrena zadaca oti e so datoteki i takva nemoze ni baba mu da ja rese... vrska nema komplicirana upm i so matrica od znaci pocnahme
    return 0;
}