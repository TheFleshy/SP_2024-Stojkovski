#include <iostream>
#include <cctype>
using namespace std;
void rekurzivno(char niza[], int x) {

    if (niza[x] == '\0') {
        return;
    }

    if (isalpha(niza[x])) {
        if (islower(niza[x])) {
            niza[x] = ((int) niza[x] + x - 'a') % 26 + 'a';
        } else {
            niza[x] = ((int) niza[x] + x - 'A') % 26 + 'A';
        }
    }
    rekurzivno(niza + 1, x);
}

int main() {

    int n;
    cin >> n;

    int x;
    cin >> x;

    char niza[100];

    cin.ignore();
    for (int i = 0; i < n; i++) {
        cin.getline(niza, 100);

        rekurzivno(niza, x);

        cout << niza << endl;
    }

    return 0;
}