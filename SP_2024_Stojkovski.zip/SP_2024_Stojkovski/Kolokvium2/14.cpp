#include <iostream>
using namespace std;
int main() {

    int n;
    cin >> n;

    int mat[100][100];

    int m = n * 2;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n * 2; j++) {
            cin >> mat[i][j];
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m / 2; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }

    for (int i = 0; i < n; i++) {
        for (int j = n; j < m; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }


    return 0;
}