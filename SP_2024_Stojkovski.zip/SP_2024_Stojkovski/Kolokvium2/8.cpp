#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;
int main() {

    char niza[100];
    char najdolgaNiza[100];
    int najdolgaDolzina = 0;

    int startIndex = 0, endIndex = 0;
    while (cin.getline(niza, 100)) {
        int start = -1, end = 0;
        if (niza[0] == 0) {
            break;
        }
        int brojac = 0;
        for (int i = 0; i < strlen(niza); i++) {
            if (isdigit(niza[i])) {
                brojac++;
                if (start == -1) {
                    start = i;
                }
                end = i;
            }
        }

        if (brojac >= 2 && strlen(niza) >= najdolgaDolzina) {
            najdolgaDolzina = strlen(niza);
            startIndex = start;
            endIndex = end;
            strcpy(najdolgaNiza, niza);
        }
    }
    for (int i = startIndex; i <= endIndex; i++)cout << najdolgaNiza[i];

    return 0;
}