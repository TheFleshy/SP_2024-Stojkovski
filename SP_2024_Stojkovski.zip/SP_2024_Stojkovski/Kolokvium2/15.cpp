#include <iostream>
#include <algorithm>
using namespace std;
int poramnet(int n) {
    if (n < 10) {
        if (n % 10 == 9) {
            return 7;
        }
        return n;
    }

    if (n % 10 == 9) {
        return poramnet(n / 10) * 10 + 7;
    }
    return poramnet(n / 10) * 10 + n % 10;
}

int main() {

    int n;
    int niza[100];

    int brojac = 0;

    while (cin >> n) {
        int b = poramnet(n);
        niza[brojac] = b;
        brojac++;
    }

    sort(niza, niza + brojac);

    if (brojac < 5) {
        for (int i = 0; i < brojac; i++) {
            cout << niza[i] << " ";
        }
        return 0;
    }

    for (int i = 0; i < 5; i++) {
        cout << niza[i] << " ";
    }

    return 0;
}