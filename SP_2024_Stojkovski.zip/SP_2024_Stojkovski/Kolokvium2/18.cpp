#include <iostream>
using namespace std;
int main() {

    int n;
    cin >> n;
    float mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> mat[i][j];
        }
    }

    float x = 0;
    float y = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i > j) {
                x += mat[i][j];
            }
            if (i + j > n - 1) {
                y += mat[i][j];
            }
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == j && i + j == n - 1) {
                mat[i][j] = x + y;
            } else if (i == j) {
                mat[i][j] = x;
            } else if (i + j == n - 1) {
                mat[i][j] = y;
            } else {
                mat[i][j] = 0;
            }
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}