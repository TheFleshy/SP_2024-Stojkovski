// Stefan Andonov - kolokviumski/ispitni zadaci 2-or del ...

/////////// Zmija - slicno na igricka (matrica, nizaznaci) - nogu retardirana zadaca

#include <iostream>
#include <cstring>
using namespace std;
int main() {

    int pole[100][100];

    int i, j;
    int m, n; // golemina na niva
    cin >> m >> n;

    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            pole[i][j] = 0;
        }
    }

    pole[0][0] = 0;

    int appleI, appleJ; // koordinati na jabolko
    cin >> appleI >> appleJ;

    cin.get();  // da se ignorira novio red posle brojkata appleJ

    char komandi[1001];
    cin.getline(komandi, 10001);

    int snakeI = 0, snakeJ = 0;
    int dI = 1, dJ = 0;

    for (i = 0; i < strlen(komandi); i++) {
        char komanda = komandi[i];
        switch (komanda) {
            case 'L':
            case 'R':
                if (dJ == 0) {
                    if (komanda == 'R') {
                        dI *= -1;
                    }
                    swap(dI, dJ);
                } else {  // dj == 1 ili -1
                    if (komanda == 'L') {
                        dJ *= -1;
                    }
                    swap(dI, dJ);
                }
                break;
            case 'F':
                break;
            default:
                cout << "ERROR";
                return 0;
        }
        snakeI += dI;
        snakeJ += dJ;

        if (snakeI == appleI && snakeJ == appleJ) {
            cout << "NJAM";
            return 0;
        }
        if (snakeI < 0 || snakeI >= m || snakeJ < 0 || snakeJ >= m) {
            cout << "GAME OVER Ouch";
            return 0;
        }

        if (pole[snakeI][snakeJ] == 1) {
            cout << "GAME OVER Ouch";
            return 0;
        } else {
            pole[snakeI][snakeJ] = 1;
        }
    }

    cout << "GAMEOVER";


    return 0;
}


////////// 2 - Januarski ispit Kolokviumski_2023_2024
//
//// matrica - Se citaat dimenzii na matrica n,m . Pa sit elementi od matricata. Da se ispecatat elementite od matricata vo sledniot redosled
//// Prvo se pecatat elementite od prva kolona i posledna redica , potoa vtora kolona predposledna redica itn.
//// Zaednickiot element od soodvetnata redica i kolona se pecati samo edns

#include <iostream>
using namespace std;
int main() {

    int m, n;
    int i, j;
    cin >> m >> n;

    int mat[100][100];

    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            cin >> mat[i][j];
        }
    }

    int kolona = 0;
    int kolona_i_end = m - 2;
    int redica = m - 1;
    int kolona_j_start = 0;

    while (redica >= 0 && kolona < n) {
        for (i = 0; i <= kolona_i_end; i++) {
            cout << mat[i][kolona] << " ";
        }
        ++kolona;
        kolona_i_end--;
        for (j = kolona_j_start; j < n; j++) {
            cout << mat[redica][j] << " ";
        }
        redica--;
        kolona_j_start++;
        cout << endl;
    }

    return 0;
}

//// ovaa zadaca mislam aco ja resi polesno, so uste eden ciklus i se namaluva i tugaj pecate nov red n pati oti toku treba da bide i novata
#include <iostream>
using namespace std;
int main() {

    int n, m;
    cin >> n >> m;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    int kolona = 0;
    int red = n - 1;

    int kolona_i_kraj = n - 2;
    int kolona_j_pocetok = 0;

    while (red >= 0 && kolona < m) {
        for (int i = 0; i <= kolona_i_kraj; i++) {
            cout << mat[i][kolona] << " ";
        }
        kolona++;
        kolona_i_kraj--;

        for (int j = kolona_j_pocetok; j < m; j++) {
            cout << mat[red][j] << " ";
        }
        red++;
        kolona_j_pocetok++;
        cout << endl;
    }


    return 0;
}


// istata zadaca kako ovaa prethodno sea samo resenie na aleksandar so e polesno ... barem za svakanje ..
#include <iostream>
using namespace std;
int main() {

    int n, m;
    cin >> n >> m;


    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    int r = n;

    int i;
    for (int j = 0; j < m; j++) {
        for (i = 0; i < r; i++) {
            cout << mat[i][j] << " ";
        }
        for (int k = j + 1; k < m && i > 0; k++) {
            cout << mat[i - 1][k] << " ";
        }
        r--;
        if (r > 0) {
            cout << endl;
        }
    }

    return 0;
}