#include <iostream>
using namespace std;

int factoriel(int n) {
    if (n == 0) {
        return 1;
    }
    return n * factoriel(n - 1);
}

bool daliESilen(int broj) {
    int temp = broj;
    int suma = 0;

    while (temp > 0) {
        int cifra = temp % 10;
        suma += factoriel(cifra);
        temp /= 10;
    }

    return suma == broj;
}

int main() {

    int n;
    cin >> n;

    int niza[100];

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    cout << "Strong numbers: " << endl;
    for (int i = 0; i < n; i++) {
        if (daliESilen(niza[i])) {
            cout << niza[i] << endl;
        }
    }

    return 0;
}