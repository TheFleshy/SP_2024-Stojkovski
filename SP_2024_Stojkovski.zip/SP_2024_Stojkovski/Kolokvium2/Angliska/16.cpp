#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;
void prajGolemi(char zbor[]) {
    int n = strlen(zbor);

    for (int i = 0; i < n; i++) {
        zbor[i] = toupper(zbor[i]);
    }
}

void edenZbor(char zbor[], int &brojac) {
    int n = strlen(zbor);
    bool hex = true;

    for (int i = 0; i < n; i++) {
        if (!isxdigit(zbor[i])) {
            hex = false;
            break;
        }
    }
    if (hex) {
        prajGolemi(zbor);
        cout << zbor << endl;
        ++brojac;
    }

}

int main() {

    char zbor[21];
    bool prazenRed = false;
    int brojac = 0;

    while (cin.getline(zbor, 21)) {

        prazenRed = true;
        for (int i = 0; i < strlen(zbor); i++) {
            if (!isspace(zbor[i])) {
                prazenRed = false;
                break;
            }
        }

        if (!prazenRed) {
            edenZbor(zbor, brojac);
        }
    }

    cout << "Total: " << brojac;


    return 0;
}