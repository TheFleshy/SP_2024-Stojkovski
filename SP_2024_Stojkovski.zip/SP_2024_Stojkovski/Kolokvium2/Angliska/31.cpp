#include <iostream>
#include <cstring>
#include <cctype>
#include <iomanip>
using namespace std;

void posebnaNiza(char niza[], int brojLinija, double &maxRatio, int &najdolgaNizaIndex) {

    int brojGolemi = 0;
    int brojMalenki = 0;

    for (int i = 0; i < strlen(niza); i++) {
        if (islower(niza[i])) {
            brojMalenki++;
        }
        if (isupper(niza[i])) {
            brojGolemi++;
        }
    }
    double ratio = (double) brojGolemi / brojMalenki;

    cout << fixed << setprecision(2) << ratio << " " << niza << endl;

    if (ratio > maxRatio) {
        maxRatio = ratio;
        najdolgaNizaIndex = brojLinija - 1;
    }

}

int main() {

    char niza[100];
    double maxRatio = 0.0;
    int najdolgaNizaIndex = 0;
    int brojLinija = 0;

    while (cin.getline(niza, 100)) {
        brojLinija++;
        posebnaNiza(niza, brojLinija, maxRatio, najdolgaNizaIndex);
    }

    cout << najdolgaNizaIndex << endl;

    return 0;
}
