#include <iostream>
using namespace std;

int main() {

    int n, m;
    cin >> n >> m;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    int najmala = 100;
    int indexNajmala;

    for (int j = 0; j < m; j++) {
        int suma = 0;
        for (int i = 0; i < n; i++) {
            suma += mat[i][j];
        }
        if (suma < najmala) {
            najmala = suma;
            indexNajmala = j;
        }

    }

    cout << indexNajmala;

    return 0;
}










