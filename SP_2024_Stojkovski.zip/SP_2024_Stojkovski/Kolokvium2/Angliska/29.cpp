#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

bool isPalindrome(const char *str) {
    int len = strlen(str);
    for (int i = 0; i < len / 2; ++i) {
        if (tolower(str[i]) != tolower(str[len - 1 - i]))
            return false;
    }
    return true;
}

bool isVowelPalindrome(const char *str) {
    char vowels[] = "aeiou";
    char vowel_str[100];
    int vowel_count = 0;

    for (int i = 0; str[i] != '\0'; ++i) {
        if (strchr(vowels, tolower(str[i]))) {
            vowel_str[vowel_count] = str[i];
            ++vowel_count;
        }
    }
    vowel_str[vowel_count] = '\0';

    return isPalindrome(vowel_str);
}

int main() {
    char niza[100];
    char umrenZbor[] = "WooooSH";

    while (cin.getline(niza, 100)) {
        if (isVowelPalindrome(niza) && strcmp(niza, umrenZbor) != 0) {
            cout << niza << endl;
        }
    }

    return 0;
}
