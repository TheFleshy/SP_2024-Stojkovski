#include <iostream>
using namespace std;
int main() {

    int n, m;
    cin >> n >> m;
    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    int x, y;
    cin >> x >> y;

    if (mat[x][y] == 0) {
        mat[x][y] = 1;

        for (int i = x - 1; i >= 0 && mat[i][y] == 0; i--) {  // gore
            mat[i][y] = 1;
        }

        for (int i = x + 1; i < n && mat[i][y] == 0; i++) {  // dole
            mat[i][y] = 1;
        }

        for (int j = y - 1; j >= 0 && mat[x][j] == 0; j--) {  // levo
            mat[x][j] = 1;
        }

        for (int j = y + 1; j < m && mat[x][j] == 0; j++) {  // desno
            mat[x][j] = 1;
        }

    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
