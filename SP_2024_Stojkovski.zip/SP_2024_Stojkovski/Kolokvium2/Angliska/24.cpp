#include <iostream>
using namespace std;

void proverkaCifri(int niza[], int n) {

    bool najdena = false;

    for (int i = 0; i < n; i++) {
        int broj = niza[i];

        int poslednaCifra = broj % 10;

        while (broj >= 10) {
            broj /= 10;
        }

        int prvaCifra = broj;

        if (prvaCifra % 2 != 0 && poslednaCifra % 2 == 0) {
            cout << niza[i] << endl;
            najdena = true;
        }
    }

    if (!najdena) {
        cout << "No such elements!" << endl;
    }
}

int main() {
    int n;
    cin >> n;

    int niza[100];

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    proverkaCifri(niza, n);

    return 0;
}
