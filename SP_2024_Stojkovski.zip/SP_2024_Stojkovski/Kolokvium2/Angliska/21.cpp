#include <iostream>
using namespace std;

int max(int a, int b) {
    if (a >= b) {
        return a;
    } else {
        return b;
    }
}

int switchElement(int arr[], int n, int i, int zameneti) {
    if (i >= n / 2) {
        return zameneti;
    } else if (arr[i] == arr[n - i - 1]) {
        return switchElement(arr, n, i + 1, zameneti);
    } else {

        int z = max(arr[i], arr[n - i - 1]);

        arr[i] = z;
        arr[n - 1 - i] = z;

        return switchElement(arr, n, i + 1, zameneti + 1);

    }
}

int main() {
    int n;
    cin >> n;
    int niza[n];
    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    cout << switchElement(niza, n, 0, 0) << endl;
    for (int i = 0; i < n; i++) {
        cout << niza[i] << " ";
    }

    return 0;
}

