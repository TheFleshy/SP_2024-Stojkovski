#include <iostream>
using namespace std;

int Odd(int a[], int n) {
    if (n == 0) {
        return 0;
    }

    int brojac = 0;
    int posledenElement = a[n - 1];

    if (posledenElement % 2 != 0) {
        brojac = 1;
    }
    return brojac + Odd(a, n - 1);
}

int main() {

    int n;
    cin >> n;
    int niza[100];

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    cout << Odd(niza, n);

    return 0;
}