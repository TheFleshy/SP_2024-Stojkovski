#include <iostream>
using namespace std;

int brojacCifri(int broj, int c) {

    int brojac = 0;
    int pozicija = 0;

    while (broj > 0) {
        int cifra = broj % 10;
        broj /= 10;

        pozicija++;

        if (pozicija % 2 == 0 && cifra == c) {
            brojac++;
        }
    }
    return brojac;
}

int main() {

    int a, b, c;

    while (cin >> a >> b >> c) {

        int brojacA = brojacCifri(a, c);
        int brojacB = brojacCifri(b, c);

        if (brojacA >= brojacB) {
            cout << a << endl;
        }

        if (brojacB > brojacA) {
            cout << b << endl;
        }
    }

    return 0;
}