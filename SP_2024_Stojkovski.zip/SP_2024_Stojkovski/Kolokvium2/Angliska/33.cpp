#include <iostream>
using namespace std;

int main() {

    float mat[100][100];

    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> mat[i][j];
        }
    }

    for (int j = 0; j < n - 1; j++) {     // pecate prv red bez poslednio elem
        cout << mat[0][j] << " ";
    }

    for (int i = 0; i < n; i++) {       // pecate cela sporedna dijag
        for (int j = 0; j < n; j++) {
            if (i + j == n - 1) {
                cout << mat[i][j] << " ";
            }
        }
    }

    for (int j = 1; j < n; j++) {       // pecate posleden red bez prv elem
        cout << mat[n - 1][j] << " ";
    }

    cout << endl;

    float novaMatirca[100][100];

    for (int j = 1; j < n; j++) {
        novaMatirca[n - 1][j] = mat[0][n - 1 -
                                       j];      // za posleden red bez prv elem zamenuva so elem od prv red u obraten
    }

    for (int j = 0; j < n -
                        1; j++) {                       // za prv red bez posleden elem zamenuva so elem od posleden red u obraten
        novaMatirca[0][j] = mat[n - 1][n - 1 - j];
    }

    for (int i = 0;
         i < n; i++) {                        // zamenuva gi samo elementite na sporednata dijagonala u obraten
        for (int j = 0; j < n; j++) {
            if (i + j == n - 1) {
                novaMatirca[i][j] = mat[j][i];
            }
        }
    }

    for (int i = 0; i <
                    n; i++) {                      // segde deka so imase nuli u novata matrica gi zamenuvase so elem od prvata matrica
        for (int j = 0; j < n; j++) {
            if (novaMatirca[i][j] == 0) {
                novaMatirca[i][j] = mat[i][j];
            }
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << novaMatirca[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}