#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;
int main() {

    char niza[100];

    cin.getline(niza, 100);

    int brojac = 0;
    int firstDigit = -1;
    int secondDigit = -1;

    char n = strlen(niza);
    for (int i = 0; i < n; i++) {
        if (isdigit(niza[i])) {
            brojac++;
            firstDigit = i;
            break;
        }
    }

    for (int j = firstDigit + 1; j < n; j++) {
        if (isdigit(niza[j])) {
            secondDigit = j;
            break;
        }
    }

    if (firstDigit == -1 || secondDigit == -1) {
        if (brojac == 1) {
            for (int i = firstDigit; i < strlen(niza); i++) {
                cout << niza[i];
            }
        } else {
            cout << "No digits" << endl;
        }

    } else {
        for (int i = firstDigit; i <= secondDigit; i++) {
            if (isalnum(niza[i])) {
                cout << niza[i];
            }
        }
    }

    return 0;
}