#include <iostream>
#include <algorithm>
using namespace std;

int parcom(int a) {
    int brojac = 1;
    int temp = a;
    while (temp > 0) {
        if ((temp % 10) % 2 == 0) {
            a += brojac;
        } else if ((temp % 10) % 2 != 0) {
            a -= 1 * brojac;
        }
        brojac *= 10;
        temp /= 10;
    }
    return a;
}

int main() {

    int n;

    int najgolemiBroevi[5] = {};
    int counter = 0;

    while (cin >> n) {
        if (counter < 5) {
            najgolemiBroevi[counter] = parcom(n);
            counter++;
            sort(najgolemiBroevi, najgolemiBroevi + counter);
        } else {
            if (parcom(n) < najgolemiBroevi[counter - 1]) {
                najgolemiBroevi[counter - 1] = parcom(n);
            }
            sort(najgolemiBroevi, najgolemiBroevi + counter);
        }

    }

    for (int i = 0; i < counter; i++) {
        cout << najgolemiBroevi[i] << " ";
    }

    return 0;
}
