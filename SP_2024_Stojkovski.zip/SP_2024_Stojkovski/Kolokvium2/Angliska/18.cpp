#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;
int main() {

    char niza[100];
    char krajnaNiza[100];

    double MaxRatio = -1;

    int n = strlen(niza);

    while (cin.getline(niza, 100)) {
        int bukvi = 0;
        int broevi = 0;

        for (int i = 0; i < n; i++) {
            if (isalpha(niza[i])) {
                bukvi++;
            }

            if (isdigit(niza[i])) {
                broevi++;
            }
        }

        if (bukvi > 0) {
            double momentalnoRatio = broevi / (double) bukvi;

            if (momentalnoRatio >= MaxRatio) {
                MaxRatio = momentalnoRatio;
                strcpy(krajnaNiza, niza);
            }
        }
    }
    cout << krajnaNiza << endl;

    return 0;
}







//#include <iostream>
//#include <cstring>
//#include <cctype>
//using namespace std;
//
//int main() {
//    char line[101];
//    char maxRatioLine[101];
//    double maxRatio = -1;
//
//    while (cin.getline(line, 101)) {
//        int letters = 0;
//        int digits = 0;
//
//        for (int i = 0; i < strlen(line); i++) {
//            if (isalpha(line[i])) {
//                letters++;
//            } else if (isdigit(line[i])) {
//                digits++;
//            }
//        }
//
//        if (letters > 0) {
//            double currentRatio = digits / (double) letters;
//
//            if (currentRatio >= maxRatio) {
//                maxRatio = currentRatio;
//                strcpy(maxRatioLine, line);
//            }
//        }
//    }
//
//    cout << maxRatioLine << endl;
//
//    return 0;
//}
