#include <iostream>
#include <cctype>
using namespace std;

void transform(char *niza, int x) {
    if (*niza == '\0') {
        return;
    }

    if (isalpha(*niza)) {
        if (islower(*niza)) {
            *niza = ((int) *niza + x - 'a') % 26 + 'a';
        } else {
            *niza = ((int) *niza + x - 'A') % 26 + 'A';
        }
    }
    transform(niza + 1, x);
}

int main() {

    int n;
    cin >> n;

    int x;
    cin >> x;

    char niza[100];

    cin.ignore();
    for (int i = 0; i < n; i++) {
        cin.getline(niza, 100);

        transform(niza, x);

        cout << niza << endl;
    }

    return 0;
}