#include <iostream>
using namespace std;

int main() {

    int n, m;
    cin >> n >> m;
    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    int brojac = 0;
    for (int i = 0; i < n; i++) {
        int posledovatelni = 0;

        for (int j = 0; j < m; j++) {
            if (mat[i][j] == 1) {
                posledovatelni++;
                if (posledovatelni >= 3) {
                    brojac++;
                    break;
                }
            } else {
                posledovatelni = 0;
            }
        }
    }

    for (int j = 0; j < m; j++) {
        int posledovatelni = 0;

        for (int i = 0; i < n; i++) {
            if (mat[i][j] == 1) {
                posledovatelni++;
                if (posledovatelni >= 3) {
                    brojac++;
                    break;
                }
            } else {
                posledovatelni = 0;
            }
        }
    }

    cout << brojac << endl;

    return 0;
}
