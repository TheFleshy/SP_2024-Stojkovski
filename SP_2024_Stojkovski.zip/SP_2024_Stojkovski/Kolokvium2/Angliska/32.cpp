#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

int main() {
    char word[21];
    char najdolgZbor[21];
    int najgolemBrojac = -1;

    while (cin.getline(word, 21)) {
        int n = strlen(word);
        int brojac = 0;

        for (int i = 0; i < n - 1; i++) {
            if (isalpha(word[i])) {
                if (tolower(word[i]) != tolower(word[i + 1])) {
                    brojac++;
                }
            }
        }

        if (brojac >= 4 && brojac >= najgolemBrojac) {
            najgolemBrojac = brojac;
            strcpy(najdolgZbor, word);
        }
    }

    cout << najdolgZbor << endl;


    return 0;
}




