#include <iostream>
using namespace std;

int kratena(int broj, int k) {

    int rezultat = 0;
    int mnozitel = 1;

    while (broj > 0) {
        int cifra = broj % 10;
        broj /= 10;

        if (cifra > k) {
            rezultat += cifra * mnozitel;
            mnozitel *= 10;
        }
    }
    return rezultat;
}

int najgolemElement(int niza[], int n) {
    int najgolem = 0;
    for (int i = 0; i < n; i++) {
        if (niza[i] > najgolem) {
            najgolem = niza[i];
        }
    }
    return najgolem;
}

int main() {

    int n;
    cin >> n;
    int niza[100];

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    int k;
    cin >> k;

    int novaNiza[100];
    for (int i = 0; i < n; i++) {
        novaNiza[i] = kratena(niza[i], k);
    }

//    int najgolem = 0;
//    for (int i=0; i<n; i++){
//        if (novaNiza[i] > najgolem){
//            najgolem = novaNiza[i];
//        }
//    }
//
//    cout<<najgolem;

    cout << najgolemElement(novaNiza, n);


    return 0;
}



// SAM JA RESIH OMG