#include <iostream>
#include <cmath>
using namespace std;

int main() {

    int n, m;
    cin >> n >> m;
    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    if (n % 2 != 0) {
        int sreden = n / 2;
        for (int j = 0; j < m; j++) {
//            mat[sreden][j] = 0;

            int suma1 = 0;
            int suma2 = 0;
            for (int i = 0; i < sreden; i++) {
                suma1 += mat[i][j];
            }
            for (int i = sreden + 1; i < n; i++) {
                suma2 += mat[i][j];
            }
            int razlika = abs(suma1 - suma2);

            mat[sreden][j] = razlika;
        }
    } else {
        int prvSreden = n / 2 - 1;
        int vtorSreden = n / 2;

        for (int j = 0; j < m; j++) {

            int suma1 = 0;
            int suma2 = 0;
            for (int i = 0; i <= prvSreden; i++) {
                suma1 += mat[i][j];
            }
            for (int i = vtorSreden; i < n; i++) {
                suma2 += mat[i][j];
            }
            int razlika = abs(suma1 - suma2);

            mat[prvSreden][j] = razlika;
            mat[vtorSreden][j] = razlika;
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }


    return 0;
}