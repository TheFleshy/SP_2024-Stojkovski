#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

void transform(char *niza) {
    for (int i = 0; i < strlen(niza); i++) {
        if (isalpha(niza[i])) {
            if (islower(niza[i])) {
                niza[i] = 'a' + (niza[i] - 'a' + 3) % 26;
            } else {
                niza[i] = 'a' + (niza[i] - 'A' + 3) % 26;
            }
        }
    }
}

int main() {

    char niza[100];
    while (cin.getline(niza, 100)) {
        transform(niza);

        cout << niza << endl;
    }

    return 0;
}
