#include <iostream>
using namespace std;
int main() {

    int n;
    cin >> n;

    int niza[100];
    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    for (int i = 0; i < n - 1; i++) {
        if (niza[i] == niza[i + 1]) {
            niza[i] *= 2;
            niza[i + 1] = 0;
            i++;
        }
    }

    int korekcija = 0;
    for (int i = 0; i < n; i++) {
        if (niza[i] != 0) {
            niza[korekcija++] = niza[i];
        }
    }
    for (int i = korekcija; i < n; i++) {
        niza[i] = 0;
    }

    for (int i = 0; i < n; i++) {
        cout << niza[i] << " ";
    }


    return 0;
}