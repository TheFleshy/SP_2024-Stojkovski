#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;
int main() {
    char niza[10000];

    while (cin.getline(niza, 10000)) {
        int n = strlen(niza);
        bool prethodenESpace = false;

        for (int i = 0; i < n; i++) {
            if (isalpha(niza[i])) {
                cout << niza[i];
                prethodenESpace = false;
            } else if (isspace(niza[i]) && niza[i] != '\n') {
                if (!prethodenESpace) {
                    cout << endl;
                    cin.get();
                    prethodenESpace = true;
                }
            }
        }
        cout << endl;
    }

    return 0;
}


#include <iostream>
#include <cstring>
#include <cctype>

using namespace std;

int main() {
    char niza[10000];

    while (cin.getline(niza, 10000)) {
        int n = strlen(niza);
        char word[81];
        int wordLength = 0;

        for (int i = 0; i < n; i++) {
            if (isalpha(niza[i])) {
                word[wordLength++] = niza[i];
            } else if (isspace(niza[i])) {
                if (wordLength > 0) {
                    word[wordLength] = '\0';
                    cout << word << endl;
                    wordLength = 0;
                }
            }
        }

        if (wordLength > 0) {
            word[wordLength] = '\0';
            cout << word << endl;
        }
    }

    return 0;
}
