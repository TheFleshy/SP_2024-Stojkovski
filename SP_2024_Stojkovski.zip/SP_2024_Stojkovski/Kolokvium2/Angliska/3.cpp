#include <iostream>
using namespace std;
int pojavuvanjeCifra(int broj, int cifra) {
    if (broj == 0) {
        return 0;
    }
    if (broj % 10 == cifra) {
        return 1 + pojavuvanjeCifra(broj / 10, cifra);
    }
    return pojavuvanjeCifra(broj / 10, cifra);
}

int main() {

    int niza[100];
    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    for (int i = 0; i < n; i++) {
        int poslednaCifra = niza[i] % 10;
        niza[i] = pojavuvanjeCifra(niza[i], poslednaCifra);
    }

    for (int i = 0; i < n; i++) {
        cout << niza[i] << " ";
    }

    return 0;
}