#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;

    int niza[n];
    for (int i = 0; i < n; ++i) {
        cin >> niza[i];
    }

    int maxBrojac1 = 0, maxBrojac2 = 0;
    int prvNajcest, vtorNajcest;

    for (int i = 0; i < n; ++i) {
        int brojac = 1;
        for (int j = i + 1; j < n; ++j) {
            if (niza[i] == niza[j]) {
                brojac++;
            }
        }
        if (brojac > maxBrojac1) {
            maxBrojac2 = maxBrojac1;
            vtorNajcest = prvNajcest;
            maxBrojac1 = brojac;
            prvNajcest = niza[i];
        } else if (brojac > maxBrojac2 && niza[i] != prvNajcest) {
            maxBrojac2 = brojac;
            vtorNajcest = niza[i];
        }
    }

    int pomal, pogolem;
    if (prvNajcest < vtorNajcest) {
        pomal = prvNajcest;
        pogolem = vtorNajcest;
    } else {
        pomal = vtorNajcest;
        pogolem = prvNajcest;
    }

    for (int i = 0; i < pomal; i++) {
        for (int j = 0; j < pogolem; j++) {
            cout << "*" << " ";
        }
        cout << endl;
    }

    return 0;
}
