#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

void zaNizaPosebno(char niza[]) {
    int n = strlen(niza);

    int nizaBroevi[100];
    int brojBroevi = 0;

    int currentNumber = 0;

    for (int i = 0; i < n; i++) {
        if (isdigit(niza[i])) {
            currentNumber = currentNumber * 10 + (niza[i] - '0');
        } else {
            if (currentNumber != 0) {
                nizaBroevi[brojBroevi++] = currentNumber;
                currentNumber = 0;
            }
        }
    }

    if (currentNumber != 0) {
        nizaBroevi[brojBroevi++] = currentNumber;
    }

    for (int i = 0; i < n; i++) {
        if (isalpha(niza[i])) {
            cout << niza[i];
        }
    }

    if (brojBroevi == 0) {
        cout << "0" << endl;
    } else {
        int suma = 0;
        for (int i = 0; i < brojBroevi; i++) {
            suma += nizaBroevi[i];
        }
        cout << suma << endl;
    }
}

int main() {
    char niza[100];

    while (cin.getline(niza, 100)) {
        zaNizaPosebno(niza);
    }

    return 0;
}
