#include <iostream>
using namespace std;
int main() {

    int n;
    cin >> n;

    int mat[100][100], final[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> mat[i][j];
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            final[i][j] = -1;
        }
    }


    for (int i = 0; i < n; i++) {
        int sumDiagonal = 0;

        for (int x = i - 1; x >= 0; x--) {
            sumDiagonal += mat[x][i];
        }

        for (int x = i + 1; x < n; x++) {
            sumDiagonal += mat[i][x];
        }

        final[i][i] = sumDiagonal;
    }

    for (int i = 0; i < n; i++) {

        int sporedna = 0;
        if (n % 2 && i == n / 2)
            sporedna = final[i][i];

        for (int x = 0; x < n - 1 - i; x++) {
            sporedna += mat[i][x];
        }

        for (int x = i + 1; x < n; x++) {
            sporedna += mat[x][n - 1 - i];
        }
        final[i][n - i - 1] = sporedna;
    }

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) {
            if (final[i][j] == -1)
                final[i][j] = mat[i][j];
        }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << final[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}