#include <iostream>
using namespace std;

int main() {

    int n, m;
    cin >> n >> m;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    bool nemaBroj = false;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            bool eden = true;

            for (int k = 0; k < m; k++) {
                if (k != j && mat[i][k] == mat[i][j]) {
                    eden = false;
                    break;
                }
            }

            if (eden) {
                cout << mat[i][j] << " ";
                nemaBroj = true;
            }
        }
    }
    if (!nemaBroj) cout << "N";

    return 0;
}