#include <iostream>
using namespace std;

int main() {

    int n;
    cin >> n;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> mat[i][j];
        }
    }

    int matB[100][100];
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int brojac = 0;

            if (i > 0 && mat[i - 1][j] == 1) {
                brojac++;
            }

            if (i < n - 1 && mat[i + 1][j] == 1) {
                brojac++;
            }

            if (j > 0 && mat[i][j - 1] == 1) {
                brojac++;
            }

            if (j < n - 1 && mat[i][j + 1] == 1) {
                brojac++;
            }

            if (mat[i][j] == 0 && brojac >= 3) {
                matB[i][j] = 1;
            } else {
                matB[i][j] = mat[i][j];
            }
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << matB[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}