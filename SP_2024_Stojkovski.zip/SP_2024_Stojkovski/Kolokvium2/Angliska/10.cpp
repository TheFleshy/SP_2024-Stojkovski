#include <iostream>
using namespace std;
int main() {

    int n, m;
    cin >> n >> m;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }


    int nova[100][100];
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            int zbir = 0;

            if (i - 1 >= 0 && mat[i - 1][j] > 0) {   // nad
                zbir += mat[i - 1][j];
            }

            if (i + 1 < n && mat[i + 1][j] > 0) {   // pod
                zbir += mat[i + 1][j];
            }

            if (j - 1 >= 0 && mat[i][j - 1] > 0) {  // levo
                zbir += mat[i][j - 1];
            }

            if (j + 1 < m && mat[i][j + 1] > 0) {  // desno
                zbir += mat[i][j + 1];
            }
            nova[i][j] = zbir;
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cout << nova[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}


