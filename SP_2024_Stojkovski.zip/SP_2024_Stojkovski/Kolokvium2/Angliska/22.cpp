#include <iostream>
using namespace std;

void printNumbers(int start, int end) {
    if (start > end) {
        return;
    }

    cout << start;
    printNumbers(start + 1, end);
}

void printTriangle(int n, int current) {
    if (current > n) {
        return;
    }

    printNumbers(1, current);
    cout << endl;

    printTriangle(n, current + 1);
}

void triangle(int n) {
    printTriangle(n, 1);
}

int main() {
    int n;
    cin >> n;
    triangle(n);

    return 0;
}