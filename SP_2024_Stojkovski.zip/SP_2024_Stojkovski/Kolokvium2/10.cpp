#include <iostream>
#include <cstring>
using namespace std;
int main() {

    char z1, z2;
    cin >> z1 >> z2;

    char niza[100];

    cin.ignore();

    while (cin.getline(niza, 100)) {

        int startIndex = 0, endIndex = 0;

        if (niza[0] == '#') {
            break;
        }

        for (int i = 0; i < strlen(niza); i++) {
            if (niza[i] == z1) {
                startIndex = i;
            } else if (niza[i] == z2) {
                endIndex = i;
            }
        }

        for (int j = startIndex + 1; j < endIndex; j++) {
            cout << niza[j];
        }
        cout << endl;
    }


    return 0;
}