//// Snimki Stefan Andonov - kolokvium Kolokviumski_2023_2024

// matrici - aud - sumaParniRedici , sumaNeparniKoloni
#include <iostream>
using namespace std;
int main() {

    int mat[100][100];
    int i, j;
    int m, n;

    cin >> m >> n;

    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            cin >> mat[i][j];
        }
    }

    int sumaParniRedici = 0, sumaNeparniKoloni = 0;

    // za iteriranje niz site elementi vo matricata
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            if (i % 2 == 1) { // abe ti na parna redica le si ?
                sumaParniRedici += mat[i][j];   // ke gi sobira site elem so sa u parna redica
            }
            if (j % 2 == 0) { // abe ti na neparna kolona le si ?
                sumaNeparniKoloni += mat[i][j];   // ke gi sobira site elem so sa u neparna kolona
            }
        }
    }

    cout<<sumaParniRedici<<endl;
    cout<<sumaNeparniKoloni<<endl;

    /*
     3 3
     1 2 3
     1 2 3             2+2+2 = 6
     1 2 3             1+1+1 + 3+3+3 = 12
     6
     12
     */

    return 0;
}


// za matrica ke gi zameni elementite od glavnata dijagonala so razlikata od maks i min elem vo matricata
// rezultanta matrica da se ispecate na ekran ..
#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;

    int mat[100][100];
    int i,j;

    for (i=0; i<n; i++){
        for (j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    int maks, min;
    min = maks = mat[0][0];

    for (i=0; i<n; i++){
        for (j=0; j<n; j++){
            if (mat[i][j] > maks){  // naoganje na maks
                maks = mat[i][j];
            }
            if (mat[i][j] < min){  // naogjanje na min
                min = mat[i][j];
            }
        }
    }

    int razlika = maks-min;

    for (i=0; i<n; i++){
        for (j=0; j<n; j++){
            if (i==j){
                mat[i][j] = razlika;
            }
        }
    }

    for (i=0; i<n; i++){
        for (j=0; j<n; j++){
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}

// za kvadratna matrica ke ispecati na ekran dali taa e simetricna vo odnos na glavnata dijagonala
#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;
    int mat[100][100];
    int i,j;
    for (i=0; i<n; i++){
        for (j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    bool simetircna=true;

    for (i=0; i<n; i++){
        for (j=0; j<n; j++){
            if (mat[i][j] != mat[j][i]){
                cout<<"Asimetricna";
                return 0;
            }

        }
    }

    cout<<"Simetricna"<<endl;


    return 0;
}


// matrica so nemora da bide kvadratna , da se najdat pluscinja ,
// ako site elementi u pluso sa kecovi dali moze da se formira i da se napisa koku plusovi ke ima, da ne se preklopuvaat
#include <iostream>
using namespace std;
int main (){

    int mat[100][100];
    int mines[100][100];
    int m,n;
    cin>>m>>n;
    int i,j;
    for (i=0; i<m; i++){
        for (j=0; j<n; j++){
            cin>>mat[i][j];
            mines[i][j] = 0;
        }
    }

    int brojacPlusovi = 0;

    for (i=1; i<m-1; i++){
        for (j=1; j<n-1;j++){
            if (mat[i][j] == 1 &&
            mat[i][j-1] == 1 &&
            mat[i][j+1] == 1 &&
            mat[i-1][j] == 1 &&
            mat[i+1][j] == 1){
                if (mines[i][j] != 1 &&
                    mines[i][j-1] != 1 &&
                    mines[i][j+1] != 1 &&
                    mines[i-1][j] != 1 &&
                    mines[i+1][j] != 1){

                    brojacPlusovi++;
                    mines[i][j] = mines[i][j-1] = mines[i][j+1] = mines[i-1][j] = mines[i+1][j] = 1;
                }
            }
        }
    }

    cout<<brojacPlusovi<<endl;

    return 0;
}


// 6. za pocetok od niza od znaci - auditoriska so password
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;
bool DaliEValidna(char password[]) {
    if (strlen(password) < 8) {
        return false;
    }

    // 1 bukva, 1 cifra, 1 spec znak

    int bukvi = 0, cifri = 0, spec = 0;
    for (int i = 0; i < strlen(password); i++) {
        if (isalpha(password[i])) {
            bukvi++;
        }
        if (isdigit(password[i])) {
            cifri++;
        }
        if (!isalnum(password[i]) && !isspace(password[i])) {   // da ne e bukva ili broj, ke bide spec znak :)
            spec++;
        }
    }
    return bukvi > 0 && cifri > 0 && spec > 0;
}

int main() {

    char pass[100];
    cin.getline(pass, 100);

    cout<<DaliEValidna(pass);

    return 0;
}


// zad 8 - od aud za niza od znaci - au mau

#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

void trim(char niza[]){

    int startIndex = -1;
    for (int i=0; i< strlen(niza); i++){
        if (!isspace(niza[i])){
            startIndex = i;
            break;
        }
    }
    strcpy(niza, niza+startIndex);

    for(int i= strlen(niza)-1; i>=0; i--){
        if (!isspace(niza[i])){
            niza[i+1] = '\0';
            break;
        }
    }

}

int main (){

    char niza[100];
    cin.getline(niza, 100);

    trim(niza);

    cout<<niza;

    return 0;
}


// brebaruvanje na elementi - toa go ima i kaj aco , ama aj da videme so ke kaze stefan
// linearno prebaruvanje
#include <iostream>
using namespace std;

int linearSerch (int niza[], int n, int element){
    for (int i=0; i<n; i++){
        if (niza[i] == element){
            return i;
        }
    }
    return -1;     // oti elemento ne e najden u nizata
}

int BinarySerch (int niza[], int n, int element){
    int pocetok = 0;
    int kraj = n-1;

    while(pocetok<kraj){                 // se dodeka pocetoko e pomal od krajo
        int sreden = (pocetok+kraj)/2;
        if (niza[sreden] == element){         // ako elemento e srednio vraka go nego
            return sreden;
        }
        else if (element > niza[sreden]){      // ako elemento e posle sredinata
            pocetok = sreden;                // pocetoko pocnuva od sredinata do krajo
        }
        else{                 // ako pa e pred sredinata elemento, krajo zavrsuva do sredinata
            kraj = sreden;
        }
    }
    return -1;   // ako ne e najden elemento vraka -1
}

int main (){

    int niza[100];

    int golemina;
    cin>>golemina;

    for (int i=0; i<golemina; i++){
        cin>>niza[i];
    }

    int element;
    cin>>element;

    cout<<BinarySerch(niza, golemina, element);
    /*
        7
        1 8 7 5 2 200 7     - oti krenuva od 0
        200
        5
     */

    // za binarno prebravuanje mora da bidat podredeni nizite !!
    // binarnoto dele na dva i sporeduva dali e tam pa dele i se taka

    return 0;
}