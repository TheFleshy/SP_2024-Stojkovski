#include <iostream>

using namespace std;

int main() {

    int n, m;
    cin >> n >> m;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    int indexI;
    int indexJ;
    cin >> indexI >> indexJ;

    int sum1 = 0, suma2 = 0, suma3 = 0, suma4 = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (i < indexI && j < indexJ) {
                suma2 += mat[i][j];
            } else if (i < indexI && j >= indexJ) {
                sum1 += mat[i][j];
            } else if (i >= indexI && j < indexJ) {
                suma3 += mat[i][j];
            } else if (i >= indexI && j >= indexJ) {
                suma4 += mat[i][j];
            }
        }
    }

    cout << sum1 << " " << suma2 << " " << suma3 << " " << suma4;

    return 0;
}