#include <iostream>
using namespace std;
int brojPozitivni(int niza[], int n) {

    if (n == 0) {
        if (niza[n] > 0) {   // tuka mora i edns da provere dali i poslednio e pozitiven pa da vrne i za nego 1
            return 1;
        }
        return 0;  // tmn si bese ako dojde do 0 da zavrse ama nema da go broe poslednoto
    }

    if (niza[n] > 0) {
        return 1 + brojPozitivni(niza, n - 1);
    }
    return 0 + brojPozitivni(niza, n - 1);

}

int main() {

    int niza[100];

    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    cout << brojPozitivni(niza, n - 1);

    return 0;
}