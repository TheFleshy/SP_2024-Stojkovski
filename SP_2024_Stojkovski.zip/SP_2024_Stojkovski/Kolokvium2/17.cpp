#include <iostream>
#include <cmath>
using namespace std;
int main() {

    int n, m;
    cin >> n >> m;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    if (m % 2 != 0) {  // za neparen broj koloni

        for (int i = 0; i < n; i++) {
            int suma1 = 0;
            int suma2 = 0;

            for (int j = 0; j < m / 2; j++) {
                suma1 += mat[i][j];
            }

            for (int j = m / 2 + 1; j < m; j++) {
                suma2 += mat[i][j];
            }

            int razlika = abs(suma1 - suma2);
            int sreden = m / 2;

            mat[i][sreden] = razlika;
        }
    } else if (m % 2 == 0) {    // paren broj koloni
        for (int i = 0; i < n; i++) {
            int suma1 = 0;
            int suma2 = 0;

            for (int j = 0; j < m / 2; j++) {
                suma1 += mat[i][j];
            }

            for (int j = m / 2; j < m; j++) {
                suma2 += mat[i][j];
            }

            int razlika = abs(suma1 - suma2);
            int prvSreden = m / 2;
            int vtorSreden = (m / 2) - 1;

            mat[i][prvSreden] = razlika;
            mat[i][vtorSreden] = razlika;
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}

