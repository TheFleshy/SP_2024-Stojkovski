#include <iostream>
using namespace std;
int main() {

    int x;
    cin >> x;
    int n, m;
    cin >> n >> m;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    for (int i = 0; i < n; i++) {
        int zbir = 0;
        for (int j = 0; j < m; j++) {
            zbir += mat[i][j];
        }

        for (int j = 0; j < m; j++) {
            if (zbir > x) {
                mat[i][j] = 1;
            } else if (zbir < x) {
                mat[i][j] = -1;
            } else if (zbir == x) {
                mat[i][j] = 0;
            }
        }

    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}