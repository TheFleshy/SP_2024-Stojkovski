#include <iostream>
#include <cstring>

using namespace std;

int main() {

    int uplata;
    cin >> uplata;

    char sifra[100], tip[5];
    float koef;
    float maks, vkupen = 1;
    char tipMax[5];
    char sifraMax[100];
    while (1) {
        cin >> sifra;
        if (sifra[0] == '#') {
            break;
        }
        cin >> tip;
        cin >> koef;

        if (koef > maks) {
            maks = koef;
            strcpy(tipMax, tip);
            strcpy(sifraMax, sifra);
        }
        vkupen *= koef;

    }

    cout << sifraMax << " " << tipMax << " " << maks << endl << vkupen * uplata << endl;

    return 0;
}


