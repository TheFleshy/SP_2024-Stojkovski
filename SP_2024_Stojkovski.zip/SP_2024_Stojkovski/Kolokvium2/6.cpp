#include <iostream>
using namespace std;

int main() {

    int n, m;
    cin >> n >> m;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    int redoviKecovi = 0;
    int koloniKecovi = 0;

    for (int i = 0; i < n; i++) {
        int brojac = 0;
        for (int j = 0; j < m; j++) {
            if (mat[i][j] == 1) {
                brojac++;
                if (brojac >= 3) {
                    redoviKecovi++;
                    break;
                }
            } else {
                brojac = 0;
            }
        }
    }

    for (int j = 0; j < m; j++) {
        int brojac = 0;
        for (int i = 0; i < n; i++) {
            if (mat[i][j] == 1) {
                brojac++;
                if (brojac >= 3) {
                    koloniKecovi++;
                    break;
                }
            } else {
                brojac = 0;
            }
        }
    }

    int vkupno = redoviKecovi + koloniKecovi;

    cout << vkupno << endl;

    return 0;
}