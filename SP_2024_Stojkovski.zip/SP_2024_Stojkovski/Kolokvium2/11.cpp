#include <iostream>
#include <algorithm>
#include <cstring>
#include <cctype>
using namespace std;
int main() {

    char niza[100];

    while (cin.getline(niza, 100)) {
        if (niza[0] == '#') {
            break;
        }

        int brojac = 0;

        for (int i = 0; i < strlen(niza); i++) {
            if (isdigit(niza[i])) {
                brojac++;
            }
        }

        cout << brojac << ":";

        int n = 0;

        for (int j = 0; j < strlen(niza); j++) {
            if (isdigit(niza[j])) {
                niza[n] = niza[j];
                n++;
            }
        }

        niza[n] = '\0';

        sort(niza, niza + n);

        cout << niza << endl;

    }

    return 0;
}



/*
int n = 0;         // zamena za podniza

for (int j=0; j< strlen(niza); j++){             // ode do krajo na nizata
    if (isdigit(niza[j])){              // moze da zeme samo brojki, drug slucaj samo bukvi pa da im prae golemi malenki
    niza[n] = niza[j];              // i sea dodava gi samo tia so gi najde u ovaa kako podniza
    n++;                            // samo se zgolemuva da osloboduva mesta
   }
}

niza[n] = '\0';             // na krajo samo da naprae e sea tuka ke ti e nultio i nizata e popunena mozes samo da ja pecates.

*/


