#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

int main (){

    char niza[100];

    int brojac = 0;
    while (cin.getline(niza,100)) {

            if (niza[0] == '#') {
                break;
            }

            int n = strlen(niza);
            for (int i = 0; i < n-1; i++) {
                char prva = tolower(niza[i]);
                char vtora = tolower(niza[i+1]);

                if (prva == 'a' || prva == 'e' || prva == 'i' || prva == 'o' || prva == 'u') {
                    if (vtora == 'a' || vtora == 'e' || vtora == 'i' || vtora == 'o' || vtora == 'u') {
                        cout << prva << vtora << endl;
                        brojac++;
                    }
                }
            }
    }
    cout<<brojac;

    return 0;
}