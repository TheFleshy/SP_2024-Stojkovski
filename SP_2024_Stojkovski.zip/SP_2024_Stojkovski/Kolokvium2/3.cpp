#include <iostream>
using namespace std;

void sum_pos (int *niza, int ind, int n){
    if (ind > n){
        cout<< 0;
    }
    int sum = 0;
    for (int i=ind; i<n; i++){
        sum += niza[i];
    }

    cout<<sum;

}

int main (){

    int n;
    cin>>n;
    int niza [100];
    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    int ind ;
    cin>>ind;

    sum_pos(niza, ind, n);

    return 0;
}