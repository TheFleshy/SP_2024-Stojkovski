#include <iostream>
#include <cstring>
using namespace std;
int main() {
    int n;
    cin >> n;
    char matrica[50][50];
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) cin >> matrica[i][j];

    char zbor[10];
    cin >> zbor;
    int dolzinaZbor = strlen(zbor);

    bool najdeno = false;
    int x, y, x1, y1;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (matrica[i][j] == zbor[0]) {
                //na desno
                for (int start = 0; start < dolzinaZbor; start++) {
                    if (matrica[i][start + j] != zbor[start]) {   // mozda ke mi treba nekoj bool
                        najdeno = false;
                        break;
                    } else najdeno = true;
                }
                if (najdeno) {
                    x = i;
                    y = j;
                    x1 = i;
                    y1 = j + dolzinaZbor - 1;
                    cout << x << ", " << y << " -> " << x1 << ", " << y1;
                    return 0;
                }

                //na levo
                for (int start = 0; start < dolzinaZbor; start++) {
                    if (matrica[i][j - start] != zbor[start]) {
                        najdeno = false;
                        break;
                    } else najdeno = true;
                }
                if (najdeno) {
                    x = i;
                    y = j;
                    x1 = i;
                    y1 = j - dolzinaZbor - 1;
                    cout << x << ", " << y << " -> " << x1 << ", " << y1;
                    return 0;
                }

                //na dole
                for (int start = 0; start < dolzinaZbor; start++) {
                    if (matrica[i + start][j] != zbor[start]) {
                        najdeno = false;
                        break;
                    } else najdeno = true;
                }
                if (najdeno) {
                    x = i;
                    y = j;
                    x1 = i + dolzinaZbor - 1;
                    y1 = j;
                    cout << x << ", " << y << " -> " << x1 << ", " << y1;
                    return 0;
                }

                //na gore
                for (int start = 0; start < dolzinaZbor; start++) {
                    if (matrica[i - start][j] != zbor[start]) {
                        najdeno = false;
                        break;
                    } else najdeno = true;
                }
                if (najdeno) {
                    x = i;
                    y = j;
                    x1 = i - dolzinaZbor + 1;
                    y1 = j;
                    cout << x << ", " << y << " -> " << x1 << ", " << y1;
                    return 0;
                }
            }
        }
    }
    if (!najdeno) cout << "Not Found";
    return 0;
}