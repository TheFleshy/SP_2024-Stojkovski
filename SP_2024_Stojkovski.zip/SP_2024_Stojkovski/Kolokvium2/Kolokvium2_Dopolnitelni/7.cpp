#include <iostream>
using namespace std;
void premesti(int niza[], int n) {


    for (int i = 0; i < n; i++) {
        if (niza[i] >= 0) {
            cout << niza[i] << " ";
        }
    }

    for (int i = 0; i < n; i++) {
        if (niza[i] < 0) {
            cout << niza[i] << " ";
        }
    }

    cout << endl;
}

int main() {

    int n;
    cin >> n;

    int niza[100];

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    premesti(niza, n);

//    for (int i=0; i<n; i++){
//        cout<<niza[i]<<" ";
//    }

    return 0;
}

// поправино решена без само да ги печате тиа па тиа .. оно па доваѓа исто ама демек не е така напиашано ботско

#include <iostream>

using namespace std;

void premesti(int niza[], int n) {
    int pozitivni[100];
    int brojPozitivni = 0;

    for (int i = 0; i < n; i++) {
        if (niza[i] >= 0) {
            pozitivni[brojPozitivni++] = niza[i];
        }
    }

    for (int i = 0; i < n; i++) {
        if (niza[i] < 0) {
            pozitivni[brojPozitivni++] = niza[i];
        }
    }

    for (int i = 0; i < brojPozitivni; i++) {
        cout << pozitivni[i] << " ";
    }
    cout << endl;
}

int main() {
    int n;
    cin >> n;

    int niza[100];

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    premesti(niza, n);

    return 0;
}
