#include <iostream>
#include <cmath>
using namespace std;
int main() {

    int n;
    cin >> n;
    int mat[100][100];

    int golemina = ceil(sqrt(n));

    int broj = 1;

    for (int j = 0; j < golemina; j++) {
        for (int i = 0; i < golemina; i++) {
            if (j % 2 == 0) {
                mat[i][j] = broj;
            } else {
                mat[golemina - 1 - i][j] = broj;
            }

            broj++;

            if (broj > n) {
                break;
            }
        }
        if (broj > n) {
            break;
        }
    }

    for (int i = 0; i < golemina; i++) {
        for (int j = 0; j < golemina; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}