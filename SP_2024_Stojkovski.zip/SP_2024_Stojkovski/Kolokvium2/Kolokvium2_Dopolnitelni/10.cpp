#include <iostream>
using namespace std;
int main() {

    int mat[100][100];

    int n, m;
    cin >> n >> m;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    for (int j = 0; j < m; j++) {
        int brojac = 0;

        for (int i = 0; i < n; i++) {
            int index = i;

            if (j < 10) {
                index *= 10;
            } else if (j < 100) {
                index *= 100;
            } else if (j < 120) {
                index *= 1000;
            }

            index += j;

            if (index == mat[i][j]) {
                brojac++;
            }
        }
        cout << brojac << endl;
    }

    return 0;
}