#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;
int main() {

    int n;
    cin >> n;

    char niza[51];
    cin.ignore();

    for (int i = 0; i < n; i++) {
        cin.getline(niza, 51);

        int dolzina = strlen(niza);

        int brojac = 0;
        for (int j = 0; j < dolzina - 2; j++) {
            if (tolower(niza[j]) == 'a' && niza[j + 1] == '1' && tolower(niza[j + 2]) == 'c') {
                brojac++;
            }
        }

        if (brojac >= 2) {
            for (int j = 0; j < dolzina; j++) {
                char siteMalenki = tolower(niza[j]);
                cout << siteMalenki;
            }
            cout << endl;
        }
    }

    return 0;
}