#include <iostream>
using namespace std;
int par(int *a, int N) {
    int niza[10000] = {0};

    for (int i = 0; i < N; i++)
        niza[a[i]]++;

    for (int i = 0; i < 10000; i++) {
        if (niza[i] % 2 == 0 && niza[i] != 0)
            return i;
    }
    return -1;
}

int main() {
    int N;
    cin >> N;
    int a[100];
    for (int i = 0; i < N; i++) {
        cin >> a[i];
    }

    if (par(a, N) != -1) {
        cout << "Najmaliot element koj se pojavuva paren broj pati e " << par(a, N);
    } else cout << "Nitu eden element ne se pojavuva paren broj pati!";

}