#include <iostream>
using namespace std;
int main() {
    int m, n;
    cin >> m >> n;

    float a[50][50];

    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            cin >> a[i][j];
        }
    }

    int x1, y1, x2, y2;
    cin >> x1 >> y1 >> x2 >> y2;

    float b[50][50];

    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            b[i][j] = a[i][j];
        }
    }

    for (int i = x1; i <= x2; i++) {
        for (int j = y1; j <= y2; j++) {

            int brojSosedi = 1;
            float zbirSosedi = a[i][j];

            if (i - 1 >= 0) {
                if (j - 1 >= 0) {
                    brojSosedi++;
                    zbirSosedi += a[i - 1][j - 1];
                }
                brojSosedi++;
                zbirSosedi += a[i - 1][j];
                if (j + 1 < n) {
                    brojSosedi++;
                    zbirSosedi += a[i - 1][j + 1];
                }
            }
            if (j - 1 >= 0) {
                brojSosedi++;
                zbirSosedi += a[i][j - 1];
            }
            if (j + 1 < n) {
                brojSosedi++;
                zbirSosedi += a[i][j + 1];
            }
            if (i + 1 < m) {
                if (j - 1 >= 0) {
                    brojSosedi++;
                    zbirSosedi += a[i + 1][j - 1];
                }
                brojSosedi++;
                zbirSosedi += a[i + 1][j];
                if (j + 1 < n) {
                    brojSosedi++;
                    zbirSosedi += a[i + 1][j + 1];
                }
            }
            float aritmeticka = zbirSosedi / brojSosedi;
            b[i][j] = aritmeticka;
        }
    }
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) cout << b[i][j] << " ";
        cout << endl;
    }
}