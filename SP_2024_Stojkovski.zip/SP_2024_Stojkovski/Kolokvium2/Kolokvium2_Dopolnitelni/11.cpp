#include <iostream>
using namespace std;
int siteNuli = 0;

void transofmirana(int niza[], int n, bool obrnana) {


    int dvizenje = abs(niza[0]);
    if (dvizenje >= n) {
        siteNuli++;
    }

    if (!obrnana) {
        for (int i = 0; i < dvizenje; i++) {
            niza[n - 1] = 0;
            for (int j = n - 1; j > 0; j--) {
                swap(niza[j], niza[j - 1]);
            }
        }
    } else {
        for (int i = 0; i < dvizenje; i++) {
            niza[0] = 0;
            for (int j = 0; j < n - 1; j++) {
                swap(niza[j], niza[j + 1]);
            }
        }
    }

}

int main() {

    int m;
    cin >> m;

    for (int i = 0; i < m; i++) {
        int n;
        cin >> n;

        int niza[100];

        for (int j = 0; j < n; j++) {
            cin >> niza[j];
        }

        transofmirana(niza, n, niza[0] < 0);

        for (int j = 0; j < n; j++) {
            cout << niza[j] << " ";
        }
        cout << endl;

    }

    cout << siteNuli;

    return 0;
}
