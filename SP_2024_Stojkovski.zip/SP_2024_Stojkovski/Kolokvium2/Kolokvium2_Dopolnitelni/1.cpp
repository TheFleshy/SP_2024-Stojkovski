#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

bool daliEpalindrom(char niza[], int n) {

    for (int i = 0; i < n / 2; i++) {
        if (niza[i] != niza[n - i - 1]) {
            return false;
        }
    }
    return true;
}


bool daliImaSpecZnak(char niza[], int n) {
    for (int i = 0; i < n; i++) {
        if (!isalnum(niza[i])) {
            return true;
        }
    }
    return false;
}


int main() {

    int n;
    cin >> n;

    char niza[81];

    char najdolgaNiza[81] = "";

    for (int i = 0; i < n; i++) {
        cin.getline(niza, 81);

        int dolzina = strlen(niza);

        if (daliEpalindrom(niza, dolzina) && daliImaSpecZnak(niza, dolzina)) {
            if (dolzina > strlen(najdolgaNiza)) {
                strcpy(najdolgaNiza, niza);
            }
        }
    }

    if (strlen(najdolgaNiza) > 0) {
        cout << najdolgaNiza;
    } else {
        cout << "Nema!";
    }

    return 0;
}