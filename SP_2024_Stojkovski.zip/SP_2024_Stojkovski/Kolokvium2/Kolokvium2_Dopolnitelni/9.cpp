#include <iostream>
#include <cstring>
using namespace std;
int broi(char niza[], int i, int brojac) {
    if (niza[i] == '\0') {
        return 0;
    }

    if (tolower(niza[i]) < 'a' || tolower(niza[i]) > 'z') {
        if (brojac >= 1 && brojac <= 3) {
            return 1 + broi(niza, i++, 0);
        } else
            return broi(niza, i + 1, 0);
    } else {
        return broi(niza, i + 1, ++brojac);
    }
}

int main() {

    char niza[100];

    char novaNiza[100];

    int maksSvriznici = -1;
    while (cin.getline(niza, 100)) {
        int brojac = broi(niza, 0, 0);
        if (brojac > maksSvriznici) {
            maksSvriznici = brojac;
            strcpy(novaNiza, niza);
        }
    }
    cout << maksSvriznici << ": " << novaNiza;

    return 0;
}