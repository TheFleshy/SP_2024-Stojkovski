#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;
    int mat[100][100];

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    int maksimalnaKolIndex = 0;
    int maksSuma = 0;

    for (int j=0; j<n; j++){
        int zbir =0;
        for (int i=0; i<n; i++){
            zbir+=mat[i][j];
        }
        if (zbir > maksSuma){
            maksSuma=zbir;
            maksimalnaKolIndex = j;
        }
    }

    for (int i=0; i<n; i++){                     // dodavame go zbiro na tia od taa kolona
        mat[i][maksimalnaKolIndex] += maksSuma;
    }

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}