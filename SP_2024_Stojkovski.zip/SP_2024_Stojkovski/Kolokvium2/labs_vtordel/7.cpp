#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;

    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    int parniPozicii =0 , neparniPozicii = 0;

    for (int i=0; i<n; i++){
        if (i % 2 == 0){
            if (niza[i] % 2 == 0) {
                parniPozicii++;
            }
        }
        else if (i % 2 != 0){
            if (niza[i] % 2 != 0) {
                neparniPozicii++;
            }
        }
    }

    int specijalna = (parniPozicii >= 0.5 * n) && (neparniPozicii <= 0.3 * n);

    cout<<specijalna;

    return 0;
}