#include <iostream>
using namespace std;
int main (){

    int n,m;

    cin>>n>>m;

    int mat[100][100];

    int i,j;
    for (i=0; i<n; i++){
        for (j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    bool eSimetricna = true;

    for (i=0; i<n; i++){
        for (j=0; j<m; j++){
            if (mat[i][j] != mat[j][i]){
                eSimetricna = false;
                break;
            }
        }
        if (!eSimetricna){
            break;
        }
    }

    if (eSimetricna){
        cout<<"1"<<endl;
    }
    else {
        cout<<"-1"<<endl;
    }

    for (i=0; i<n; i++){
        for (j=0; j<m; j++){
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }


    return 0;
}