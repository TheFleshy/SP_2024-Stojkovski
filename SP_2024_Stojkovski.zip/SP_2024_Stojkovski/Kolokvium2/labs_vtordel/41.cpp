#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;

    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    for (int i=0; i<n; i++){
        int brojac=0;

        for (int j=i+1; j<n; j++){
            if (niza[j] > niza[i] ){
                brojac++;
                if (brojac >= 2){
                    cout<<niza[i]<<" ";
                    break;
                }
            }
        }
    }

    return 0;
}