#include <iostream>
using namespace std;
int main (){

    int n,m;
    cin>>n>>m;
    int mat[100][100];

    int i,j;
    for ( i=0; i<n; i++){
        for (j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    int min , max = 0;



    float vrednost = (mat[j][j] - min)/max-min;




    return 0;
}