#include <iostream>
using namespace std;

int main (){

   int n;

   cin>>n;

   double niza[100];

   for (int i=0; i<n; i++){
       cin>>niza[i];
   }

    double suma = 0;

   for (int i=0; i<n; i++){
       suma += niza[i];
   }

   double srednaVrednost = suma/n;

   double najBlisku = niza[0];
   double najbliskaRazlika = abs(niza[0] - srednaVrednost);

   for (int i=1; i<n; i++){
       double razlika = abs(niza[i] - srednaVrednost);
       if (razlika < najbliskaRazlika){
           najBlisku = niza[i];
           najbliskaRazlika = razlika;
       }
   }


   printf("%.2f", najBlisku);

    return 0;
}
