#include <iostream>
using namespace std;
int main(){

    int n;
    cin>>n;

    int nizaA[100];

    for (int i=0; i<n; i++){
        cin>>nizaA[i];
    }

    int m;
    cin>>m;

    int nizaB[100];

    for (int i=0; i<m; i++){
        cin>>nizaB[i];
    }

    int s[200];

    int i=0, j=0, k=0; // i za prva, j za vtora, k za treta
    while(i<n && j<m){  //spojuva gi element od dvete nizi
        if(nizaA[i]<nizaB[j]){  // elem od prva pomal od vtora, stava elem od prva
            s[k]=nizaA[i];
            k++;
            i++;
        }
        else{  // elem od vtora obratno
            s[k]=nizaB[j];
            k++;j++;
        }
    }
    while(i<n){     //site od prvata , pogolemi od vtorata gi stava u s
        s[k]=nizaA[i];
        i++;k++;
    }
    while(j<m){    // tuka obratno od vtora pogolemi prva stava u s
        s[k]=nizaB[j];
        j++; k++;
    }

    for(int x=0; x<k; x++) cout<<s[x]<<" ";
    return 0;

}