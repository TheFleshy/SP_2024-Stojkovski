#include <iostream>
using namespace std;
int main (){

    int n,m;
    cin>>n>>m;

    int mat[100][100];
    int mat2[100][100];

    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            cin>>mat2[i][j];
        }
    }

    int brojac=0;
        for (int j=0; j<m; j++){
            if (mat[j][j] == mat2[j][j]){
                brojac++;
            }
        }
    cout<<brojac;

    return 0;
}