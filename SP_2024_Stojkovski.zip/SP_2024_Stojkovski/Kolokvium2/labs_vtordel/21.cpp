#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;

    int niza[100];

    int i;

    for (i=0; i<n; i++){
        cin>>niza[i];
    }


        int maks = niza[0], minim = niza[0];
    for (i=0; i<n; i++){

        if (niza[i] > maks){
            maks = niza[i];
        }
        else if (niza[i] <= maks){
            minim = niza[i];
        }
    }

    for (i=0; i<n; i++){
        if (niza[i] < minim){
            minim = niza[i];
        }
    }

    cout<<"MAX"<<" -> "<<maks<<endl;
    cout<<"MIN"<<" -> "<<minim<<endl;


    int razlika  = maks - minim;

    for (i=0; i<n; i++){
        niza[i] = niza[i] + razlika;
        cout<<niza[i]<<" ";
    }


    // 5
    // 2 4 5 1 3


    return 0;
}