#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;
    int mat[100][100];
    int i,j;
    for (i=0; i<n; i++){
        for(j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    for (i=0; i<n; i++) {
        for (j = 0; j < n; j++) {
            if (mat[i][j] < 0) {
                int zbir = 0;
                if (i - 1 >= 0) zbir += mat[i - 1][j];  // nad
                if (i + 1 < n) zbir += mat[i + 1][j];   // pod
                if (j - 1 >= 0) zbir += mat[i][j - 1];  // levo
                if (j + 1 < n) zbir += mat[i][j + 1];   // desno

                mat[i][j] = zbir;
            }
        }
    }

    for (i=0; i<n; i++){
        for(j=0; j<n; j++){
            cout<<mat[i][j] << " ";
        }
        cout<<endl;
    }

    return 0;
}