#include <iostream>
using namespace std;
int main (){

    int n, k;
    cin>>n>>k;

    int niza[100];
    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    int brojac=0;

    for (int i=0; i<n; i++){
        if (k == niza[i]){
            brojac++;
        }
    }

    for (int i=0; i<n; i++){
        cout<<niza[i]<<" ";
    }
    cout<<endl;

    cout<<"Brojot "<<k<<" vo nizata se naogja "<<brojac<<" pati. ";

    return 0;
}