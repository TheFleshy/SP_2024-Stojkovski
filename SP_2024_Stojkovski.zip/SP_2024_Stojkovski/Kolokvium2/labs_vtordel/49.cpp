#include <iostream>
using namespace std;
int main (){

    int n,m;
    cin>>n>>m;

    int mat[100][100];

    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    for (int i=0; i<n; i++){
        int maks = mat[i][0];
        for (int j=1; j<m; j++){
            if (mat[i][j] > maks){
                maks = mat[i][j];
            }
        }
        mat[i][m-1] = maks;
    }

    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    int elementi = n*m;
    int zbirElementi = 0;
    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            zbirElementi += mat[i][j];
        }
    }

    float sredna = (float)zbirElementi/(float)elementi;
    cout<<sredna;

    return 0;
}