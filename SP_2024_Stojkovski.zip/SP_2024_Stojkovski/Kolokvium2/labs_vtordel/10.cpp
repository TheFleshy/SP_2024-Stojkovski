#include <iostream>
using namespace std;
int main (){

    int n,m;

    cin>>n>>m;



    int i,j;

    int mat1[m][n];
    for (i=0; i<n; i++){
        for (j=0; j<m; j++){
            cin>>mat1[i][j];
        }
    }

    int mat2[m][n];
    for (i=0; i<n; i++){
        for (j=0; j<m; j++){
            cin>>mat2[i][j];
        }
    }

    int brojac=0;
    for (i=0; i<n; i++){
        int count=0;

        for (j=0; j<m; j++){
            if (mat1[j][j] == mat2[j][j]){
                count++;
            }
        }

        if (count == n){
            count++;
        }
        brojac = count;
    }

        cout<<brojac;

    return 0;
}