#include <iostream>
#include <cmath>
using namespace std;
int main (){

    int n;
    cin>>n;
    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    for (int i=0; i<n; i++){
        if (niza[i] < 0){
            niza[i] *= -1;
        }
        niza[i] += niza[i];
    }

    for (int i=0; i<n; i++){
        cout<<niza[i]<<" ";
    }

    return 0;
}