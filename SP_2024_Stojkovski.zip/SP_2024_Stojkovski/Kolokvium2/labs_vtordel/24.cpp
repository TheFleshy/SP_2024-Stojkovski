#include <iostream>
using namespace std;

void funkcija (int niza[], int n){

    for (int i=0; i<n; i++){
        niza[i] = niza[i-1] + niza[i];
    }
}

int main(){

    int n;
    cin>>n;

    int niza[100];

    for(int i=0; i<n; i++){
        cin>>niza[i];
    }

    cout<<"Vnesenata niza e: "<<endl;
    for(int i=0; i<n; i++){
        cout<<niza[i]<<" ";
    }
    cout<<endl;
    cout<<"Novata niza e: "<<endl;

    funkcija(niza, n);

    for(int i=0; i<n; i++){
        cout<<niza[i]<<" ";
    }

    return 0;
}