#include <iostream>
using namespace std;

void form(int n) {
    // Основен случај: ако n е помало или еднакво на 0, заврши рекурзија
    if (n == 0) {
        return;
    }

    // Испечати ред со n ѕвезди
    for (int i = 0; i < n; i++) {
        cout << "*";
    }

    // Префрли се во нов ред
    cout << endl;

    // Рекурзивен повик со n-1 за печатење на следниот ред
    form(n - 1);
}

int main() {
    int n;

    cin >> n;

    form(n);

    return 0;
}
