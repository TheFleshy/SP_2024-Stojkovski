#include <iostream>
using namespace std;

void transform(int niza[], int n){

    int maksimum = niza[0];
    int minimum = niza[0];

    for (int i = 1; i < n; ++i) {
        if (niza[i] > maksimum) {
            maksimum = niza[i];
        }

        if (niza[i] < minimum) {
            minimum = niza[i];
        }
    }

    for (int i = 0; i < n; ++i) {    // smena na max i min el
        if (niza[i] == maksimum) {
            niza[i] = minimum;
        } else if (niza[i] == minimum) {
            niza[i] = maksimum;
        }
    }

    int razlika = maksimum - minimum;

    for (int i = 0; i < n; i++) {
        if (niza[i] != maksimum && niza[i] != minimum) {
            niza[i] += razlika;
        }
    }

}

int main (){

    int n;
    cin>>n;
    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    transform(niza, n);

    for (int i=0; i<n; i++){
        cout<<niza[i]<<" ";
    }

    return 0;
}