#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;

    int mat[100][100];

    int i,j;

    for (i=0; i<n; i++){
        for (j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    if (n % 2 != 0){
        cout<<"GRESKA";
        return 0;
    }
    else {

        int dipliranaMat[50][50]; // Матрицата по диплирањето ќе биде половина по големина

        for ( i = 0; i < n / 2; i++) {  // se isto samo deleme se so 2
            for ( j = 0; j < n / 2; j++) {
                dipliranaMat[i][j] = mat[i][j] + mat[i][n - 1 - j] + mat[n - 1 - i][j] + mat[n - 1 - i][n - 1 - j]; // tuka segde deka so ima + toa sa site uslovi

                // mat[i][j]   +   mat[i][n - 1 - j]    +   mat[n - 1 - i][j]    +     mat[n - 1 - i][n - 1 - j]
                //     1                   2                        3                                4
            }
        }

        for ( i = 0; i < n / 2; i++) {  // i tuka deleme samo so 2
            for ( j = 0; j < n / 2; j++) {
                cout << dipliranaMat[i][j] << " ";
            }
            cout << endl;
        }
    }

    return 0;
}