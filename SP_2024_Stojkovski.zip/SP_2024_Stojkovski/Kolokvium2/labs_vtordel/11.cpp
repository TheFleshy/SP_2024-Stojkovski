#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;

    int mat[n][n];

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    for (int i = 0; i < n-1; i++) {

        int suma = 0;

        for(int j=i+1; j<n;j++){
            suma+=mat[i][j];
        }
        //cout << suma << endl;
        if (mat[i][i] != suma) {
            cout << -1;
            return 0;
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}



//#include <iostream>
//using namespace std;
//int main (){
//
//    int n;
//
//    cin>>n;
//
//    int mat[n][n];
//
//    //int i,j;
//
//    for (int i=0; i<n; i++){
//        for (int j=0; j<n; j++){
//            cin>>mat[i][j];
//        }
//    }
//
//    bool uslov_ispolnet = true;
//    for (int i = 0; i < n; i++) {
//        int suma = 0;
//        for (int j = 0; j < n; j++) {
//            if (i == j) {  // Прескокни го елементот од главната дијагонала
//                suma += mat[i][j];
//            }
//
//        }
//
//        if (mat[i][i] != suma) {
//            uslov_ispolnet = false;
//            break;
//        }
//    }
//
//
//    if (uslov_ispolnet) {
//        for (int i = 0; i < n; i++) {
//            for (int j = 0; j < n; j++) {
//                cout << mat[i][j] << " ";
//            }
//            cout << endl;
//        }
//    } else {
//        cout << -1 << endl;
//        return 0;
//    }
//
//
//
//    return 0;
//}







