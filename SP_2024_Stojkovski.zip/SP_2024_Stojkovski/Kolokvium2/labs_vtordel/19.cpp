#include <iostream>
using namespace std;

int najgolemaNeparnaCifra(int broj) {

    if (broj == 0) {
        return 0;
    }

    int poslednaCifra = broj % 10;
    int ostatokBr = broj / 10;

    int najgolemaOdOstanatite = najgolemaNeparnaCifra(ostatokBr);

    if (najgolemaOdOstanatite == -1 && poslednaCifra % 2 != 0) {
        return poslednaCifra;
    }

    if (poslednaCifra % 2 == 0) {
        return najgolemaOdOstanatite;
    } else {
        return max(najgolemaOdOstanatite, poslednaCifra);
    }
}

int main (){

    int n,m;
    cin>>n>>m;

    for (int i=n; i<=m; i++){

        int rezultat = najgolemaNeparnaCifra(i);

        cout<<i<<" -> "<<rezultat<<endl;
    }

    return 0;
}