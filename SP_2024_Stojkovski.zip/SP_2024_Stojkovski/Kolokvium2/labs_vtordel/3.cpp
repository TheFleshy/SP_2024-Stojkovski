#include <iostream>
using namespace std;
int main (){

    int n = 0;
    int niza[100];

    while(cin>>niza[n]){
        n++;
    }

    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (niza[j] == niza[i]) {
                niza[j] += j - i;
            }
        }
    }

    for (int i = 0; i < n; ++i) {
        cout << niza[i] << " ";
    }

    return 0;
}