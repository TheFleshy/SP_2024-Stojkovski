#include <iostream>
using namespace std;

void rekurzija(int niza[], int i){

    if (i == 0){
        cout<<niza[i]<<" ";


    }
    else {
        rekurzija(niza, i-1);
        cout<<niza[i]<<" ";

//        cout<<niza[i]<<" ";
    }

}

int main (){

    int n;
    cin>>n;

    int niza[n];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    rekurzija(niza, n-1);



    return 0;
}