#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;
    int niza[100];
    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

        int zbir=0;
    for (int i=0; i<n; i++){
        zbir += niza[i];
    }

    double prosek = (double)zbir/n;

    for (int i=0; i<n; i++){
        if (niza[i] < prosek){
            niza[i] = 0;
        }
        else if (niza[i] >= prosek){
            niza[i] = 1;
        }
    }

    cout<<"Average price: "<<prosek<<endl;
    for (int i=0; i<n; i++){
        cout<<niza[i]<<" ";
    }

    return 0;
}