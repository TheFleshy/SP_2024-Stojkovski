#include <iostream>
#include <algorithm>
using namespace std;
int main (){

    int n, k;         // koku najmali elementi ke se pecatat

    cin>>n>>k;

    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    sort(niza, niza + n); // sortirame ja nizata od najmal do najgolem

    cout<<k<<"-te najmali elementi se: ";

    for (int i=0; i<k; i++){   // vademe toku elementi do k , od sortiranata niza
        cout<<niza[i]<<" ";
    }

    return 0;
}


//7 4
//16 12 5 49 48 47 20
// 5 12 16 20 47 48 49 - sortirana od najmal do najgolem i samo pecati do k elementi ..