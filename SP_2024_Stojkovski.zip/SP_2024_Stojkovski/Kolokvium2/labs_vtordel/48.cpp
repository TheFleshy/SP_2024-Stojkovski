#include <iostream>
using namespace std;
int main (){

    int n,m;
    cin>>n>>m;
    int mat[100][100];

    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    cout<<mat[0][0]<<endl;
    for (int j=1; j<m; j++){
        int i=0;
        int k=j;
        while (i<n && k>=0){
            cout<<mat[i][k]<<" ";
            i++;
            k--;
        }
        cout<<endl;
    }


    return 0;
}