#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;

    int mat[100][100];
    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    if (n % 2 != 0){
        cout<<"GRESKA";
        return 0;
    }

    int nova_Diplirana[50][50];

    for (int i=0; i<n/2; i++){
        for (int j=0; j<n/2; j++){
            nova_Diplirana[i][j] = mat[i][j] + mat[i][n-1-j] + mat[n-1-i][j] + mat[n-1-i][n-1-j];
        }
    }

    for (int i=0; i<n/2; i++){
        for (int j=0; j<n/2; j++){
            cout<<nova_Diplirana[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}