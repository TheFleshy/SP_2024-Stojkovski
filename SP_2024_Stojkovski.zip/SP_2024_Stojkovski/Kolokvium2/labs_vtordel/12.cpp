#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;

    int mat[100][100];

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            if (i+j == n-1){
               int zbir=0;
                int brojac=0;

                for (int k=0; k<j; k++){
                    zbir += mat[i][k];
                    brojac++;
                }

                float prosek = (float) zbir/(float)brojac;

                for (int k=n-1; k>j; k--){
                    if (mat[i][k] < prosek){
                        mat[i][k] = -1;
                    }
                }
            }
        }
    }

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}