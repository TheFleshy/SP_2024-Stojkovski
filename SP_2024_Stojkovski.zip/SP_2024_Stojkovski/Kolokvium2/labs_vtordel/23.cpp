#include <iostream>
using namespace std;

int rek (int broj){

    if (broj == 0) return 0;

    int cifra = broj%10;
    int ostatokBr = broj/10;

    int transformiranOstatok = rek(ostatokBr);

    if (cifra % 2 != 0 ){
        return transformiranOstatok * 10 + cifra -1;
    }
    else return transformiranOstatok * 10;
    broj /= 10;
}

int main (){

    int broj;
    cin>>broj;

    int rezultat = rek(broj);

    cout<<"Brojot e "<<rezultat;

    return 0;
}