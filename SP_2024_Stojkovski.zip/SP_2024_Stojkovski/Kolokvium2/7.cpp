#include <iostream>
#include <cmath>
using namespace std;
int main() {

    int n, m;
    cin >> n >> m;

    int mat[100][100];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    int niza[100];

    for (int i = 0; i < n; i++) {
        double sredina = 0;

        for (int j = 0; j < m; j++) {
            sredina += mat[i][j];
        }
        sredina /= m;

        int najblisku = mat[i][0];

        double najbliskaRazlika = abs(sredina - mat[i][0]);

        for (int j = 1; j < m; j++) {
            double razlika = abs(sredina - mat[i][j]);

            if (razlika > najbliskaRazlika) {
                najblisku = mat[i][j];
                najbliskaRazlika = razlika;
            }
        }
        niza[i] = najblisku;
    }

    for (int i = 0; i < n; i++) {
        cout << niza[i] << " ";
    }
    cout << endl;

    return 0;
}
