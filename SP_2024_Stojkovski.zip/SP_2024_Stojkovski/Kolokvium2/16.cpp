#include <iostream>
using namespace std;
int najgolema(int n) {

    if (n == 0) {
        return n;
    }

    int maksimum = najgolema(n / 10);

    return max(n % 10, maksimum);

}

int main() {

    int n;

    while (cin >> n) {
        cout << najgolema(n) << endl;
    }

    return 0;
}