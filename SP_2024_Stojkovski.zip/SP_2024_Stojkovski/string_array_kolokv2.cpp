#include <iostream>
#include <cstring>
using namespace std;
int baranje(char niza[], char zbor[]) {
    int dolzinaNiza = strlen(niza);
    int dolzinaZbor = strlen(zbor);
    int brojac = 0;

    for (int i = 0; i < dolzinaNiza; i++) {
        if (niza[i] == zbor[0]) {
            bool seSostoi = true;

            for (int j = 0; j < dolzinaZbor; j++) {
                if (niza[i + j] != zbor[j]) {
                    seSostoi = false;
                    break;
                }
            }
            if (seSostoi) {
                brojac++;
            }
        }
    }
    return brojac;
}

int main() {

    int n;
    cin >> n;
    cin.ignore();

    char zbor[100];
    cin.getline(zbor, 100);

    for (int i = 0; i < n; i++) {
        char niza[100];
        cin.getline(niza, 100);

        int brojPati = baranje(niza, zbor);
        cout << i << ":" << brojPati << endl;
    }

    return 0;
}


// AMA OVOA E PRIMER 0 PATI SE POJAVUVA U TOKU RECENIC
// 1 SE POJAVUVA U TOKU RECENICI
// 2 SE POJAVUVA U TOKU ITD........ A TOA GO GLEDA ZA U KOKU NAJVEKE SE POJAVUVA PA DURI TUGAJ..
#include <iostream>
#include <cstring>
using namespace std;

int f(char niza[], char charstring[]) {
    int dolzinaNiza = strlen(niza);
    int dolzinaString = strlen(charstring);
    int counter = 0;
    for (int i = 0; i < dolzinaNiza; i++) {
        if (niza[i] == charstring[0]) {
            bool seSostoi = true;
            for (int j = 0; j < dolzinaString; j++) {
                if (niza[i + j] != charstring[j]) {
                    seSostoi = false;
                    break;
                }
            }
            if (seSostoi) {
                counter++;
            }
        }
    }
    return counter;
}

int main() {

    char string[20];
    cin.getline(string, 20);
    int n, najgolem = 0;
    cin >> n;
    cin.ignore(); // Отстрани нов ред од влезниот бафер
    int rezultantna[100] = {0};
    for (int i = 0; i < n; i++) {
        char niza[100];
        cin.getline(niza, 100);
        int brojPati = f(niza, string);
        rezultantna[brojPati]++;
        if (brojPati > najgolem) najgolem = brojPati;
    }
    for (int i = 0; i < najgolem + 1; i++) cout << i << ": " << rezultantna[i] << endl;
    return 0;
}


/// RESENIE BOJAN/MIHAIL

#include <iostream>
#include <cstring>
using namespace std;

int f(char *niza, char *string){
    int dolzinaNiza = strlen(niza), dolzinaString= strlen(string);
    int counter=0;
    for(int i=0; i<dolzinaNiza; i++){
        if(niza[i]==string[0]){
            bool seSostoi=true;
            for(int j=0; j<dolzinaString;j++){
                if(niza[i+j]!=string[j]){
                    seSostoi=false;
                    break;
                }
            }
            if(seSostoi){
                counter++;
            }
        }
    }
    return counter;
}

int main(){

    char string[20];
    cin.getline(string,20);
    int n, najgolem=0;
//    char niza[100];
//    cin.getline(niza,100);
//    cout<<f(niza,string);
    cin>>n;
    cin.ignore();
    int rezultantna[100]={0};
    for(int i=0; i<n; i++){
        char niza[100];
        cin.getline(niza,100);
        int brojPati = f(niza,string);
        rezultantna[brojPati]++;
        if(brojPati>najgolem) najgolem=brojPati;
    }
    for(int i=0; i<najgolem+1; i++) cout<<i<<": "<<rezultantna[i]<<endl;
    return 0;
}

/*
2024
4
Stefan laz
ova e2024 kkasdkas
kako si 2024klo
2024
 */