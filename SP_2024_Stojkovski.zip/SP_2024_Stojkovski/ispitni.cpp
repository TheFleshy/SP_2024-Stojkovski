#include <iostream>

using namespace std;

void premesti(int niza[], int n) {

    for (int i = 0; i < n; i++) {
        if (niza[i] >= 0) {
            cout << niza[i] << " ";
        }
    }

    for (int i = 0; i < n; i++) {
        if (niza[i] < 0) {
            cout << niza[i] << " ";
        }
    }

}

int main() {

    int n;
    cin >> n;
    int niza[100];

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    premesti(niza, n);

    return 0;
}

DAJ MI
OBJASNUVANJE ZA
OVAA :d

#include <iostream>
using namespace std;

void vrednost(int niza[], int n) {

    for (int i = 1; i < n - 1; i++) {
        int tekoven = niza[i];
        if (niza[i] > niza[i + 1] && niza[i] > niza[i - 1]) {

            if (niza[i] > tekoven) {
                tekoven = niza[i];
            }
            cout << tekoven;
            break;
        } else {
            cout << "No element match the criteria";

        }
    }
}

int main() {

    int n;
    cin >> n;

    int niza[100];
    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    vrednost(niza, n);

    return 0;
}


#include <iostream>

using namespace std;

int main() {

    int n, m;
    cin >> n >> m;
    int mat[50][50];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    int s1 = 0, s2 = 0;


    return 0;
}


#include <bits/stdc++.h>

using namespace std;

int main() {

    int niza[100];

    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    int index;
    cin >> index;

    for (int i = n; i > index; i--) {    // meste ja nizata za eden u desno !!! , prae mesto za drug
        niza[i] = niza[i - 1];
    }
    n++;

    for (int i = 0; i < n; i++) {
        niza[index] = rand() % 100;
    }

    for (int i = 0; i < n; i++) {
        cout << niza[i] << " ";
    }

}


#include <iostream>

using namespace std;

int main() {

    int n, m;
    cin >> n >> m;

    int mat[120][120];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }

    for (int j = 0; j < m; j++) {
        int brojac = 0;

        for (int i = 0; i < n; i++) {
            int index = i;
            if (j < 10) {
                index *= 10;
            } else if (j < 100) {
                index *= 100;
            } else if (j < 121) {
                index *= 1000;
            }

            index += j;

            if (index == mat[i][j]) {
                brojac++;
            }
        }
        cout << brojac << endl;
    }

    return 0;
}


#include <iostream>
#include <cstring>

using namespace std;

int main() {
    char niza[100];

    cin.getline(niza, 100);

    int length = strlen(niza);
    int halfLength = length / 2;

    for (int i = 0; i < halfLength; ++i) {
        char temp = niza[i];
        niza[i] = niza[i + halfLength];
        niza[i + halfLength] = temp;
    }

    cout << niza << endl;

    return 0;
}


#include <iostream>
#include <cstring>
#include <cctype>

using namespace std;

int main() {

    int n;
    cin >> n;

    int k;
    cin >> k;

    char c;
    cin >> c;

    cin.ignore();

    char niza[100];

    bool najden = false;

    for (int i = 0; i < n; i++) {
        cin.getline(niza, 100);

        int dolzina = strlen(niza);
        int brojac = 0;
        for (int j = 0; j < dolzina; j++) {

            if (tolower(niza[j]) == tolower(c)) {
                brojac++;
            }
        }

        if (brojac == k) {
            cout << niza << endl;
            najden = true;
        }
    }

    if (!najden) {
        cout << "NONE";
    }

    return 0;
}


#include <iostream>
#include <cstring>
#include <cctype>

using namespace std;

int main() {

    char niza[100];
    cin.getline(niza, 100);

    float vkupnoKarakateri = 0;

    for (int i = 0; i < strlen(niza); i++) {
        if (isalpha(niza[i])) {
            vkupnoKarakateri++;
        }
    }

    float vkupnoMaliBukvi = 0;
    float vkupnoGolemiBukvi = 0;

    for (int i = 0; i < strlen(niza); i++) {
        if (islower(niza[i])) {
            vkupnoMaliBukvi++;
        }
        if (isupper(niza[i])) {
            vkupnoGolemiBukvi++;
        }
    }

    float relativnaFmali = vkupnoMaliBukvi / vkupnoKarakateri;
    float relativniFgolemi = vkupnoGolemiBukvi / vkupnoKarakateri;

    cout << relativnaFmali << endl;
    cout << relativniFgolemi << endl;


    return 0;
}


#include <iostream>

using namespace std;

void rekurizivna(int n) {

    cout << n << " ";

    if (n > 0) {
        rekurizivna(n - 3);
        cout << n << " ";
    }

}

int main() {

    int n;
    cin >> n;

    rekurizivna(n);

    return 0;
}
