#include <iostream>
using namespace std;
int main() {

    int mat[100][100];
    int n, m;
    cin >> n >> m;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> mat[i][j];
        }
    }
    int dolzina;

    if (n > m) {
        dolzina = m;
    } else if (m > n) {
        dolzina = n;
    } else {
        dolzina = n;
    }
    for (int x = 1; x < dolzina; x++) {
        int suma = 0;
        for (int i = 0; i <= x; i++) {
            suma += mat[i][0];
            suma += mat[i][i];
            suma += mat[i][x];
        }
        suma = suma - mat[0][0];
        suma = suma - mat[x][x];
        cout << suma << endl;
    }
    return 0;
}


// RESENIE DRUG NACIN

#include <bits/stdc++.h>
#include <iostream>
using namespace std;
int main() {
    int n, m;
    cin >> n >> m;
    int a[n][m];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> a[i][j];
        }
    }

    int minim = min(m, n);
    for (int x = 1; x < minim; x++) {
        int zbir = 0;
        for (int i = 0; i < x + 1; i++) {
            zbir += a[i][0];
        }
        for (int i = 0; i < x + 1; i++) {
            zbir += a[i][x];
        }
        for (int i = 1; i < x; i++) {
            zbir += a[i][i];
        }
        cout << zbir << endl;
    }

    return 0;
}