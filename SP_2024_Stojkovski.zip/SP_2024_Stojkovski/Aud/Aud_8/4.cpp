//Напишете програма во C++ која чита низа од цели броеви од стандарден влез
//а потоа генерира случаен (random) број и истиот го внесува на позиција која се чита како дополнителен аргумент од стандарден влез.
// Прикажете ја изменетата низа. Пример влез:
// 5 - elementi na niza
// 1 2 3 4 5 - vnes na elemntite
// 2 - na koja pozicija da se umetne , pocnuvajki od 0
// 1 2 '9' 3 4 5

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main (){

    int niza[100];

    int n ;
    cin>>n;
    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    srand(time(NULL));

    int RandomNumber = 1 + rand() % 1000;

    int m; // na koj indeks da se vmetne brojo

    cin>>m;

    if (m<0 || m> n-1){
        cout<<"Nevaliden indeks!";
        return -1;
    }

    for (int i=n; i>m; i--){       // meste gi elementite na desno, prave prostorce
        niza[i] = niza [i-1];
    }

    niza[m] = RandomNumber;  // dodava go rand

    n++;  // sire ja nizata oti ima eden poveke element

    for (int i=0; i<n; i++){
        cout<<niza[i]<<" ";
    }
    cout<<endl;



    return 0;
}