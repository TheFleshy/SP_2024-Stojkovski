// Да се напише програма која влезната низа a ќе ја трансформира во излезна низа b на следниот начин:
//bi = ai + an-1-i
//Влезната низа 1 2 3 5 7 треба да се трансформира во 8 7 6 7 8.
//Објаснување: Бидејќи влезната низа a е со големина n, низата b ќе биде со иста големина.
// Трансформацијата се врши со парно собирање и замена на елементи.
//За секој пар елементи a[i] и a[n-1-i], каде што i се движи од [0 до n/2-1], нивниот збир е зачуван во b[i], додека a[i] се заменува со [n-1-i].
// Ако n е непарен, средниот елемент a[n/2] се множи со 2.

#include <iostream>
using namespace std;

void transform (int niza[], int n){
    for (int i=0, j=n-1; i<j; i++, j--){
        niza[i] += niza[j];
        niza[j] = niza[i];
    }
    if (n%2){
        niza[n/2] *= 2;
    }
}

int main (){

    int n;
    int niza[100];

    cout << "Vnesete golemina na nizata: ";
    cin>>n;

    cout<<"Vnesete gi elementite na nizata: ";

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    transform(niza, n);

    cout<<"Transformiranata niza e: "<<endl;

    for (int i=0; i<n; i++){
        cout<<niza[i]<<" ";
    }
    cout<<endl;

    return 0;
}