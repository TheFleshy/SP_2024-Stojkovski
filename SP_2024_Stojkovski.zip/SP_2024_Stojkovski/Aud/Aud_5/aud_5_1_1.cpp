// Да се напише програма за пресметување на сумата на сите непарни двоцифрени броеви.
// Добиената сума се печати на екран.

#include <iostream>
using namespace std;
int main (){

    int i = 11, sum = 0;
    while (i <= 99){
        sum = sum + i; //gi sobira broevite
        i= i + 2; // gi sobira za 2 (parnite)
    }
    cout<<sum;
    return 0;
}