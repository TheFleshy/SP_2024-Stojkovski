// Да се напише програма што ќе ги испечати сите броеви од зададен опсег
// кои се читаат исто и одлево надесно и оддесно налево.

// пр: 12321 5061605

#include <iostream>

using namespace std;

int main() {
    int pocni, zavrsi, temp, op, cifra;
    int i;
    cin >> pocni >> zavrsi;
    for (i = pocni; i <= zavrsi; i++) {
        temp = i;
        op = 0;
        while (temp > 0){
            cifra = temp % 10;
            op = op * 10 + cifra;
            temp = temp / 10;
        }
        if (op == i)
            cout<<i<<endl;
    }
    return 0;
}