//Да се напише програма што од непознат број на цели броеви што се внесуваат од тастатура
// ќе ги определи двата броја со најголеми вредности.
// Програмата завршува ако се внесе невалидна репрезентација на број.

//пр: Ако се внесат броевите 2 4 7 4 2 1 8 6 9 7 10 3 програмата ќе отпечати 10 и 9.

#include <iostream>
using namespace std;
int main (){
    int n, max1, max2, temp;
    if (cin>>max1>>max2){
        if (max2>max1){
            temp = max1;
            max1 = max2;        /* sporedba na max1 i max2 i swamp so pomos na temp */
            max2 = temp;
        }
        while (cin>>n){
            if (n > max1){
                max2 = max1;    /* proverka dali n e pogolemo od max1 i swamp isto pomalenko dava vrednost na drugoto i zima od slednio u slucajno n */
                max1 = n;
            }else if (n > max2){
                max2=n;             /* Ako e pomalo od max1 proverka dali e od max2 */
            }
        }
        cout<<max1<<endl;
        cout<<max2<<endl;
    }else {
    cout<<"Vnesete dva broja!";
    }
    return 0;
}