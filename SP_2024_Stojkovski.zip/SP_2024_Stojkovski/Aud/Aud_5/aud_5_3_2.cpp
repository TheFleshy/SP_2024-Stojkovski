//Да се напише програма што од n броеви (внесени од тастатура) ќе го определи бројот на броеви
// што се деливи со 3, при делењето со 3 имаат остаток 1, односно 2.
//Задачата да се реши со while, do…while и for

// for

#include <iostream>
using namespace std;
int main (){
    int n = 1, i, broj, div, r1,r2;
    div = r1 = r2 = 0; /* brojaci */
    cin>>n; /* vnesete broevi */
    for (i = 0; i < n; i++){
        cin>>broj;
        if (broj % 3 == 0){
            div++;
        }else if (broj % 3 == 1){
            r1++;
        }else {
            r2++;
        }
    }
    cout<<div<<endl;
    cout<<r1<<endl;
    cout<<r2<<endl;

    return 0;
}