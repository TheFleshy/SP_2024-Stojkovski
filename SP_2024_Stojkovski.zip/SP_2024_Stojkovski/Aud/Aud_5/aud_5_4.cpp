//Да се напише програма што на екран ќе ги испечати сите четири-цифрени броеви
// кај кои збирот на трите најмалку значајни цифри е еднаков со најзначајната цифра.
// pr. 4031 (4=0+3+1), 5131 (5=1+3+1)


#include <iostream>
using namespace std;

int main() {
    int i, n, suma, prva_cifra, cifra;
    i = 1000;
    while (i <= 9999) {
        prva_cifra = i / 1000;
        n = i % 1000;
        suma = 0;
        while (n > 0) {
            cifra = n % 10;
            suma += cifra;
            n /= 10;
        }
        if (suma == prva_cifra) cout << i << "\t";
        i++;
    }
    return 0;
}