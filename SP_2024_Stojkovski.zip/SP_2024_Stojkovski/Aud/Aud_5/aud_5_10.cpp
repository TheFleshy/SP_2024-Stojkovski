// Да се напише програма што од непознат број на цели броеви кои се внесуваат од тастатура
// ќе ги определи позициите (редните броеви на внесување) на двата последователни броја што ја имаат најголемата сума.
// Програмата завршува ако едно по друго (последователно) се внесат два негативни цели броја.

#include <iostream>
using namespace std;
int main (){
    int pol_pozicija, pozicija, max_suma, suma, prethoden, sleden;
    cin>>prethoden>>sleden;
    pol_pozicija = pozicija = 2;
    max_suma = suma = prethoden + sleden;
    while (1){
        if (prethoden < 0 && sleden < 0){
            break;
        }
        suma = prethoden + sleden;
        if (suma > max_suma){
            max_suma = suma;
            pol_pozicija = pozicija;
        }
        prethoden = sleden;
        cin>>sleden;
        pozicija++;
    }
    if (pozicija > 2){
        cout<<"Broevite se na pozicii: "<<pol_pozicija - 1<<" i "<<pol_pozicija<<" i nivnata suma e: "<<max_suma;
    }
    return 0;
}