//Да се напише програма која од СВ ќе прочита два цели броеви и ќе ја испечати
// на компјутерскиот екран нивната сума, разлика, производ и остатокот при делењето.

#include <iostream>

using namespace std;

int main() {
    int x,y;
    cin>>x>>y;

    cout<<"Sumata na dvata broja e: "<<x+y<<endl;
    cout<<"Razlikata na dvata broja e: "<<x-y<<endl;
    cout<<"Proizvodot na dvata broja e: "<<x*y<<endl;
    cout<<"Ostatok pri delenje na dvata broja e: "<<x%y;

    return 0;
}