// Да се напише програма која за дадени страни на еден разностран триаголник ќе ги отпечати
// на екран периметарот и квадратот од плоштината (нека се работи со a = 5, b = 7.5, c = 10.2).

#include <iostream>

using namespace std;

int main() {
    float a = 5, b = 7.5, c = 10.2;
    float L = a + b + c;
    float k = L / 2;
    float P = k * (k - a) * (k - b) * (k - c);
    cout << "Perimetarot na triagolnikot e: " << L << endl;
    cout << "Kvadratot na plostinata e: " << P << endl;
    return 0;
}