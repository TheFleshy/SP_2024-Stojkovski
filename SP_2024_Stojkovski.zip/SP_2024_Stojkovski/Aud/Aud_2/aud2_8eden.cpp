//Да се напише програма која ќе ја пресметува вредноста на математичкиот израз:
// x = 3/2 + (5 – 46*5/12)

#include <iostream>

using namespace std;

int main() {
    float x = 3 / 2 + (5 - 46 * 5 / 12);
    cout << "x= " << x;
    return 0;
}