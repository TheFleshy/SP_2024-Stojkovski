//Да се напише програма која ќе ги отпечати на екран остатоците при делењето на бројот:
// 19 со 2, 3, 5 и 8.

#include <iostream>

using namespace std;

int main() {
    int a=19;
    cout<<"Ostatok pri delenje na 19 i 2 e: "<<a%2<<endl;
    cout<<"Ostatok pri delenje na 19 i 3 e: "<<a%3<<endl;
    cout<<"Ostatok pri delenje na 19 i 5 e: "<<a%5<<endl;
    cout<<"Ostatok pri delenje na 19 i 8 e: "<<a%8<<endl;
    return 0;
}
