// Да се напише програма која чита голема буква од стандарден влез
// и ја печати истата како мала буква.
// - Напомена: Секој знак се претставува со ASCII број.

#include <iostream>

using namespace std;

int main() {
    char b;

    cout << "Vnesete golema bukva: " << endl;
    cin >> b;

    cout << b << " malo se pisuva " << char(b + ('a' - 'A'));

    return 0;
}