//Да се напише програма за пресметување и печатење на плоштината и периметарот на круг.
// Радиусот на кругот се чита од стандарден влез (тастатура) како децимален број.

#include <iostream>

using namespace std;

int main() {
    float r, P, L;
    cout << "Vnesi go radiusot:";
    cin >> r;

    L = 2 * r * 3.14;
    cout << "Perimetarot na krugot e: " << L << endl;

    P = r * r * 3.14;
    cout << "Plostinata na krugot e: " << P;

    return 0;
}