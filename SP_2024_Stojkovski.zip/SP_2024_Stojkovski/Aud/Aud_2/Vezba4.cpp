#include <iostream>
using namespace std;
int main ()
{
    int x=3, y=5, z=12;
    float ar_sredina = (x+y+z)/3.0;
    cout<<"Aritmetickata sredina e: "<<ar_sredina <<endl;
    return 0;

}

// Zadaca - PRESMETKA NA ARITMETICKA SREDINA