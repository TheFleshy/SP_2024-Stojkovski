/* Да се напише програма која за зададена вредност на х (при декларација на променливата)
 * ќе го пресмета и отпечати на екран х2. */

#include <iostream>

using namespace std;

int main() {
    int x = 7;
    cout << "Brojot " << x << " na kvadrat e: " << x * x;
    return 0;
}