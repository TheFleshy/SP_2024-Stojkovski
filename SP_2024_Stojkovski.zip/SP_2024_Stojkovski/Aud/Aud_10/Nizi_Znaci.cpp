#include <iostream>
#include <cstring>
using namespace std;

int broenje_znak(char niza[], char z){
    int vkupno = 0;

    for (int i=0; i< strlen(niza); i++){
        if (niza[i] == z){
            vkupno++;
        }
    }

    return vkupno;
}

int main (){

    char niza[100];
    cin.getline(niza, 100);

    char znak;

    cin>>znak;

    cout<<"Znakot "<<znak<<" se pojavuva "<<broenje_znak(niza, znak)<<" pati";

    return 0;
}

// #2
#include <iostream>
#include <cstring>
using namespace std;

int dolzina (char niza[]){
    int dolzina = 0;

    for (int i=0; i< strlen(niza); i++){
        dolzina++;
    }

    return dolzina;
}

int dolzina_r(char niza[]){
    if (niza[0] == '\0'){
        return 0;
    }
    return 1+ dolzina(niza+1);
}

int main (){

    char niza[100];
    cin.getline(niza, 100);

    cout<<dolzina(niza);
    cout<<endl;
    cout<<dolzina_r(niza);

    return 0;
}


// #3

#include <iostream>
#include <cstring>
using namespace std;
int main (){

    char niza[100];

    cin.getline(niza, 100);

    int pozicija, dolzina;
    cin>>pozicija>>dolzina;

    char podniza[100];

    if (pozicija <= strlen(niza)){
        strncpy(podniza, niza + pozicija, dolzina);
        podniza[dolzina] = '\0';
        cout<<podniza;
    }else{
        cout<<"Ne validen vnes ";
    }

    return 0;
}


#include <iostream>
#include <cstring>
using namespace std;
int main(){
    int n,maks=0,broj=0;
    cin>>n;
    cin.ignore();
    for(int i=0; i<n; i++){
        char string[100];
        cin.getline(string,100);
        int suma=0;
        for(int j=0; j< strlen(string);j++){
            if(isdigit(string[j])){
                suma+=string[j]-'0';
            }
        }
        if(suma>maks){
            maks = suma;
            broj=i;
        }
    }
    cout<<maks<<endl<<broj<<endl;



    char string[100];
    cin.getline(string,100);
    int pojavuvanja[26]={0};
    for(int i=0; i< strlen(string);i++){
        pojavuvanja[string[i]-'a']++;
    }
    for(int i=0; i<26;i++) cout<<pojavuvanja[i]<<" ";
    return 0;
}



// #5
#include <iostream>
#include <cstring>
using namespace std;

int daliePalindrom (char niza[]){

    for (int i=0; i< strlen(niza)/2; i++){
        if (niza[i] != niza[strlen(niza) - 1 - i]){
            return 0;
        }
    }
    return 1;
}

// rekurzivno

int palindrom_r(char niza[], int pocetok, int kraj){
    if (pocetok >= kraj)return 1;
    if (niza[pocetok] == niza[kraj])
        return palindrom_r(niza, pocetok+1, kraj-1);
    return 0;
}


int main (){

    char niza[100];
    cin.getline(niza, 100);

    if (daliePalindrom(niza)){
        cout<<"Taa e palindrom";
    }else cout<<"Ne e palindrom";

    return 0;
}


// #5.1

#include <iostream>
#include <cstring>
#include <cctype>

bool daliePalindrom (char niza[]){
    int dolzina = strlen(niza);
    char nizaCista[dolzina + 1];
    int index = 0;

    for (int i=0; i<dolzina; i++){
        if (!isspace(niza[1]) && !ispunct(niza[i])){
            nizaCista[index++] = tolower(niza[i]);
        }
    }

    for (int i=0; i<dolzina/2; i++){
        if (nizaCista[i] != nizaCista[dolzina - 1 - i]){
            return true;
        }
    }
    return false;
}

using namespace std;
int main (){

    char niza[100];
    cin.getline(niza, 100);

    if (daliePalindrom(niza)){
        cout<<"Nizata e palindrom ";
    }else cout<<"Ne e palindrom";

    return 0;
}


#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

int daliEvalidna (char niza[]){
    int bukvi=0, cifra=0, spec=0;

    if (strlen(niza) <= 8){
        cout<<"Nizata ne e dovolno golema"<<endl;
        return 0;
    }

    for (int i=0; i< strlen(niza); i++){
        if (isalpha(niza[i])){
            bukvi++;
        }
        else if (isdigit(niza[i])){
            cifra++;
        }
        else spec++;
    }

    return bukvi > 0 && cifra > 0 && spec > 0;
}

int main (){

    char niza[100];
    cin.getline(niza, 100);

    if (daliEvalidna(niza)){
        cout<<"Nizata e validna";
    }else if (strlen(niza)>8)
        cout<<"Nizata ne e validna";

    return 0;
}





// #7
#include <iostream>
#include <cstring>
using namespace std;

void filter (char niza[]){
    int i, j=0;

    for (i=0; i< strlen(niza); i++){
        if (isalpha(niza[i])){
            if (islower(niza[i])){
                niza[j] = toupper(niza[i]);
            }
            else if (isupper(niza[i])){
                niza[j] = tolower(niza[i]);
            }
            j++;
        }
    }
    niza[j] = '\0';
}

int main (){

    char niza[100];
    cin.getline(niza, 100);

    filter(niza);
    cout<<niza<<endl;

    return 0;
}


// #8

#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

void trim(char niza[]){

    int start=-1;
    for (int i=0; i< strlen(niza); i++){
        if (!isspace(niza[i])){
            start = i;
            break;
        }
    }

    strcpy(niza, niza+start);

    for (int i= strlen(niza)-1; i>=0; i--){
        if (!isspace(niza[i])){
            niza[i+1] = '\0';
            break;
        }
    }

}

int main (){

    char niza[100];
    cin.getline(niza, 100);

    trim(niza);
    cout<<niza;

    return 0;
}