#include <iostream>

using namespace std;

int main() {
    int b;
    cout << "Vnesi eden broj: " << endl;
    cin >> b;
    if (b > 0) {
        cout << "Brojot e pozitiven!";
    } else if (b < 0) {
        cout << "Brojot e negativen";
    } else {
        cout << "Brojot e nula!";
    }
    return 0;
}