// Да се напише програма која што ќе ги избрише дупликатите од една низа.
// На крај, да се испечати на екран новодобиената низа. Елементите од низата се читаат од стандарден влез.

#include <iostream>
using namespace std;
int main (){

    int niza[100];

    int n;

    cin>>n;

    for (int i = 0 ; i<n; i++){
        cin>>niza[i];

        cout<<niza[i];
    }

    cout<<endl;

    int izbrisani = 0;


    for (int i = 0;i < n - izbrisani; i++){
        for (int j = i+1; j<n-izbrisani; j++){
            if (niza[i] == niza[j]){
                for (int k = j; k<n-1-izbrisani; k++){
                    niza[k] = niza [k+1];
                }

                izbrisani++;
                --j;         // ovoa mora zatoa so ako go nema sekogas kuga ke ima eden duplikat nema da go racuna kako duplikat ..
            }
        }
    }

    n = n-izbrisani;

    for (int i=0; i<n; i++){
        cout<<niza[i]<<" ";
    }

    return 0;
}