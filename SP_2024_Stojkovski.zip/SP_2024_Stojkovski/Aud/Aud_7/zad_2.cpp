// Да се напише програма која за низа чии елементи се внесуваат од тастатура
// ќе го пресмета збирот на парните елементи, збирот на непарните елементи,
// како и односот помеѓу бројот на парни и непарни елементи. Резултатот да се испечати на екран.

#include <iostream>
using namespace std;
int main (){

    int n;
    int niza[100];

    int sumaParni = 0, sumaNeparni = 0;

    int odnosParni = 0, odnosNeparni =0;

    cin>>n; // kolku elementi ke ima vo nizata

    for (int i = 0; i<n; i++){
        cin>>niza[i];          // unasame gi elementite u nizata
    }

    for (int i = 0; i<n; i+=2){
        sumaParni += niza[i];      // suma na parni pozicii
        odnosParni++;
    }

    for (int i = 1; i<n; i+=2){
        sumaNeparni += niza[i];  // suma na neparni pozicii
        odnosNeparni++;
    }

    cout<<sumaParni<<endl;
    cout<<sumaNeparni<<endl;

    cout<<(float)odnosParni / odnosNeparni;


    return 0;
}

// 7
// 3 2 7 6 2 5 1



// Sega ke napravam programa samo da vidi dali cifrata e parna pa da ja sobira vo parni.. //


#include <iostream>
using namespace std;
int main (){

    int n;
    int niza[100];

    int sumaParni = 0, sumaNeparni = 0;

    int odnosParni = 0, odnosNeparni =0;

    cin>>n; // kolku elementi ke ima vo nizata

    for (int i = 0; i<n; i++){
        cin>>niza[i];          // unasame gi elementite u nizata
    }

    for (int i=0; i<n; i++){

        if (niza [i] % 2 == 0){
            sumaParni += niza[i];
            odnosParni++;
        }

        else {
            sumaNeparni += niza[i];
            odnosNeparni++;
        }

    }

    cout<<sumaParni<<endl;
    cout<<sumaNeparni<<endl;

    cout<<(float)odnosParni / odnosNeparni;


    return 0;
}