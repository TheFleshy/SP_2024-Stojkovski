// #1

#include <iostream>
using namespace std;
int main (){

    int n,m;
    cin>>n>>m;
    int mat[100][100];

    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    int zbirNeparniKoloni = 0;
    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            if (j+1 % 2){
                zbirNeparniKoloni++;
            }
        }
    }

    int zbirParniRedici = 0;
    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            if (i % 2 == 0){
                zbirParniRedici++;
            }
        }
    }

    int razlika = zbirNeparniKoloni - zbirParniRedici;
    cout<<razlika<<endl;

    return 0;
}


#include <iostream>
using namespace std;
int main (){

    int mat[100][100];
    int n;
    cin>>n;

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    int maks=0; int min;               // maks mora da e napocetok 0 oti posle ke zamenuva i ke sporeduva dodeka ne nae najgolem
    // min ne mora da e 0 oti u cikluso nema nikogas da bide pomalo od 0 za najmal
    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            if (mat[i][j] > maks){
                maks = mat[i][j];
            }
            else if (mat[i][j] < min){
                min = mat[i][j];
            }
        }
    }

    int razlika = maks - min;

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            if (i==j){
                mat[i][j] = razlika;
            }
        }
    }

//    cout<<maks<<endl;
//    cout<<min<<endl;

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}

// #3

#include <iostream>
using namespace std;
int main (){

    int n;
    cin>>n;
    int mat[100][100];

    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    int simetricna = 1;

    for (int i=0; i<n; i++){
        for (int j=i+1; j<n; j++){
            if (mat[i][j] != mat[j][i]){
                simetricna = 0;
                break;
            }

            if (!simetricna){
                break;
            }
        }
    }

    if (simetricna){
        cout<<"Matricata e simetricna "<<endl;
    }else cout<<"Matricata ne e simetricna vo odnos na glavnata dijagonala "<<endl;

    // 3                            3
    // 3 3 3                        1 2 3
    // 3 3 3                        1 2 3
    // 3 3 3   - simetricna         1 2 3      - ne e simetricna

    return 0;
}


za doma so bombite na zaev :)

#include <iostream>
using namespace std ;
int main (){

    int n,m;
    cin>>n>>m;

    int mat[100][100];
    int mines[100][100];

    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            cin>>mat[i][j];
            mines[i][j]=0;
        }
    }

    int brojacPlusovi = 0;

    for (int i=1; i<n-1; i++ ){            // tuka ke gi naogja ama ke se povtarat
        for (int j=1; j<m-1; j++){
            if (mat[i][j] == 1 &&
                mat[i][j-1] == 1 &&
                mat[i][j+1] == 1 &&             //mat[i][j-1] - lev sosed ,   mat[i-1][j] - goren sosed
                mat[i-1][j] == 1 &&
                mat[i+1][j] == 1) {

                if (mines[i][j] != 1 &&
                    mines[i][j-1] != 1 &&
                    mines[i][j+1] != 1 &&             // praeme istoto samo i za mines i tia mora da ne sa 1, za kuga ke go zgolememe brojaco e tugaj veke da stanat 1 i tam veke da ne moze da se prae na drugite kuga ke doe pa od ozgore
                    mines[i-1][j] != 1 &&
                    mines[i+1][j] != 1){

                    brojacPlusovi++;
                    mines[i][j] = mines[i][j-1] = mines[i][j+1] = mines[i-1][j] = mines[i+1][j] = 1;
                }
            }
        }
    }

    // praeme nova matrica so ke bide samo so nuli, i deka so veke edns se pojave plus tam puka bomba i tam veke nemoze broe plus
    cout<<brojacPlusovi;

    return 0;
}