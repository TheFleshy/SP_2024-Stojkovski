// Да се напише програма која ќе го пресмета скаларниот производ на два вектори со по n координати.
// Бројот на координати n, како и координатите на векторите се внесуваат од стандарден влез.
// Резултатот да се испечати на екран.

#include <iostream>
using namespace std;
int main (){

    int n, skalar=0;
    int nizaA[100], nizaB[100];

    cin>>n;  // koku elementi da ima nizata

    for (int i=0; i<n; i++){
        cin>>nizaA[i];          // unasa se elementite na nizata A
    }

    for (int i=0; i<n; i++){
        cin>>nizaB[i];         // unasa se elemenetite na nizata B
    }

    for (int i=0; i<n; i++){
        skalar += nizaA[i] * nizaB[i];        // retardiran skalara ...
    }

    cout<<skalar;

    return 0;
}


// zabegana zadaca