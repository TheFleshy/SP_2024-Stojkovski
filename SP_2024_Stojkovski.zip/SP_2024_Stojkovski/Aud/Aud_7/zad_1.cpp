//Да се напише програма која за две низи кои се внесуваат од тастатура
// ќе провери дали се еднакви или не. На екран да се испачати резултатот од споредбата.
// Максимална големина на низите е 100.

#include <iostream>
using namespace std;
int main (){

    int n, m;
    int i;

    int niza1[100], niza2[100];

    cout<<"Goleminata na prvata niza e: "<<endl;
    cin>>n;

    cout<<"Goleminata na vtorata niza e: "<<endl;
    cin>>m;

    if (n != m){
        cout<<"Goleminite na nizite ne se isti!";
    }

    else {

        cout<<"Elementite na prvata niza se: "<<endl;
        for (i=0; i<n; i++){
            cin>>niza1[i];
//            cout<<niza1[i]<<" ";
        }

//        cout<<endl;

        cout<<"Elementite na vtorata  niza se: "<<endl;
        for ( i = 0; i<m; i++){
            cin>>niza2[i];
//            cout<<niza2[i]<<" ";
        }

        for (i = 0; i<n; i++){
            if (niza1[i] != niza2[i]){
                break;
            }
        }

        if (i == n){
            cout<<"Nizite se ednakvi ";
        }
        else {
            cout<<"Nizite se razlicni";
        }

    }




    return 0;
}