// Да се напише програма која ќе провери дали дадена низа од n елементи која се чита од стандарден влез
// е строго растечка, строго опаѓачка или ниту строго растечка ниту строго опаѓачка.
// Резултатот да се испечати на екран.

#include <iostream>
using namespace std;
int main (){

    int n;
    int niza[100];

    int rastecka = 1, opagacka = 1; // znamenca za rastecka, opagacka

    cin>>n;  // koku elementi ke ima nizata

    for (int i=0; i<n; i++){   // unasame gi elementite na nizata, toku elementi koku so sme zadadeli deka ke ima u nizata so n !!!
        cin>>niza[i];
    }

    for (int i=0 ; i<n-1; i++){       // poznuva od 1 element na nizata dodeka ne stigne do posleden , bez nego t.s do predposleden
        if (niza[i] >= niza [i+1]){   // sporeduva go sekoj soseden element, ako prvio e pogolem od narednio nemoze da bide rastecka, mora da e najmalecok do posledniot da e najgolem
            rastecka = 0;   // i ako ne e rastecka stava ja kako 0 i prekunuva go for cikluso
            break; //izlava od taj ciklus
        }
    }

    for (int i=0; i<n-1; i++){   // poznuva od 1 element na nizata dodeka ne stigne do posleden , bez nego t.s do predposleden
        if (niza[i] <= niza [i+1]){   // sporeduva go sekoj soseden element, ako prvio e pomalecok od narednio nemoze da bide opagacka, mora da e najgolem do posledniot da e najmalecok
            opagacka = 0; // ako ne e opagacki togaj stava go znamenceto na 0.
            break; // izlava od cikluso
        }
    }

    if (rastecka){  // ako znamenceto e ostanalo 1, odnosno true, znaci deka prvio element e najmal i site nagore se pogolem i pogolem, odnosno se zgolemuvat
        cout<<"Nizata e strogo rastecka";
    }

    else if (opagacka){   // ako znamenceto e ostanalo 1, odnosno true, znaci deka prvio element e najgolem i site nagore se pomali pomali , odnoso se namaluvat
        cout<<"Nizata e strogo opagacka";
    }

    else if (!rastecka && !opagacka){   // ako pa i dvete znamenca sa 0, odnosno false , znaci deka ne e ni prvio najmal pa nagore da rastat, ni pa prvio e najgolem pa nagore da opagat.. znaci deka nizata e mesavina i ne ni rastecka ni opagacka
        cout<<"Nizata e nitu rastecka nitu opagacka";
    }

    return 0;
}