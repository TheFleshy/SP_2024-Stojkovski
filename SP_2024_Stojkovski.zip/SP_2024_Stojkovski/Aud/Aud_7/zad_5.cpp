// Да се напише програма за ротирање на елементите на една низа за едно место во десно.
// На крај, да се испечати на екран ротираната низа. Елементите од низата се читаат од стандарден влез.

#include <iostream>
using namespace std;
int main (){

    int n;
    int niza[100];

    cin>>n;

    for (int i = 0; i<n; i++){
        cin>>niza[i];             // ispisuvame ja nizata
    }

    int temp;  // kreirame privremena

    temp = niza[n-1];   // zimame ja poslednata cifra od nizata i ja stavame u privremenata

    for (int i = n-1; i>0; i--){
        niza[i] = niza [i-1];                       // NEZNAM SO PRAVE OVAJ CIKLUS
    }

    niza[0] = temp;    // zamenuvame ja prvata cifra od nizata so poslednata cifra, koja so bese staena u privremenata

    for (int i=0; i<n; i++){
        cout<<niza[i]<<" ";     // ispisuvame ja na novo nizata so prazno mesto megju sekoj clen
    }

    return 0;
}