//Da se presmeta prosekot na 10 broevi vneseni od tast. Za sekoj broj da se otpecati dali e pod ili nad prosekot

#include <iostream>
using namespace std;
int main (){

    int n;
    int broj [10];

    float prosek = 0;

    cout<<"Vnesuvaj broevi: "<<endl;

    for (n=0; n<10; n++)
        cin>>broj[n];

    for (n=0; n<10; n++)
        prosek += broj [n];
    prosek/n;

    cout<<"Srednata vrednost na vnesenite broevi e: "<<prosek<<endl;

    for (n=0; n<10; n++)
        cout<<broj[n]<<(broj[n]>prosek? "> ": "<=") <<prosek << endl;


    return 0;
}