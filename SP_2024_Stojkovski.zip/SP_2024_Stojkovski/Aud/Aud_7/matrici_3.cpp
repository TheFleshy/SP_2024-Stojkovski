//Да се напише програма која за квадратна матрица внесена од тастатура
// ќе испечати на екран дали таа е симетрична во однос на главната дијагонала.

#include <iostream>
using namespace std;
int main (){

    int mat[100][100], n, simetricna = 1;

    cin>>n;

    for (int i=0; i<n; i++){              // iskucuvame gi elementite na matricata
        for (int j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    for (int i=0; i<n-1; i++){            // za i od 1v do posleden i
        for (int j=i+1; j<n; j++){       // za j od 2r do goleminata na kvadratnata niza
            if (mat[i][j] != mat[j][i]){    // ako elementite na matricata kako i da sa napisani ne sa simetricni da ja stae flag za simetricna 0
                simetricna = 0;
                break;
            }
        }
        if (simetricna == 0)       // ako posle prvio ciklus , pa e 0 isto da prekine
            break;
    }

    if (simetricna){
        cout<<"Taa e simetricna!"; // ako simetricna e ostanala 1 , pecate deka e simetricna
    }
    else {
        cout<<"Ne e simetricna"; // ako se smene simetricna = 0, pecate deka ne e simetricna .
    }

    return 0;
}