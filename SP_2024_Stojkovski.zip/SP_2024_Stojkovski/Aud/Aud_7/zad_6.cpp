// Да се напише програма за ротирање на елементите на една низа за m местa во десно.
// На крај, да се испечати на екран ротираната низа.
// Елементите од низата и бројот на ротирања се читаат од стандарден влез.


#include <iostream>
using namespace std;
int main (){

    int n, mesta;
    int niza[100];

    cin>>n;
    cin>>mesta; // za koku mesta ke se pomestuva nizata u desno

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    for (int i=0; i<n; i++){
        cout<<niza[i]<<" ";        // moze i bez nego samo e za da videme so se ke se naprae
    }

    cout<<endl;  // ovoa pa ic

    int temp;

    for (int j=0; j<mesta; j++){    // od prvio so e 0 do koku mesta  // ISTO E KAKO ZA EDNO MESTO MESTENJE SAMO TUKA AKO SAKAME DA STAVEME ZA KOKU MESTA DODAVAME GO OVAJ CIKLUS , IST KAKO DEFAULTO
        temp = niza[n-1];  // cuvame ja poslednata cifra

        for (int i=n-1; i>0; i--){  // ciklus za mestenje u desno za koku ke uneseme m
            niza[i] = niza [i-1];
        }
        niza[0] = temp;  // prvio element go meneme so poslednio
    }

    for (int i=0; i<n; i++){   // poslednata napraena niza ja pcetame so prazno mesto megju clenovite
        cout<<niza[i]<<" ";
    }

    return 0;
}