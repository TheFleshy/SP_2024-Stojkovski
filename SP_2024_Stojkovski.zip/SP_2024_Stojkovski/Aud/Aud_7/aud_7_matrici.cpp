//#include <iostream>
//using namespace std;
//int main (){
//
//    int n,m;
//    cin>>n>>m;
//
//    int mat[100][100];
//
//    int i, j;
//
//    int zbirKoloni=0, zbirRedici=0;
//
//    for (i=0; i<n; i++){
//        for (j=0; j<m; j++){
//            cin>>mat[i][j];
//        }
//    }
//
//    for (i=0; i<n; i++){
//        for (j=0; j<m; j++){
//            if (j % 2){
//                zbirKoloni += mat[i][j];      // zbir na parni koloni
//            }
//            if ((i+1) % 2 ){
//                zbirRedici += mat[i][j];   // zbir na neparni redici
//            }
//        }
//    }
//
//    cout<<zbirKoloni-zbirRedici;
//
//
//    return 0;
//}

//#include <iostream>
//
//using namespace std;
//
//int main() {
//
//    int n;
//
//    cin >> n;
//
//    int mat[100][100];
//
//    int i, j;
//    int maks, min;
//
//    for (i = 0; i < n; i++) {
//        for (j = 0; j < n; j++) {
//            cin >> mat[i][j];
//
//            if (i == 0 && j == 0) {
//                maks = mat[i][j];
//                min = mat[i][j];
//            } else if (mat[i][j] > maks) {
//                maks = mat[i][j];
//            } else if (mat[i][j] < min) {
//                min = mat[i][j];
//            }
//        }
//    }
//
//    for (i = 0; i < n; i++) {
//        mat[i][i] = maks - min;
//    }
//
//
//    for (i = 0; i < n; i++) {
//        for (j = 0; j < n; j++) {
//            cout << mat[i][j] << " ";
//        }
//        cout << endl;
//    }
//
//
//    return 0;
//}

//#include <iostream>
//using namespace std;
//int main (){
//
//    int n;
//    cin>>n;
//
//    int mat[100][100];
//
//    int i, j;
//
//
//    int maks, min;
//
//    for (i = 0; i < n; i++) {
//        for (j = 0; j < n; j++) {
//            cin >> mat[i][j];
//
//            if (i == 0 && j == 0) {
//                maks = mat[i][j];
//                min = mat[i][j];
//            } else if (mat[i][j] > maks) {
//                maks = mat[i][j];
//            } else if (mat[i][j] < min) {
//                min = mat[i][j];
//            }
//        }
//    }
//
//    for (i=0; i<n; i++){
//        mat[i][n-i-1] = maks-min;
//    }
//
//
//    for (i=0; i<n; i++){
//        for (j=0; j<n; j++){
//            cout<<mat[i][j]<<" ";
//        }
//        cout<<endl;
//    }
//
//
//    return 0;
//}