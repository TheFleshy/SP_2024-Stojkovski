//Да се напише програма која за матрица внесена од тастатура ќе ја пресмета
//разликата на збирот на елементите на непарните колони и збирот на елементите на парните редици.
//Матрицата не мора да биде квадратна.

#include <iostream>
using namespace std;
int main (){

    int n, m;                  // n - redici, m - koloni
    int matrica[100][100];

    int sumaRedici=0, sumaKoloni = 0;

    cin>>n>>m;

    for (int i = 0 ; i<n; i++){
        for (int j=0; j<m; j++){
            cin>>matrica[i][j];         // ispisuvame ja matricata
        }
    }

    for (int i = 0; i<n; i++){
        for (int j=0; j<m; j++){
            if ((j+1) % 2){           // j+1 - isto mesto da pocne od 0 za parni, da pocne od 1 za neparni
                sumaKoloni = sumaKoloni + matrica[i][j];
            }
            if (i % 2) {  // i - isto kako da pocne od 0 za parni
                sumaRedici = sumaRedici + matrica [i][j];
            }
        }
    }

    cout<<sumaKoloni-sumaRedici;

    return 0;
}

