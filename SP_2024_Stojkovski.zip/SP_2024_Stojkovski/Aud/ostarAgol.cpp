#include <iostream>

using namespace std;

int main() {
    int a;
    cout << "Vnesi go agolot: " << endl;
    cin >> a;
    if (a > 0 && a < 90) {
        cout << "Agolot e ostar!";
    } else if (a == 90) {
        cout << "Agolot e prav!";
    } else if (a == 0) {
        cout << "Agolot e ramen!";
    } else {
        cout << "Agolot e tap!";
    }

    return 0;
}