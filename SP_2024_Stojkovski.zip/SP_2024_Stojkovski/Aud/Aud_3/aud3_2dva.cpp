//Да се напише програма која ќе чита два цели броеви (x, y) од тастатура и на компјутерскиот екран
// ќе го испечати резултатот (z) од следниот израз:
//z = x++ + --y + (x<y)
//Каква вредност ќе има z за x = 1, y = 2?

#include <iostream>

using namespace std;

int main() {
    int x, y, z;
    cout << "Vnesi dva celi broja:" << endl;
    cin >> x >> y;
    z = x++ + --y + (x < y);
    cout << z;
    return 0;
}