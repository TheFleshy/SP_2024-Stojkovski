//Да се напише програма каде од тастатура ќе се внесе цена на производ,
// а потоа ќе ја испечати неговата цена со пресметан ддв.

//ПОМОШ: ДДВ е 18% од почетната цена

#include <iostream>

using namespace std;

int main() {
    int cena;
    float ddv = 1.18F;
    cout << "Vnesete ja cenata:" << endl;
    cin >> cena;
    cout << "Cenata so vklucen ddv e: " << cena * ddv;
    return 0;
}