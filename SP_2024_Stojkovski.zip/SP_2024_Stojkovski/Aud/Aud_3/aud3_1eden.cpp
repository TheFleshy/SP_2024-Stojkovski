//Да се напише програма која чита знак од тастатура
// и во зависнот од тоа дали е мала или голема буква печати 1 или 0, соодветно.

//ПОМОШ: Користете логички и релациски оператори за тестирање на ASCII вредноста на знакот.
//Бонус: Направете проверка дали знакот е цифра


#include <iostream>

using namespace std;

int main() {
    char a;
    cout << "Vnesete karakter:" << endl;
    cin >> a;
    if (a >= 'a' && a <= 'z') {
        cout << "Vnesovte mala bukva!" << endl;
    } else if (a >= 'A' && a <= 'Z') {
        cout << "Vnesovte golema bukva! " << endl;
    } else if (a >= '0' && a <= '9') {
        cout << "Vnesovte brojka!" << endl;
    } else {
        cout << "Vnesovte drug simbol!" << endl;
    }

    return 0;
}
