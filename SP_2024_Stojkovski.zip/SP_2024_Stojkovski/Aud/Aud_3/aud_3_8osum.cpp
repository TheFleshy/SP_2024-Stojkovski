//Да се напише програма со која ќе се отпечати
// максимумот од два броја чии вредности се читаат од тастатура.

#include <iostream>

using namespace std;

int main() {
    int x, y;
    cout << "Vnesi dve vrednosti:" << endl;
    cin >> x >> y;
    if (x > y) {
        cout << "Maximumot e: " << x << endl;
    } else {
        cout << "Maximumot e: " << y << endl;
    }
    return 0;
}