//3.1. Пример
// Dali sp e lesen predmet?

#include <iostream>

using namespace std;

int main() {
    char odgovor;
    cout<<"Dali sp e lesen predmet ? (d/n): "<<endl;
    cin>>odgovor;
    switch (odgovor) {
        case 'd':
        case 'D':
            cout<<"I jas mislam taka!"<<endl;
            break;
        case 'n':
        case 'N':
            cout<<"Navistina?"<<endl;
            break;
        default:
            cout<<"Dali da ili ne ?"<<endl;
    }
    return 0;
}