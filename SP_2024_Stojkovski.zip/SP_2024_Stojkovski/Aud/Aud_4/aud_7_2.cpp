//3.2. Пример за реализација на (текст) мени

#include <iostream>
using namespace std;
int main (){
    int vrednost, izbor;
    cout<<"Vnesete pocetna vrednost: ";
    cin>>vrednost;

    do {
        do {
            cout<<"Meni:"<<endl;
            cout<<"1 - zgolemi "<<endl;
            cout<<"2 - namali "<<endl;
            cout<<"3 - dupliraj "<<endl;
            cout<<"0 - kraj "<<endl;
            cin>>izbor;
        }
        while (izbor < 0 || izbor > 3);
        switch (izbor) {
            case 1:
                vrednost++;
                break;
            case 2:
                vrednost--;
                break;
            case 3:
                vrednost *= 2;
                break;
            case 0:
                cout<<"Kraj!"<<endl;
                break;
            default:
                cout<<"Nevaliden izbor!"<<endl;
                break;
        }
        cout<<"Vrednost = "<<vrednost<<endl;
    }
    while (izbor != 0);
    return 0;
}