// Од тастатура се внесуваат должини на три отсечки во произволен редослед.
// Да се напише програма што ќе провери дали од отсечките може да се конструира триаголник,
// при што ако може, да се провери дали истиот е правоаголен и да се пресмета неговата плоштина.
// Во спротивно, треба да се испечатат соодветни пораки.

#include <iostream>

using namespace std;

int main() {
    float a, b, c;
    cin >> a >> b >> c;
    if (a + b <= c || a + c <= b || b + c <= a) {
        cout << "Ne moze da se konstruira triagolnik";
    } else {
        if (a >= b) {
            float tmp = a;
            a = b;
            b = tmp;
        }
        if (a >= c) {
            float tmp = a;
            a = c;
            c = tmp;
        }
        if (b >= c) {
            float tmp = b;
            b = c;
            c = tmp;
        }
        if (c * c == a * a + b * b) {
            cout << "Triagolnikot e pravoagolen" << endl;
            cout << "Plostinata mu e: " << a * b / 2;
        }
        else {
            cout<<"Triagolnikot ne e pravoagolen!";
        }
    }
    return 0;
}