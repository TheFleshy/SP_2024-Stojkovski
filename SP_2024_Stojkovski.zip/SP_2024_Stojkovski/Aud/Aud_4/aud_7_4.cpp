// 3.4. Задача 2
// Да се напише програма што ќе претставува едноставен калкулатор. Во програмата се вчитуваат два броја и оператор во формат:
// broj1 operator broj2
// По извршената операција во зависност од операторот, се печати резултатот во формат:
// broj1 operator broj2 = rezultat

#include <iostream>

using namespace std;

int main() {
    double broj1, broj2, rezultat;
    char operatorce;

    cout<<"Vnesete dva broja i operator (pr. 2 + 2): ";
    cin>>broj1 >> operatorce >> broj2;

    switch (operatorce) {
        case '+':
            rezultat  = broj1 + broj2;
            break;
        case '-':
            rezultat = broj1 - broj2;
            break;
        case '*':
            rezultat = broj1 * broj2;
            break;
        case '/':
            if (broj2 != 0){
                rezultat = broj1 / broj2;
            }else {
                cout<<"Ne se deli so 0"<<endl;
                return 1;
            }
        break;
        default:
            cout<<"Nepoznat operator!"<<endl;
            return 1;
    }
    cout<<broj1<<' '<< operatorce <<' '<<broj2<<" = "<<rezultat<<endl;
    return 0;
}