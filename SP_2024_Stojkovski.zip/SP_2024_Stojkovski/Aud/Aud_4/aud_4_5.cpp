//Од тастатура се внесуваат должини на три отсечки во произволен редослед.
// Да се провери дали од дадените отсечки може да се конструра триаголник.
// Ако може, да се испечати дали триаголникот е разностран, рамностран или рамнокрак
// и да му се пресмета плоштината.

#include <iostream>
#include <cmath>

using namespace std;

int main() {
    float a,b,c;
    cin>>a>>b>>c;
    if (a + b <= c || a + c <= b || b + c <= a){
        cout<<"Ne moze da se konstruira triagolnik! ";
    }
    else {
        if (a==b && b==c && c==a){
            cout<<"Triagolniko e ramnostran! ";
        }
        else if (a==b || b==c || a==c){
            cout<<"Triagolnikot e ramnokrak! ";
        }
        else {
            cout<<"Triagolnikot e raznostran! ";
        }
    }
    float s =  (a + b + c) / 2;
    float p = sqrt(s * (s - a) * (s - b) * (s - c));
    cout<<"Plostinata mu e: "<<p;
    return 0;
}