// За дома
// 4.1. Задача 1
// За три внесени отсечки да се одреди дали е можно да се конструира триаголник и притоа
// дали триаголникот е правоаголен, остроаголен или тапоаголен.

#include <iostream>

using namespace std;

int main() {
    int a,b,c;
    cout<<"Vnesi tri otsecki: ";
    cin>>a>>b>>c;
    if (a > 0 && b > 0 && c > 0 && a+b>c && a+c>b && b+c>a){
        cout<<"Moze da se konstruira triagolnik";
    }else {
        cout<<"Ne moze da se konstruira triagolnik";
    }
    return 0;
    //ЗА ПРАВОАГОЛЕН, ОСТРОАГОЛЕН И ТАПОАГОЛЕН ПОЈМА НЕАМ..
}