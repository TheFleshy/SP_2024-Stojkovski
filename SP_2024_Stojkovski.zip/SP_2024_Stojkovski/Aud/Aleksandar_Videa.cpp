/// REKURZIJA AUDITORISKI ALEKSANDAR STOJMENSKI

// da se napise programa sto ke ja ispisuva vrednosta na n-tiot clen na nizata def so:
// x[1] = 1
// x[2] = 2
// x[n] = (n-1) * [n-1] / n + x[n-2] / n


#include <iostream>
using namespace std;

float rek (int n){

    if (n == 1){
        return 1;
    }
    if (n == 2){
        return 2;
    }

    return (n-1) * 1.0 * rek(n-1) / n + rek(n-2) / n;  // toa 1.0 nemora oti sekako e float

}

int main (){

    int n = 20;
    cout<<rek(n);

    return 0;
}


#include <iostream>
using namespace std;
int main (){

    int n,m;

    int mat[100][100];
    cin>>n>>m;
    int i,j;
    for (i=0; i<n; i++){
        for (j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    int r = n;
    for (j=0; j<m; j++){
        for ( i=0; i<r; i++){
            cout<<mat[i][j]<<" ";
        }
        for (int k=j+1; k<m && i>0; k++){
            cout<<mat[i-1][k]<<" ";
        }
        r--;
        if (r>0){
            cout<<endl;
        }
    }


    // 3 3
    // 1 2 3     // pecate nadole pa desno, taka za sekoja kolona, samo se namaluva za edna redica
    // 1 2 3

    // 1 2 3
    // 1 1 1 2 3
    // 2 2 3
    // 3

    return 0;
}


//
//komandite za dvizenje se zadadeni kako niza od znaci (ne podolga od 100) sostavena od cifrite 1,2,3,4,6,7,8,9
//koi oznacuvaat pridvizuvanje niz matricata na soseden element vo odnos na tekovniot.
//So sekoja komanda (eden znak od nizata) se pridvizuvame na nekoj od 8-te sosedni elemetni na tekovniot.
//Dvizenjeto niz elementite od matricata se pravi vo pravci kako sto se rasporedeni cifrite na numericka tastatura i toa:
//1 - dvizenje dijagonalno dole levo  -
//2 - vo ista kolona nadolu --
//3 - dijagonalno dole desno ---
//4 - ista redica nalevo =
//6 - ista redica nadesno =
//        7 - dijagonalno gore levo -
//8 - ista kolona nagore --
//9 - dijagonalno gore desno ---
//ako so nekoj od potezite se izleze nadvor od matricata, se prekinuva so dvizenjeto i se pacate: "Error: out of matrix"
//
//input
//3 3     // dimnz
//5 4 6   // elem na mat
//8 2 1
//9 0 3
//1 1     // pozicija na pojdoven element
//48631    // komandi za dvizenje

#include <iostream>
#include <cstring>
using namespace std;
int main (){

    int mat[30][30];
    int m,n;
    int i,j;
    cin>>m>>n;

    for (i=0; i<m; i++){
        for (j=0; j<n; j++){
            cin>>mat[i][j];
        }
    }

    int red, kolona;
    cin>>red>>kolona;

    char komandi[100];
    cin.ignore();         // ovoa e nogu bitna stvar !!!
    gets(komandi);

    int suma = mat[red][kolona];
    for (i=0; i< strlen(komandi); i++){
        char komanda = komandi[i];
        switch (komanda) {
            case '1':
                red+=1; kolona-=1;
                break;
            case '2':
                red+=1;;
                break;
            case '3':
                red+=1; kolona+=1;
                break;
            case '4':
                kolona-=1;
                break;
            case '6':
                kolona+=1;
                break;
            case '7':
                red-=1; kolona-=1;
                break;
            case '8':
                red-=1;
                break;
            case '9':
                red-=1; kolona+=1;
                break;
            default:
                cout<<"Error";
        }
        if (red >= 0 && red < m && kolona >=0 && kolona < n){
            suma += mat[red][kolona];
        }
        else {
            cout<<"Error: out of matrix";
            return 0;
        }
    }
    cout<<suma;


    // 3 3
    // 5 4 6
    // 8 2 1
    // 9 0 3
    // 1 1
    // 48631

    return 0;
}

//
//Da se napise funkcija koja vo string sto i se predava kako vlezen parametar ke gi promeni malite bukvi vo golemi
//        i obratno, i ke go ostrani site cifri i spec znaci

#include <iostream>
#include <cstring>
using namespace std;

void promeni(char niza[]){

    int i,j=0;
    for (i=0; i< strlen(niza); i++){
        if (isalpha(niza[i])){
            if (islower(niza[i])){
                niza[j] = toupper(niza[i]);
            }
            if (isupper(niza[i])){
                niza[j] = tolower(niza[i]);
            }
            j++;
        }

    }
    niza[j] = '\0';   // kuga ne go dodadeh ovoa i brojkite mi gi smetase mame mu
}

int main (){

    char niza[100];
    cin.getline(niza, 100);

    int len = strlen(niza);
    niza[len-1] = '\0';

    promeni(niza);
    cout<<niza<<endl;
}


//za broenje na cifri u edna recenica
#include <iostream>
#include <cstring>
using namespace std;

int izbroiCifri (char niza[]){
    int brCifri = 0;

    for (int i=0; i< strlen(niza); i++)
    {
        if (isdigit(niza[i])){
            brCifri++;
        }
    }
    return brCifri;
}

int main (){

    char niza[100];
    cin.getline(niza, 100);

    cout<<izbroiCifri(niza);

    return 0;
}


//KOLOKVIUMSKI - ALEKSANDAR STOJMENSKI //
//
//od standarden vlez se unasat N (n<100) poz cel broevi (prvo broj na broevi koi ke se vnesat pa broevite)
//napisi programa koja na std izl ke ispecati site broevi koi go ispolnuvaat dadeniot kriterium vo istiot redosled vo koj se pojavuvaat na vlezot
//
//Kriterium: najmnogu znacajna cifra (cifra na najleva pozicija) e parna i se naoga na parna pozicija ili najmnogu znacajnata cifra e neparna i se naogja na neparna pozcija.
//se smeta deka najmalku znacajnata cifra vo brojot se naoga na 1va pozicija.
//Ako vo vnsenite broevi ne postoi nitu eden takov broj, treba da se ispecati poraka "No such number".
//Pri implementacija, proeverkata dali daden broj go ispolnuva dadeniot kriterium treba da se realizira vo posebna funkcija

#include <iostream>
using namespace std;

int uslov(int broj){

    int poz = 1;

    while (broj >= 10){
        poz++;
        broj /=10;
    }
    int najznacajna = broj;

//    if ((poz % 2 == 0 && najznacajna % 2 == 0) || (poz % 2 != 0 && najznacajna % 2 != 0)){
//        return 1;
//    }else return 0;   --- ovoa e isto kako toa pod nego samo kratko xdd

    return poz % 2 == najznacajna % 2;
}

int main (){

    int n;
    cin>>n;

    int najdeno = 0;

    for (int i=0; i<n; i++){
        int broj;
        cin>>broj;
        if (uslov (broj)){
            cout<<broj<<endl;
            najdeno = 1;
        }
    }

    if (najdeno == 0){
        cout<<"No such number"<<endl;
    }

    return 0;
}


//MATRICA
//        Od tastatura se vnesuvaat dimenziite m i n , i nejzninite elemen. Potoa se vnesuvaat dva celi broja r i k (indeksi na redica,kolona od matrica, t.s 0<=r<m , 0<=k<n)
//da se napise programa koja ja transformira matricata A taka sto elementite nad redicata r i levo od kolonata k se zamenuvaat so minimalnata vrednost od matricata A

#include <iostream>
using namespace std;
int main (){

    int m,n;
    int r,k;

    int min_elem = 0;
    int mat[30][30];

    cin>>m>>n;
    cin>>r>>k;

    int i,j;
    for (i=0; i<m; i++){
        for (j=0; j<n; j++){
            cin>>mat[i][j];
            if (i ==0 && j==0){
                min_elem = mat[i][j];
            }
            else if (mat[i][j] < min_elem){
                min_elem = mat[i][j];
            }
        }
    }

    for (i=0; i<r; i++){
        for (j=0; j<k; j++){
            mat[i][j] = min_elem;
        }
    }

    for (i=0; i<m; i++){
        for (j=0; j<n; j++){
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}


//
//NIZA OD ZNACI // ne e toku teska ovaa //
//
//od std se cita cel broj N i potoa N nizi od znaci. Nizite znaci sodrzat bukvi, cifri i specijalni znaci,
//a sekoja od niv e pogolema od 50 znaci
//        Da se ispecate site nizi od znaci vo koi se sodrzi podnizata A1c najmalku 2 pati. spored redosledot kako sto se procitani od vlezot.
//Pri pecatenje na zborovite, site alfabetski znaci treba da se ispecatat so mali bukvi.

#include <iostream>
#include <cstring>
#include <cctype>
#include <iomanip>
using namespace std;
int main (){

    char str[100];

    int n;
    cin>>n;

    for (int i=0; i<n; i++){
        cin>>str;
        int brojPojavuvanja = 0;
        for (int j=0; j< strlen(str)-2; j++){
            if (tolower(str[j]) == 'a' && str[j+1] == '1' && tolower( str[j+2])== 'c' ){
                brojPojavuvanja++;
            }
        }
        if (brojPojavuvanja >= 2){
            for (int j=0; j<strlen(str); j++){
                char mala = tolower(str[j]);
                cout<<mala;
            }
            cout<<endl;
        }
    }

    return 0;
}



