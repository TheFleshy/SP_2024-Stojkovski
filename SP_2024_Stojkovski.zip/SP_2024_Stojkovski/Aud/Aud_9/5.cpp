//Да се напише рекурзивна функција која ќе го пресметува збирот на цифрите на еден број.
// sumDigits(126) -> 9
// sumDigits(49) -> 13
// sumDigits(12) -> 3

#include <iostream>
using namespace std;

int zbirCifri (int n){
    if (n == 0)
        return n;
    else
        return n%10 + zbirCifri(n/10);
}


int main (){

    int n;
    cin>>n;

    cout<<zbirCifri(n);

    return 0;
}