//Да се напише програма која за даден природен број ја пресметува разликата помеѓу најблискиот поголем од него прост број и самиот тој број.
//Програмата треба да користи рекурзивна функција за наоѓање на соодветниот прост број,
// која пак треба да користи рекурзивна функција за проверка дали даден број е прост број.

//Пример:
//Ако се внесе 573, програмата треба да испечати 577 - 573 = 4

#include <iostream>
using namespace std;

int daliEprost (int n, int i){  // rekurzivna za Dali brojot e prost
    if (n<4)
        return 1;
    else if ((n%2) == 0)
        return 0;
    else if (n%i == 0)
        return 0;
    else if (i * i > n)
        return 1;
    else
        return daliEprost(n, i+2);
}

int prvNajgolemProstBroj (int n){    // rekurzivna da najde prv najgolem prost broj
    if (daliEprost(n+1, 3))
        return n+1;
    else
        return prvNajgolemProstBroj(n+1);
}

int main (){

    int broj, razlika;

    cin>>broj;

    razlika = prvNajgolemProstBroj(broj) - broj;   // razlikata na prvio najgolem i samio broj so od nego e najgolem

    cout<<prvNajgolemProstBroj(broj)<< " - "<<broj<<" = "<<razlika<<endl;   // da se ispecate razlikata

//    cout<<razlika<<endl; // moze samo vaka

    return 0;
}









