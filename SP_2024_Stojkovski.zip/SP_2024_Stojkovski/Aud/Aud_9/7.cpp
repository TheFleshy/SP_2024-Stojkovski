//Да се напише програма која што за дадена низа од природни броеви (која што се внесува од тастатура)
//ќе го отпечати најголемиот заеднички делител (НЗД) на нејзините елементи.
//Програмата задолжително треба да содржи рекурзивна функција за пресметување НЗД на два природни броја.

// pr.  48 36 120 72 84
// output:  NZD na elementite na ovaa niza e 12

// НЗД за два броја може да се пресмета со користење на Евклидовиот алгоритам
//За да се пресмета НЗД на броевите m и n, се пресметува остатокот при делење на m со n.
//ако остатокот не е 0, се пресметува остатокот при делење на n со m % n
//постапката се повторува се додека се добиваат ненулти остатоци
//ако остатокот е 0, НЗД на двата броја е последниот пресметан ненулти остаток

// Evklidov algoritam - primer
//  NZD(20, 12)
//  20 % 12 = 8
//  12 % 8 = 4
//  8 % 4 = 0

//  NZD(20, 12) = 4

#include <iostream>
using namespace std;

int NZD(int m, int n){
    if (n == 0)
        return m;
    return NZD(n, m % n);
}


int main (){

    int n;
    cin>>n;

    int niza[100];

    for (int i = 0 ; i<n; i++){
        cin>>niza[i];
    }

    int LokalnoNZD = NZD(niza[0] , niza[1]); // oti veke imame za prvite 2


    for (int i=2; i<n; i++){  // mora da steme =2 , za da sporede prvite 2 so tretio i taka natamo
        LokalnoNZD = NZD(LokalnoNZD, niza[i]);
    }

    cout<<"NZD na elementite od nizata e: "<<LokalnoNZD<<endl;

    return 0;
}