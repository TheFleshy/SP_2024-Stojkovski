// Да се напише рекурзивна функција count_down(int n)
// која за даден цел број n ќе овозможи печатење на броевите од n до 0.

#include <iostream>
using namespace std;

void count_down(int n){  // rekurzivna funkcija za ispisuvanje od n do 0
    if (n == 0){
        cout<<0<<" ";
        return;
    }
    cout<<n<<" ";
    count_down(n-1);
}

void count_up(int n){  // rekurzivna funkcija za ispisuvanje od 0 do n
    if (n == 0){
        cout<<0<<" ";
        return;
    }
    count_up(n-1);
    cout<<n<<" ";
}

int main (){

    int n;
    cin>>n;

    count_down(n);  // ke ja ispecate od n do 0
    cout<<endl;
    count_up(n);  // ke ja ispecate od 0 do n

    return 0;
}