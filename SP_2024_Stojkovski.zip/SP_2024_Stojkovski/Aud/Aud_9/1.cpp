//Да се пресмета збирот 1! + (1+2)! + (1+2+3)! + … + (1+2+…+n)!
// притоа: - користете рекурзивна функција за пресметување на збирот на првите k природни броеви.
// - користете рекурзивна функција за пресметување на факториел на еден природен број.

#include <iostream>
using namespace std;

int fak(int n){  // faktoriel na eden priroden broj
    if (n == 0){
        return 1;
    }
    return n* fak(n-1);
}

int suma (int k){ // zbir na prvite k prirodni broevi
    if (k == 0){
        return 0;
    }
    return k + suma(k-1);
}

int main (){

    int i, n, restultat = 0;

    cin>>n;

    if (n > 0){
        for (i = 1; i<n; i++){
            int s = suma(i);
            restultat += fak(s);
                    cout<<s<<"! + ";
        }

        int s = suma(n);
        restultat += fak(s);
        cout<<s<<"! = "<<restultat << endl;
    }
    else
        cout<<"Pogresen vlez!"<<endl;

    return 0;
}