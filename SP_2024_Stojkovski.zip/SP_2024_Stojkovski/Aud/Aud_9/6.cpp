// За даден број n, да се напише рекурзивна функција која ќе ги изброи појавувањата на цифрата 8.
// Притоа, доколку до некоја цифра 8 има уште една цифра 8 веднаш лево од неа, нејзиното појавување се брои двојно.
//PRIMER/
//  count8(8) -> 1
//  count8(818) -> 2
//  count8(8818) -> 4

#include <iostream>
using namespace std;
int count8 (int n){  // rekurzivna funckija oti si vika za daden broj pa pisame int n
    if (n == 0)   // prv slucaj ako brojo e ednakov na 0, da zavrse
        return 0;
    if ((n/10) % 10 == 8 && n%10 == 8 )   // vtor slucaj ako brojo/10 % 10 , predposlednio == 8, i poslednio e ednakov na 8
        return 2 + count8(n/10);      // broe se dvojno toa edns go prave zatoa e n/10
    if (n%10 == 8)                    // oti moze samo i poslednata cifra da e 8 , epa tugaj ke broe kako 1, oti ima edno pojavuvanje na 8
        return 1 + count8(n/10);
    return count8(n/10);            // ako ni edno od tia vraka broj/10
}


int main (){

    int n;
    cin>>n;

    cout<<count8(n);

    return 0;
}