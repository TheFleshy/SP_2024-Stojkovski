//Да се напише програма што ќе ја испишува вредноста на n-тиот член на низата дефинирана со:
//    x[1] = 1
//    x[2] = 2
//    ...
//    x[n] = (n - 1) * x[n - 1] / n + x[n - 2] / n

#include <iostream>
using namespace std;

float formulata (int n){  // zamenuvas samo so formulata i dadeno e za vtor i tret slucaj, nia da napraeme za n
    if (n == 1)  // za vtorio element oti pocnuva od 0!
        return 1;
    if (n == 2)    // za tretio element oti pocnuva od 0!
        return 2;

    return formulata(n - 1)* formulata(n - 1) / n + formulata(n - 2 )/ n;  // ovoa e za n
}

int main (){

    int n;
    cin>>n;

    cout<<formulata(n)<<endl;


    return 0;
}