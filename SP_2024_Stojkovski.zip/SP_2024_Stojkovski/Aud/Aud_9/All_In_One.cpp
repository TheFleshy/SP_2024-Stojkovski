/// #1

#include <iostream>
using namespace std;

int rek(int n){
    if (n == 0) return 1;

    else
        return n * rek(n-1);
}

int sum (int k){
    if (k==0) return 0;
    else
        return k+ sum(k-1);
}


int main (){

    int n;
    cin>>n;

    int resultat =0;
    if (n>0){
        for (int i=0; i<n; i++){
            int s = sum(i);
            resultat += rek(s);
        }

        int su = sum(n);
        resultat += rek(su);
        cout<<su<<"! = "<<resultat<<endl;
    }
    else {
        cout<<"Pogresen vnes";
    }

    return 0;
}



/// #2 , #2.1

#include <iostream>
using namespace std;

void count_down(int n){

    if (n==0){
        cout<<0<<" ";
        return ;
    }

    cout<<n<<" ";
    count_down(n-1);
}

void count_up(int n){

    if (n==0){
        cout<<0<<" ";
        return ;
    }

    count_up(n-1);
    cout<<n<<" ";
}

int main (){

    int n;
    cin>>n;

    count_down(n);

    for (int i=n; i<0; i-- ){
        cout<<n;
    }
    cout<<endl;

    count_up(n);

    for (int i=n; i<0; i-- ){
        cout<<n;
    }

    return 0;
}


/// #3     - razlika megju najbliskiot pogolem od nego prost broj i samiot broj

#include <iostream>
using namespace std;

int DaliProst (int n, int i){
    if (n<4){
        return 1;
    }
    else if (n%2 == 0){
        return 0;
    }
    else if (n%i == 0){
        return 0;
    }
    else if (i*i > n){
        return 1;
    }
    else {
        return DaliProst(n, i+2);
    }
}

int prvProstBroj (int n){
    if (DaliProst(n+1, 3)){
        return n+1;
    }
    else {
        return prvProstBroj(n+1);
    }
}

int main (){

    int broj, razlika;

    cin>>broj;

    razlika = prvProstBroj(broj) - broj;

    cout<<prvProstBroj(broj)<<" - "<<broj<<" = "<<razlika<<endl;

    return 0;
}

/// #4

#include <iostream>
using namespace std;

float rek(int n){
    if (n == 1){
        return 1;
    }
    if (n == 2){
        return 2;
    }
    return (n - 1) * rek(n - 1)/n + rek(n-2)/n;
}

int main (){

    int n;
    cin>>n;

    cout<<rek(n);
    return 0;

}


/// #5

#include <iostream>
using namespace std;

int sumDigits(int n){
    if (n==0) return 0;
    return n%10 + sumDigits(n/10);
}

int main (){

    int n;
    cin>>n;

    cout<<sumDigits(n);

    return 0;
}


/// #6

#include <iostream>
using namespace std;

int broiOsum (int n){
    if (n == 0) return 0;

    else {
        if (n % 10 == 8 && (n/10)%10 == 8 ){
            return 2+ broiOsum(n/10);
        }
        if (n%10 == 8){
            return 1+ broiOsum(n/10);
        }
        return broiOsum(n/10);   // moze i 0+broiOsum(n); - za da ja vrne samo brojkata oti nema pojavuvanje
    }
}

int main (){

    int broj;
    cin>>broj;

    cout<<broiOsum(broj);

    return 0;
}


/// #7

#include <iostream>
using namespace std;

int NZD(int n, int m){
    if (m == 0) return n;
    return NZD(m, n%m);
}

int main (){

    int n;
    cin>>n;
    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    int nzd = NZD(niza[0], niza[1]);

    for (int i=2; i<n; i++){
        nzd = NZD(nzd, niza[i]);
    }

    cout<<nzd;

    return 0;
}

/// #9

#include <iostream>
using namespace std;

int suma(int niza[], int n){
    if (n == 0) return niza[0];
    else
        return niza[n] + suma(niza, n-1);
}

//int suma(int niza[], int i, int n){
//    if (i == n) return 0;
//    else                                                 // ovoa e drug nacin da se izmine niza i da se najde zbiro
//        return niza[i] + suma(niza, i+1, n);
//}

int main (){

    int niza[100];
    int n;
    cin>>n;

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    cout<<suma(niza, n-1);
//    cout<<suma(niza, 0, n);  - moze i vaka , ovoa e drug nacin da se izmine niza

    return 0;
}


/// #10 - domasna

#include <iostream>
using namespace std;

int najgolem(int niza[], int n){

    if (n == 0) return niza[0];

    int maks = najgolem(niza, n-1);

    if (niza[n] > maks){
        return niza[n];
    } else
        return maks;
}

int main (){

    int niza[100];
    int n;
    cin>>n;

    for(int i=0; i<n; i++){
        cin>>niza[i];
    }

    cout<<"Najgolemiot element vo nizata e: " ;
    cout<<najgolem(niza, n-1);

    return 0;
}