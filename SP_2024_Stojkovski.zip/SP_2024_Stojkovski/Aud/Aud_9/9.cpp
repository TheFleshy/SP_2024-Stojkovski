//Да се напише програма која за дадена низа од цели броеви (која што се внесува од тастатура)
// ќе го отпечати збирот на елементи од низата.
// Програмата треба да содржи рекурзивна функција за наоѓање на збирот на елементите во дадена низа.

#include <iostream>

using namespace std;

int zbirElementi(int niza[], int n) {
    if (n == 0)
        return niza[n];
    else
        return niza[n] + zbirElementi(niza, n - 1);
}

int main() {

    int n;

    cin >> n;

    int niza[100];

    for (int i = 0; i < n; i++) {
        cin >> niza[i];
    }

    cout << "Zbirot na elementite na nizata e: " << zbirElementi(niza, n - 1) << endl;

    return 0;
}



