// Да се напише програма која за дадена низа од цели броеви (која што се внесува од тастатура)
// ќе го отпечати најголемиот елемент.
// Програмата треба да содржи рекурзивна функција за наоѓање на најголем елемент во дадена низа.

// 5 8 3 12 9 6 - inptu
// Najgolem element vo nizata e 12 - output

#include <iostream>
#include <climits>

using namespace std;

int najgolemElement (int niza[], int n, int maks){
    if (n == 0)
        return maks;
    if (niza[n - 1] > maks) {
        maks = niza[n - 1];
    }
        return najgolemElement(niza, n-1, maks);
}


int main (){

    int n;
    int najgolema = INT_MIN;
    cin>>n;

    int niza[100];

    for (int i=0; i<n; i++){
        cin>>niza[i];
    }

    int rezultat = najgolemElement(niza, n, najgolema);

    cout<<"Najgolem element vo nizata e: "<<rezultat<<endl;

    return 0;
}

